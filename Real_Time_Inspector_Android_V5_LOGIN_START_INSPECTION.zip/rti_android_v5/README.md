REAL TIME INSPECTOR Android V3

QR-only inspector scanner connected to the live backend.

New in V3:
- Inspector Name + Inspector ID setup on first launch
- Inspector profile is saved on the phone
- Inspector Name/ID shown on the scanner screen
- QR token is sent directly to /api/scan (works with random server QR tokens)
- No NFC
- 4G/Internet supported

Backend:
https://muthasseer.pythonanywhere.com

Build with JDK 17 and Android Studio. A GitHub Actions workflow is included.


## V4 Inspector profile
- Inspector Name and Inspector ID are stored locally on the phone.
- Every scan sends `inspector_name`, `inspector_employee_id`, `device_id`, and QR token to the Real Time Inspector API.
- Server URL: https://muthasseer.pythonanywhere.com
- QR-only; NFC is not included.
