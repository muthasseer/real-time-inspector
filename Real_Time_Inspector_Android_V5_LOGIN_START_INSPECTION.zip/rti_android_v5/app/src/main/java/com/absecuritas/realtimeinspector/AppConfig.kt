package com.absecuritas.realtimeinspector

object AppConfig {
    const val SERVER_BASE_URL = "https://muthasseer.pythonanywhere.com"
    const val DEVICE_ID = "ANDROID-INSPECTOR"
    const val SCAN_ENDPOINT = "/api/scan"
}
