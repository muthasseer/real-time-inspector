@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "scripts\stop_all.ps1"
if errorlevel 1 pause
exit /b %ERRORLEVEL%
