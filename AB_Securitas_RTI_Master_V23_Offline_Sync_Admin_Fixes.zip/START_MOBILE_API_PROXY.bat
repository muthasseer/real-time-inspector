@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo AB SECURITAS - MOBILE API PROXY
echo ==============================================
echo Central server must already be running on port 5000.
echo This proxy exposes the mobile API and token-protected Client PC sync route on 127.0.0.1:5200.
echo START_TAILSCALE_FUNNEL.bat publishes this allow-listed proxy.
echo Press Ctrl+C to stop.
echo.
where py >nul 2>nul
if not errorlevel 1 (
  py -3 MobileApiProxy\proxy.py
) else (
  python MobileApiProxy\proxy.py
)
pause
