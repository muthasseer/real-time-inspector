# AB Securitas RTI — Master V23

## V23 offline repeats, diagnostics, and retention

- Android computes repeat results from the inspection's phone-stored events during offline use. Scan two is marked Repeat; scan three and later trigger Repeat Alert. Records remain safely queued.
- Client PC status separates Central domain reachability from the Client PC node-token and company-sync token checks. Android LAN test displays the Central status reported by the PC and reports address/DNS, timeout, and connection-refused errors.
- Scan-history deletion is Super Admin-only and writes an Audit Log entry for every deleted scan in the same SQLite transaction.
- Permanent inspector removal erases personal/profile credentials but retains the foreign-key tombstone and scan snapshots. Permanent device removal retains an inaccessible ID tombstone to prevent device re-enrollment. Both actions are audited.
- Windows uninstaller requires typing `UNINSTALL`, stops RTI services, preserves local configuration/data/backups outside the app folder, then removes only the verified RTI app folder.
- License keys have a copy action; numeric Company IDs are visible without a copy button. Android versionCode 27 / versionName 23.0.0. The V22 QR scanner code is unchanged.

## தமிழ் வழிகாட்டி

### அமைப்பு

- Android App முதலில் Central API-யின் Tailscale Funnel HTTPS முகவரியைப் பயன்படுத்தும்.
- Internet வழி கிடைக்காவிட்டால், ஒரே Wi-Fi / LAN-ல் உள்ள Client PC-யை நேரடியாக முயற்சிக்கும்.
- Internet மற்றும் LAN இரண்டும் இல்லாவிட்டால், Android-ல் உள்ள SQLite database-ல் scan பதிவு சேமிக்கப்படும்.
- Client PC வழியாக வந்த scan-களும் அதன் local SQLite database-ல் சேமிக்கப்பட்டு, Central server கிடைத்ததும் retry ஆகும்.
- Windows Central மற்றும் Client PC database-கள் replace ஆகக்கூடிய source folder-க்கு வெளியே இருக்கும்; பழைய database இருந்தால் copy செய்து original-ஐ அப்படியே வைத்திருக்கும்.
- Manual / scheduled / offline scan வகை, schedule பெயர், sync source ஆகியவை Central history மற்றும் Client PC monitor-ல் பதிவாகும்.
- Tailscale Funnel என்பது இயங்கும் server-க்கு HTTPS அணுகல் தரும். அது server hosting அல்ல.
- Administrator dashboard, Tailscale tailnet வழியாக மட்டும் திறக்க வேண்டும். Funnel வழியாக public-ஆக dashboard வெளியிடப்படாது.

உங்கள் office/laptop-ஐ அணைக்கும்போதும் Central தொடர்ந்து இயங்க வேண்டுமானால், Central API-ஐ cloud VM-ல் இயக்க வேண்டும். Package-ல் Debian/Ubuntu installer, systemd services, persistent database path, தேர்வு செய்யக்கூடிய daily SQLite backup ஆகியவை உள்ளன. இலவச VM கிடைப்பது அல்லது 24/7 செயல்பாடு உறுதி செய்யப்படவில்லை; provider account மற்றும் VM availability-ஐ தனியாக உறுதிப்படுத்த வேண்டும்.

### Cloud VM அமைத்தல்

1. VM-ல் Tailscale நிறுவி account-ல் sign in செய்யவும்.
2. Project folder-ல் இருந்து:

   sudo bash deploy/linux/install.sh

3. sudo tailscale up இயக்கி tailnet-ல் VM-ஐ approve செய்யவும்.
4. Tailnet-க்கு Funnel அனுமதியை enable/approve செய்யவும்.
5. sudo systemctl enable --now rti-funnel இயக்கவும்.
6. sudo tailscale funnel status மூலம் HTTPS முகவரியைப் பெறவும்.
7. Android app-இல் அந்த Funnel URL-ஐ உள்ளிட்டு சேமிக்கவும். Client PC configuration-லும் Central Funnel URL தேவை.
8. அதே tailnet-ல் உள்ள Admin PC-யிலிருந்து VM-ன் Tailscale IP-க்கு port 5000 மூலம் dashboard திறக்கவும்.

Public firewall-ல் port 5000 மற்றும் 5200-ஐ திறக்க வேண்டாம். Admin dashboard-க்கு tailnet வழி மட்டுமே பயன்படுத்தவும். Funnel public traffic-ஐ localhost:5200-ல் உள்ள allow-listed mobile proxy-க்கு மட்டும் அனுப்பும்.

முதல் login: admin / admin123. Dashboard பயன்படுத்துவதற்கு முன் password மாற்றவும். முதலில் company, license, inspectors, checkpoints உருவாக்கவும். Initial Cloud VM installer ஒரு company/client credential template-ஐ /var/lib/ab-securitas-rti/client-1.env-ல் உருவாக்கும்; அதில் உள்ள tokens-ஐ private-ஆக வைத்திருக்கவும்.

### Client PC மற்றும் LAN அமைத்தல்

Windows Client PC-ல் CLIENT_PC_SETUP.bat இயக்கி Python dependencies நிறுவவும். ClientPC/.env-ல் கீழ்கண்டவற்றை சரியாக அமைக்கவும்:

- Central Funnel HTTPS URL
- Company ID
- அந்த PC-க்கு தனித்த Client ID
- Company sync token
- அந்த Client ID-க்கு உரிய node token
- LAN API token

START_CLIENT_PC.bat இயக்கவும். Android app-ன் optional LAN settings-ல் Client PC-யின் Wi-Fi IP மற்றும் LAN API token-ஐ உள்ளிடவும். Windows Firewall-ல் TCP 5100-ஐ trusted Private network-க்கு மட்டும் அனுமதிக்கவும்; Public network-க்கு திறக்க வேண்டாம்.

Client PC Central-ஐ முதன்முதலில் தொடர்பு கொண்ட பிறகு அது Super Admin-ன் “Schedules & Client Access” பக்கத்தில் தோன்றும். அந்த PC-க்கு schedule உருவாக்க அனுமதி தேவைப்பட்டால் Super Admin அங்கே permission enable செய்ய வேண்டும். Menu மறைப்பதுடன், Central API-யிலும் permission மீண்டும் சரிபார்க்கப்படுகிறது.

### V22 QR Scanner Crop Fix

- CameraX analysis image-இல் இருந்து preview viewport-ன் crop rectangle-ஐ நேரடியாக bitmap-ஆக வெட்டி, upright square-ஐ மட்டும் ML Kit scan செய்யும். இனி camera/preview coordinate மாற்றம் தேவையில்லை; detected QR bounds அதே square coordinates-ல் சரிபார்க்கப்படும்.
- QR முழுவதும் scan square-க்குள் இருந்தால் மட்டுமே ஏற்கப்படும்; `RTI-` checkpoint token-களே checkpoint validation-க்கு செல்லும்.

### V20 Scan, Company ID மற்றும் Client PC Access

- Camera preview மற்றும் QR analysis ஒரே CameraX viewport-ஐப் பயன்படுத்தும். முழு QR code scan square-க்குள் இருந்தால்தான் ஏற்கப்படும்; square-க்கு வெளியே இருந்தால் app வழிகாட்டும்.
- Setup/testing-க்காக monitor அல்லது phone screen-ல் காட்டப்படும் valid RTI QR-களையும் scan செய்யலாம். Checkpoint assignment மற்றும் server validation தொடர்ந்து பொருந்தும்.
- Central Web → Companies → Company Directory-ல் numeric Company ID தெளிவாகக் காட்டப்படும்; Copy ID button மூலம் Client PC Setup-ல் ஒட்டலாம். Company Code வேறு என்பதை setup விளக்குகிறது.
- INSTALL_SETUP ஒவ்வொரு PC-க்கும் நிலையான unique Client PC ID உருவாக்கும்; Setup page-ல் ID read-only-ஆகவும் copy வசதியுடனும் இருக்கும்.
- Super Admin registered Client PC பெயரை மாற்றலாம், access block/enable செய்யலாம், schedule edit permission வழங்கலாம் அல்லது நீக்கலாம். Block ஆன PC-யின் அடுத்த API கோரிக்கைகள் மறுக்கப்படும்; scan history இருக்கும்.
- Android LAN check, app company ID மற்றும் Client PC company ID வேறானால் mismatch எனத் தெளிவாகக் காட்டும்.

### V19 பயன்பாடு, Device Access மற்றும் Live Update

- Android Settings தனி screen-ல் திறக்கும்; ஆரம்ப local password `1234`. Online inspector login வெற்றியடைந்த பின் Settings screen-ல் password மாற்றலாம்.
- Login மற்றும் Settings text field-கள் keyboard திறந்தாலும் scroll செய்து பார்க்கக்கூடியதாக இருக்கும்.
- QR scan screen-ல் camera preview square-க்குள் மட்டும் தெரியும்; வெளியே முழுவதும் black. QR முழுவதும் square-க்குள் இருந்தால்தான் scan ஏற்கப்படும்.
- Super Admin Device Access பக்கத்தில் Device ID மாற்றலாம், access block/restore செய்யலாம், soft-remove செய்யலாம், குறிப்பிட்ட inspector-களுக்கு மட்டும் அனுமதி வழங்கலாம். பழைய scan history பாதுகாக்கப்படும்.
- Client PC monitor மூன்று வினாடிக்கு ஒருமுறை புதுப்பிக்கும்; tab-க்கு திரும்பும்போது உடனே refresh ஆகும். Central Scan History idle நிலையில் தானாகவும், manual button மூலமும் புதுப்பிக்கும்.
- Super Admin QR scan இடைவெளியையும் ஒவ்வொரு schedule-ன் grace period-ஐயும் மாற்றலாம்.

### V18 பயன்பாடு மற்றும் தேடல்

- Login பக்கம் navy/blue branded design மற்றும் உயர்த்தப்பட்ட card style-ல் உள்ளது.
- QR scanner-ல் square camera area மட்டும் தெரியும்; வெளியே black ஆக இருக்கும். QR முழுமையாக அந்த square-க்குள் இருந்தால் மட்டுமே scan ஏற்கப்படும்.
- Scan History, Reports, Audit Logs-ல் date range, category, name, code, ID, device, schedule ஆகியவற்றைத் தேர்ந்தெடுக்கவும் அல்லது type செய்து தேடவும்.
- Company ID / Client PC ID சேமித்த பின்பும் Central sync 401/403 என்றால் installed master folder-ல் `REPAIR_SYNC_TOKENS.bat` இயக்கவும். இது private `.env` backups உருவாக்கி matching credentials-ஐ சரிசெய்யும்; database-ஐ மாற்றாது. பிறகு `STOP_ALL.bat`, `START_ALL.bat` மூலம் services-ஐ restart செய்யவும்.

### Android offline செயல்பாடு

முதல் முறையாக Android-ல் Internet மூலம் login செய்து checkpoints மற்றும் schedules-ஐ download செய்யவும். அதன் பிறகு:

- Offline login, device-ல் பாதுகாப்பாகச் சேமித்துள்ள அதே Inspector credentials-ஐ மட்டுமே பயன்படுத்தும்.
- Password Android Keystore மூலம் encrypt செய்யப்படுகிறது.
- Offline QR scan-க்கு, கடைசியாக download செய்யப்பட்ட checkpoint list பயன்படும்.
- ஒவ்வொரு event-க்கும் unique ID, device time, inspector, device, checkpoint, session key சேர்க்கப்படும்.
- Online கிடைத்தால் Central-க்கு sync; இல்லையெனில் configured LAN Client PC-க்கு sync; இரண்டும் கிடைக்காவிட்டால் Android local queue-ல் சேமிப்பு.
- Sync முடியும் வரை Android மற்றும் Client PC தனித்தனி local records வைத்திருக்கலாம். Internet/LAN இல்லாத நேரத்தில் Central-க்கு உடனடி update அல்லது alert செல்ல முடியாது.
- Server time மற்றும் device time தனித்தனியாக சேமிக்கப்படும். Device clock மாறியிருக்கலாம் எனத் தெரிந்தால் Android warning காட்டும்.
- Android recurring schedule reminders local notification ஆக வரும். App notification permission வழங்கப்பட வேண்டும்; Android battery settings alarm நேரத்தை தாமதப்படுத்தலாம்.

### GitHub Actions APK build

Project files-ஐ GitHub repository root-ல் upload செய்யவும். Actions → “Build AB Securitas Real Time Inspector APK” → Run workflow தேர்ந்தெடுக்கவும். Funnel domain APK build நேரத்தில் தேவையில்லை; Android app-ல் Connection Settings பகுதியில் ஒருமுறை உள்ளிட்டு சேமிக்கவும். Workflow APK-ஐ build செய்து artifact ஆக வழங்கும். GitHub Actions server hosting செய்யாது; cloud VM சேவையை தனியாக இயக்க வேண்டும்.

## English reference

### Runtime behavior

Central owns the schedule and inspection history. Each device keeps local data so inspectors can continue without an internet connection. Android tries the Central HTTPS API first, the configured Client PC LAN address second, and its local queue last. The Client PC keeps LAN submissions in SQLite and forwards them to Central using its private node token.

An offline device cannot deliver a live alert to Central while disconnected. It preserves the event time and Central records the receive time after retry. Cached login, checkpoints, schedule data, and permissions can be stale until a successful sync.

### Schedule permissions

The Super Admin creates schedules and sees Client PCs after their first authenticated sync. Schedule editing starts disabled for every new Client PC. The Super Admin enables or revokes permission per client node. Client PC UI visibility is only a convenience; Central checks the node token and permission again on every schedule mutation.

Existing Super Admin schedules remain active when a Client PC permission is revoked. The client can still receive assigned schedules and submit inspections.

### Service and backup commands

~~~text
sudo systemctl status rti-web rti-proxy rti-funnel
sudo systemctl restart rti-web rti-proxy
sudo tailscale funnel status
sudo systemctl status rti-backup.timer
~~~

The database is at /var/lib/ab-securitas-rti/inspector.db. Set the separate backup directory in the Super Admin Database Backups page; daily backup files are retained and are never removed automatically. Copy backups to another machine or drive for recovery from VM or disk loss.

Windows Central: use the Super Admin **Database Backups** page to choose a dedicated folder outside the live data folder, make an immediate backup, and review earlier copies. Client PC: open `http://127.0.0.1:5100/setup` to choose its own backup folder, run IP Check, and create/copy the private Android LAN passkey.

### Important operating limit

Free compute allocation, account eligibility, capacity, and continuous availability are controlled by the cloud provider. The application package cannot create an account, reserve a VM, configure a tailnet policy, approve Funnel, or push itself to GitHub. Those setup steps require the owner's accounts and credentials.
