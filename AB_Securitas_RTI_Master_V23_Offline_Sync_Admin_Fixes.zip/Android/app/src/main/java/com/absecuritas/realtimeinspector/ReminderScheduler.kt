package com.absecuritas.realtimeinspector

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import java.util.Calendar

object ReminderScheduler {
    private const val PREFS = "rti_mobile"
    private const val SCHEDULES_KEY = "cached_schedules"
    private const val ALARM_IDS_KEY = "scheduled_alarm_ids"
    private const val CHANNEL_ID = "inspection_schedule"

    fun update(context: Context, schedules: JSONArray) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(SCHEDULES_KEY, schedules.toString()).apply()
        cancelPrevious(context, prefs.getString(ALARM_IDS_KEY, "") ?: "")
        val alarmIds = mutableListOf<Int>()
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        for (index in 0 until schedules.length()) {
            val schedule = schedules.optJSONObject(index) ?: continue
            val scheduleId = schedule.optInt("id", index + 1)
            val time = schedule.optString("schedule_time")
            val pieces = time.split(":")
            if (pieces.size != 2) continue
            val hour = pieces[0].toIntOrNull() ?: continue
            val minute = pieces[1].toIntOrNull() ?: continue
            val days = schedule.optJSONArray("days") ?: JSONArray()
            val allowedDays = (0 until days.length()).map { days.optString(it).uppercase() }.toSet()
            for (offset in 0..14) {
                val calendar = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, offset)
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                val day = when (calendar.get(Calendar.DAY_OF_WEEK)) {
                    Calendar.MONDAY -> "MON"
                    Calendar.TUESDAY -> "TUE"
                    Calendar.WEDNESDAY -> "WED"
                    Calendar.THURSDAY -> "THU"
                    Calendar.FRIDAY -> "FRI"
                    Calendar.SATURDAY -> "SAT"
                    else -> "SUN"
                }
                if (day !in allowedDays || calendar.timeInMillis <= now) continue
                val requestCode = (scheduleId * 1000 + calendar.get(Calendar.DAY_OF_YEAR)) and 0x7fffffff
                alarmIds.add(requestCode)
                val intent = Intent(context, ScheduleAlarmReceiver::class.java).apply {
                    putExtra("schedule_id", scheduleId)
                    putExtra("schedule_name", schedule.optString("name", "Inspection"))
                    putExtra("schedule_time", time)
                }
                val pending = PendingIntent.getBroadcast(
                    context, requestCode, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pending)
            }
        }
        prefs.edit().putString(ALARM_IDS_KEY, alarmIds.joinToString(",")).apply()
        createChannel(context)
    }

    fun restore(context: Context) {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(SCHEDULES_KEY, null) ?: return
        try {
            update(context, JSONArray(raw))
        } catch (_: Exception) {
        }
    }

    private fun cancelPrevious(context: Context, rawIds: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        rawIds.split(",").forEach { raw ->
            val id = raw.toIntOrNull() ?: return@forEach
            val pending = PendingIntent.getBroadcast(
                context, id, Intent(context, ScheduleAlarmReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pending != null) alarmManager.cancel(pending)
        }
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Inspection reminders", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Scheduled checkpoint inspection reminders"
            }
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    fun show(context: Context, id: Int, title: String, time: String) {
        createChannel(context)
        val scheduleId=id
        val openApp = PendingIntent.getActivity(
            context, id, Intent(context, MainActivity::class.java).apply {
                flags=Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("start_scheduled_inspection",true)
                putExtra("schedule_id",scheduleId)
                putExtra("schedule_name",title)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Inspection due: $title")
            .setContentText("Scheduled at $time · Tap here to start this inspection")
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, notification)
    }
}

class ScheduleAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.show(
            context,
            intent.getIntExtra("schedule_id", 0),
            intent.getStringExtra("schedule_name") ?: "Inspection",
            intent.getStringExtra("schedule_time") ?: ""
        )
        ReminderScheduler.restore(context)
    }
}

class ScheduleBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) ReminderScheduler.restore(context)
    }
}
