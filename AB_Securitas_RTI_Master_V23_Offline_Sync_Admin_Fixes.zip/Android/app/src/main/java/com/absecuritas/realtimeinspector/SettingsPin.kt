package com.absecuritas.realtimeinspector

import android.content.Context
import java.security.MessageDigest

/** Local convenience lock for connection settings; inspector login remains the account security boundary. */
object SettingsPin {
    private const val PREFS = "rti_mobile"
    private const val HASH_KEY = "settings_pin_sha256"
    private const val DEFAULT_PIN = "1234"

    fun verify(context: Context, candidate: String): Boolean {
        if (!candidate.matches(Regex("\\d{4,8}"))) return false
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(HASH_KEY, "").orEmpty()
        val expected = if (saved.isBlank()) digest(DEFAULT_PIN) else saved
        return MessageDigest.isEqual(expected.toByteArray(Charsets.US_ASCII), digest(candidate).toByteArray(Charsets.US_ASCII))
    }

    fun update(context: Context, candidate: String): Boolean {
        if (!candidate.matches(Regex("\\d{4,8}"))) return false
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(HASH_KEY, digest(candidate)).apply()
        return true
    }

    private fun digest(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
