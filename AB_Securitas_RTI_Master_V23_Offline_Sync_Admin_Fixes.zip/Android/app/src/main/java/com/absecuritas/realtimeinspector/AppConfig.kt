package com.absecuritas.realtimeinspector

import android.content.Context
import java.net.URI
import java.util.Locale

/** Runtime configuration for the Central mobile API. */
object AppConfig {
    private const val PREFS_NAME = "rti_mobile"
    private const val SERVER_URL_KEY = "server_base_url"

    /** An optional build-time default; the inspector can configure this in the app. */
    @Volatile
    var SERVER_BASE_URL: String = BuildConfig.SERVER_BASE_URL.trimEnd('/')
        private set

    fun load(context: Context) {
        val saved = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(SERVER_URL_KEY, "")
            .orEmpty()
            .trim()
        SERVER_BASE_URL = (saved.ifBlank { BuildConfig.SERVER_BASE_URL }).trimEnd('/')
    }

    fun saveServerBaseUrl(context: Context, url: String) {
        val normalized = normalizeServerUrl(url)
            ?: throw IllegalArgumentException("Invalid Tailscale Funnel URL")
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(SERVER_URL_KEY, normalized)
            .apply()
        SERVER_BASE_URL = normalized
    }

    /** Accepts a host or HTTPS origin, but never a route, credential, or non-Funnel host. */
    fun normalizeServerUrl(raw: String): String? {
        val value = raw.trim().trimEnd('/')
        if (value.isBlank()) return null
        val candidate = if (value.contains("://")) value else "https://$value"
        return try {
            val uri = URI(candidate)
            val host = uri.host?.lowercase(Locale.US) ?: return null
            if (!uri.scheme.equals("https", ignoreCase = true) || !host.endsWith(".ts.net") ||
                uri.userInfo != null || (uri.port != -1 && uri.port != 443) ||
                (uri.path.isNotEmpty() && uri.path != "/") || uri.query != null || uri.fragment != null) {
                return null
            }
            "https://$host"
        } catch (_: Exception) {
            null
        }
    }
}
