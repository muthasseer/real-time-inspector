import java.net.URI

plugins {
    id("com.android.application")
}

// Optional default only. Inspectors can enter and save the Funnel domain in the app.
val configuredFunnelUrl = providers.gradleProperty("funnelUrl").orNull?.trim()?.trimEnd('/').orEmpty()
if (configuredFunnelUrl.isNotBlank()) {
    val parsedFunnelUrl = try {
        URI(configuredFunnelUrl)
    } catch (e: Exception) {
        throw GradleException("funnelUrl is not a valid URL", e)
    }
    val funnelHost = parsedFunnelUrl.host?.lowercase().orEmpty()
    if (!parsedFunnelUrl.scheme.equals("https", ignoreCase = true) || !funnelHost.endsWith(".ts.net") ||
        parsedFunnelUrl.userInfo != null || (parsedFunnelUrl.port != -1 && parsedFunnelUrl.port != 443) ||
        (parsedFunnelUrl.path.isNotEmpty() && parsedFunnelUrl.path != "/") || parsedFunnelUrl.query != null || parsedFunnelUrl.fragment != null) {
        throw GradleException("funnelUrl must be a Tailscale Funnel HTTPS origin, e.g. https://device.tailnet.ts.net")
    }
}
val escapedFunnelUrl = configuredFunnelUrl.replace("\\", "\\\\").replace("\"", "\\\"")
val persistentKeyStorePath = providers.environmentVariable("RTI_ANDROID_KEYSTORE_PATH").orNull?.takeIf { it.isNotBlank() }

android {
    namespace = "com.absecuritas.realtimeinspector"
    compileSdk = 36

    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        buildConfigField("String", "SERVER_BASE_URL", "\"$escapedFunnelUrl\"")
        applicationId = "com.absecuritas.realtimeinspector"
        minSdk = 23
        targetSdk = 36
        versionCode = 27
        versionName = "23.0.0"
    }

    signingConfigs {
        if (persistentKeyStorePath != null) {
            create("rtiPersistent") {
                storeFile = file(persistentKeyStorePath)
                storePassword = providers.environmentVariable("RTI_ANDROID_KEYSTORE_PASSWORD").orNull.orEmpty()
                keyAlias = providers.environmentVariable("RTI_ANDROID_KEY_ALIAS").orNull.orEmpty()
                keyPassword = providers.environmentVariable("RTI_ANDROID_KEY_PASSWORD").orNull.orEmpty()
            }
        }
    }

    buildTypes {
        debug {
            if (persistentKeyStorePath != null) signingConfig = signingConfigs.getByName("rtiPersistent")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.activity:activity-ktx:1.12.3")

    // CameraX stable 1.5.3
    implementation("androidx.camera:camera-core:1.5.3")
    implementation("androidx.camera:camera-camera2:1.5.3")
    implementation("androidx.camera:camera-lifecycle:1.5.3")
    implementation("androidx.camera:camera-view:1.5.3")

    // Bundled ML Kit barcode model: available immediately after install.
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
}
