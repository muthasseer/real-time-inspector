# AB Securitas Real Time Inspector Android V23.0

- CameraX with the bundled ML Kit QR model.
- Inspector authentication uses the Central Inspectors account, not the web Super Admin account.
- Successful online sign-in caches an encrypted credential and checkpoint data for later offline use.
- A local SQLite store keeps inspection events and retry status. Internet is attempted first, then the optional Client PC LAN API, then the device queue remains until connectivity returns.
- Recurring schedule reminders are restored after device reboot. Android notification permission is required.
- Offline event time is device-reported; Central records the later server receive time separately.
- The Funnel origin is not embedded in the APK; it is saved from the app's Company Server Domain field. LAN URL and token are also configured in the app.
- Connection settings are under the gear icon. The app displays Internet, Central, Client PC/LAN, sync, and queued-record status while running, and sends a notification when those states change (notification permission required).
- The login screen uses a branded navy/blue layout. During inspection, only the framed camera square is visible; CameraX crops the same viewport square shown by the preview, rotates that crop upright, and gives only those pixels to ML Kit; QR bounds are checked directly inside that image.
- Android Settings open on a separate page protected by the default local PIN `1234`. After an online inspector login, the Settings page allows changing that PIN.
- Login and Settings fields remain reachable when the software keyboard is open.
- Super Admin device controls can change IDs, block, restore, remove, and restrict a device to selected inspectors while preserving prior scan history.
- Client PC monitor and Central History update automatically; schedule grace periods and QR scan spacing are configurable by Super Admin.
- Offline repeats use the locally saved inspection history: scan two is marked Repeat and later scans trigger Repeat Alert; records still queue for sync.
- LAN diagnostics distinguish a reachable Client PC from Central authentication failures and give clearer connection error messages.
- VersionCode 27 / versionName 23.0.0. The V22 QR scanner implementation is unchanged.

See the repository's MASTER_ARCHITECTURE_TAMIL_EN.md and ANDROID_GITHUB_BUILD_TAMIL.md.
