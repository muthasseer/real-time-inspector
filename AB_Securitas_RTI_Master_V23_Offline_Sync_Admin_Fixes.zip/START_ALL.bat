@echo off
setlocal
cd /d "%~dp0"

echo ==================================================
echo AB SECURITAS RTI - ONE-CLICK START
echo ==================================================

if not exist Web\.venv\Scripts\python.exe goto :setup
if not exist Web\.env goto :setup
if not exist ClientPC\.env goto :setup
Web\.venv\Scripts\python.exe -c "import flask, dotenv" >nul 2>nul
if errorlevel 1 goto :setup
goto :launch

:setup
echo First-time setup or a missing dependency was detected.
echo Installing the app requirements before starting the services...
set "RTI_INSTALL_NO_PAUSE=1"
call INSTALL_SETUP.bat
set "RTI_SETUP_RESULT=%ERRORLEVEL%"
set "RTI_INSTALL_NO_PAUSE="
if not "%RTI_SETUP_RESULT%"=="0" goto :failed

:launch
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "scripts\start_all.ps1"
if errorlevel 1 goto :failed
exit /b 0

:failed
echo.
echo One-click startup could not complete. Read the message above.
pause
exit /b 1
