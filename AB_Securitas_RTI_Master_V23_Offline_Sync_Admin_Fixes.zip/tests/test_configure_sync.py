import os
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SOURCE_ROOT = Path(__file__).resolve().parents[1]


def read_env(path):
    values = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    return values


class ConfigureSyncTests(unittest.TestCase):
    def make_project(self, company_id="4", client_id=""):
        temporary = tempfile.TemporaryDirectory(prefix="ab-rti-sync-setup-")
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "scripts").mkdir()
        (root / "Web").mkdir()
        (root / "ClientPC").mkdir()
        (root / "scripts" / "configure_sync.py").write_bytes((SOURCE_ROOT / "scripts" / "configure_sync.py").read_bytes())
        (root / "Web" / ".env").write_text(
            "RTI_CLIENT_SYNC_TOKENS=\nRTI_CLIENT_NODE_TOKENS=\n", encoding="utf-8"
        )
        (root / "ClientPC" / ".env").write_text(
            "RTI_COMPANY_ID=" + company_id + "\n"
            "RTI_CLIENT_ID=" + client_id + "\n"
            "RTI_CLIENT_SYNC_TOKEN=CHANGE-TO-A-LONG-RANDOM-SYNC-TOKEN\n"
            "RTI_CLIENT_NODE_TOKEN=CHANGE-TO-A-LONG-RANDOM-NODE-TOKEN\n"
            "RTI_LAN_API_TOKEN=CHANGE-TO-A-LONG-RANDOM-LAN-TOKEN\n",
            encoding="utf-8",
        )
        return root

    def run_setup(self, root):
        return subprocess.run(
            [sys.executable, str(root / "scripts" / "configure_sync.py")],
            cwd=root, text=True, capture_output=True, check=False,
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )

    def test_first_setup_generates_stable_client_id_and_matching_credentials(self):
        root = self.make_project()
        first = self.run_setup(root)
        self.assertEqual(first.returncode, 0, first.stderr)
        client = read_env(root / "ClientPC" / ".env")
        central = read_env(root / "Web" / ".env")
        client_id = client["RTI_CLIENT_ID"]
        self.assertRegex(client_id, r"^CLIENT-[0-9A-F]{8}$")
        self.assertIn("Generated Client PC ID: " + client_id, first.stdout)
        self.assertEqual(client["RTI_CLIENT_SYNC_TOKEN"], dict(item.split(":", 1) for item in central["RTI_CLIENT_SYNC_TOKENS"].split(";"))["4"])
        self.assertEqual(client["RTI_CLIENT_NODE_TOKEN"], dict(item.split(":", 1) for item in central["RTI_CLIENT_NODE_TOKENS"].split(";") )["4/" + client_id])
        self.assertTrue(client["RTI_LAN_API_TOKEN"])
        self.assertNotIn(client["RTI_CLIENT_NODE_TOKEN"], first.stdout)

        second = self.run_setup(root)
        self.assertEqual(second.returncode, 0, second.stderr)
        client_after = read_env(root / "ClientPC" / ".env")
        self.assertEqual(client_after["RTI_CLIENT_ID"], client_id)
        self.assertEqual(client_after["RTI_CLIENT_NODE_TOKEN"], client["RTI_CLIENT_NODE_TOKEN"])

    def test_existing_client_id_is_preserved(self):
        root = self.make_project(client_id="OFFICE-PC-7")
        result = self.run_setup(root)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(read_env(root / "ClientPC" / ".env")["RTI_CLIENT_ID"], "OFFICE-PC-7")


if __name__ == "__main__":
    unittest.main()
