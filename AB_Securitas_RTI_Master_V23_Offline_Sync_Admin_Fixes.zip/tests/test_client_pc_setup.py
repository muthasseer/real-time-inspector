import atexit
import importlib.util
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


_CLIENT_TEST_ROOT = tempfile.TemporaryDirectory(prefix="ab-rti-client-setup-")
atexit.register(_CLIENT_TEST_ROOT.cleanup)
os.environ["RTI_COMPANY_ID"] = "4"
os.environ["RTI_CLIENT_ID"] = "CLIENT-TEST-0001"
os.environ["RTI_LAN_API_TOKEN"] = "lan-test-token"
os.environ["RTI_CLIENT_DATABASE_PATH"] = str(Path(_CLIENT_TEST_ROOT.name) / "client.db")
os.environ["RTI_CLIENT_BACKUP_DIR"] = str(Path(_CLIENT_TEST_ROOT.name) / "backups")

CLIENT_APP_PATH = Path(__file__).resolve().parents[1] / "ClientPC" / "app.py"
spec = importlib.util.spec_from_file_location("rti_client_pc_setup_test", CLIENT_APP_PATH)
client_pc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client_pc)


class ClientPCSetupTests(unittest.TestCase):
    def setUp(self):
        self.client = client_pc.app.test_client()

    def test_setup_shows_company_id_and_generated_read_only_client_id(self):
        response = self.client.get("/setup")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Company ID", response.data)
        self.assertIn(b"Company Directory", response.data)
        self.assertIn(b"Generated Client PC ID", response.data)
        self.assertIn(b"id=\"client\" class=\"key\" readonly", response.data)
        self.assertIn(b"copyClientId", response.data)
        info = self.client.get("/api/setup").get_json()
        self.assertEqual(info["company_id"], "4")
        self.assertEqual(info["client_id"], "CLIENT-TEST-0001")

    def test_setup_refuses_to_change_generated_client_id(self):
        response = self.client.post("/api/setup", json={
            "action": "save", "company_id": "4", "client_id": "CLIENT-MANUAL-2",
        })
        self.assertEqual(response.status_code, 400)
        self.assertIn("generated once", response.get_json()["message"])

    def test_company_change_requires_token_repair_and_service_restart(self):
        original_company_id = client_pc.COMPANY_ID
        try:
            with patch.object(client_pc, "_upsert_client_env") as save_env:
                response = self.client.post("/api/setup", json={
                    "action": "save", "company_id": "7", "client_id": "CLIENT-TEST-0001",
                })
            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.get_json()["restart_required"])
            self.assertIn("REPAIR_SYNC_TOKENS.bat", response.get_json()["message"])
            save_env.assert_called_once()
        finally:
            client_pc.COMPANY_ID = original_company_id

    def test_authenticated_lan_health_reports_numeric_company_and_client_ids(self):
        response = self.client.get(
            "/api/mobile/health", headers={"Authorization": "Bearer lan-test-token"},
        )
        self.assertEqual(response.status_code, 200, response.get_data(as_text=True))
        payload = response.get_json()
        self.assertEqual(payload["company_id"], 4)
        self.assertEqual(payload["client_id"], "CLIENT-TEST-0001")

    def test_lan_health_separates_central_reachability_from_token_auth(self):
        connection = client_pc.db()
        try:
            connection.execute(
                "INSERT OR REPLACE INTO client_cache(cache_key,cache_value) VALUES(?,?)",
                ("central_connection_status", '{"central_reachable":true,"node_auth":"FAILED","sync_auth":"OK","last_error":"HTTP 401"}'),
            )
            connection.commit()
        finally:
            connection.close()
        response = self.client.get("/api/mobile/health", headers={"Authorization": "Bearer lan-test-token"})
        payload = response.get_json()
        self.assertTrue(payload["central_reachable"])
        self.assertFalse(payload["central_authenticated"])
        self.assertEqual(payload["central_node_auth"], "FAILED")
        self.assertEqual(payload["central_sync_auth"], "OK")


if __name__ == "__main__":
    unittest.main()
