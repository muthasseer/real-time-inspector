# AB Securitas Real Time Inspector — Central API V15

The Central Flask application serves the admin dashboard and JSON API. On Windows, run python app.py for a local development instance. The default bind is 127.0.0.1:5000.

For Linux cloud deployment, use the systemd configuration under deploy/linux. The central database path is configurable with RTI_DATABASE_PATH; production uses persistent storage under /var/lib/ab-securitas-rti. Do not expose the dashboard to the public internet. The Tailscale Funnel endpoint is restricted to the allow-listed mobile proxy.

The first-run admin/admin123 password must be changed before normal use. Keep RTI_SECRET_KEY, client sync/node tokens, .env files, and the SQLite database private. Daily SQLite backups are configured by the Linux installer.
