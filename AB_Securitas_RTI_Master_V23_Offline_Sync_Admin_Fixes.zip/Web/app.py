
from flask import Flask, request, jsonify, render_template_string, session, redirect, url_for, flash, Response, send_file, abort
from functools import wraps
from datetime import datetime, date, timedelta, timezone
import sqlite3, os, csv, io, hashlib, secrets, hmac, html, re, sys, json, threading, time, tempfile
from pathlib import Path
from dotenv import load_dotenv

APP_VERSION = "23.0.0"
load_dotenv(Path(__file__).with_name(".env"))
app = Flask(__name__)
app.secret_key = os.environ.get("RTI_SECRET_KEY") or secrets.token_urlsafe(48)
if not os.environ.get("RTI_SECRET_KEY"):
    print("WARNING: RTI_SECRET_KEY is not set; a temporary key is in use and sessions will reset on restart.", file=sys.stderr)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
# The admin dashboard is served only on this PC over local HTTP.
app.config["SESSION_COOKIE_SECURE"] = os.getenv("RTI_COOKIE_SECURE", "0").strip().lower() in ("1", "true", "yes", "on")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
def default_data_directory():
    configured = os.getenv("RTI_DATA_DIR", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    if os.name == "nt":
        root = Path(os.getenv("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
        return (root / "AB Securitas" / "Real Time Inspector" / "data").resolve()
    root = Path(os.getenv("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
    return (root / "ab-securitas-rti").resolve()

DATA_DIR = default_data_directory()
DB = str(Path(os.getenv("RTI_DATABASE_PATH") or (DATA_DIR / "inspector.db")).expanduser().resolve())
DEFAULT_BACKUP_DIR = Path(os.getenv("RTI_BACKUP_DIR") or (Path(DB).parent / "backups")).expanduser().resolve()
Path(DB).parent.mkdir(parents=True, exist_ok=True)

DEFAULT_POINTS = [
    ("P01","POINT-01 Main Entrance"), ("P02","POINT-02 Front Gate"),
    ("P03","POINT-03 Parking Area"), ("P04","POINT-04 Back Entrance"),
    ("P05","POINT-05 Warehouse"), ("P06","POINT-06 Office Floor 1"),
    ("P07","POINT-07 Office Floor 2"), ("P08","POINT-08 Server Room"),
    ("P09","POINT-09 Emergency Exit"), ("P10","POINT-10 Loading Area"),
]

def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def path_is_within(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False

def client_sync_token(company_id):
    """Return the configured read-only sync token for exactly one company."""
    for entry in os.getenv("RTI_CLIENT_SYNC_TOKENS", "").split(";"):
        configured_company, separator, token = entry.partition(":")
        if separator and configured_company.strip() == str(company_id):
            return token.strip()
    return ""

# V13.2: one REPEAT is allowed per point; the next scan of the same point gives REPEAT_ALERT.
MAX_REPEATS = 1
# V13.2: minimum seconds between two NEW points in one inspection (blocks scanning pre-taken QR photos back to back). Set 0 to disable.
try:
    MIN_SECONDS_BETWEEN_POINTS = min(300, max(0, int(os.environ.get("RTI_MIN_POINT_GAP", "8"))))
except ValueError:
    MIN_SECONDS_BETWEEN_POINTS = 8


def minimum_point_gap(c):
    row = c.execute("SELECT setting_value FROM settings WHERE company_id=0 AND setting_key='min_point_gap_seconds'").fetchone()
    try:
        return min(300, max(0, int(row["setting_value"]))) if row else MIN_SECONDS_BETWEEN_POINTS
    except (TypeError, ValueError):
        return MIN_SECONDS_BETWEEN_POINTS

def conn():
    c = sqlite3.connect(DB, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c


def _copy_sqlite_database(source_path, destination_path):
    """Create and verify a consistent SQLite copy without modifying the source."""
    destination_path = Path(destination_path)
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination_path.with_name(destination_path.name + ".tmp")
    source = sqlite3.connect(f"file:{Path(source_path).resolve().as_posix()}?mode=ro", uri=True, timeout=30)
    target = sqlite3.connect(str(temporary), timeout=30)
    try:
        source.backup(target, pages=256, sleep=0.05)
        check = target.execute("PRAGMA quick_check").fetchone()[0]
        if check != "ok":
            raise sqlite3.DatabaseError("SQLite backup integrity check failed")
        target.commit()
    except Exception:
        target.close()
        source.close()
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise
    else:
        target.close()
        source.close()
    temporary.replace(destination_path)
    return destination_path


def migrate_legacy_database():
    """Move the active database out of the replaceable app folder, keeping both copies."""
    legacy = (Path(BASE_DIR) / "inspector.db").resolve()
    current = Path(DB).resolve()
    if current.exists() or not legacy.exists() or current == legacy:
        return
    stamp = datetime.now().strftime("%Y%m%dT%H%M%S.%f")
    legacy_copy = DEFAULT_BACKUP_DIR / f"central_before_data_folder_migration_{stamp}.db"
    _copy_sqlite_database(legacy, legacy_copy)
    _copy_sqlite_database(legacy, current)
    print(f"Migrated existing RTI database to persistent storage; original and backup kept: {current}")


def configured_backup_directory():
    """Use the Super Admin-selected location, then the environment/default folder."""
    try:
        c = conn()
        row = c.execute("SELECT setting_value FROM settings WHERE company_id=0 AND setting_key='backup_directory'").fetchone()
        c.close()
        if row and row["setting_value"].strip():
            return Path(row["setting_value"]).expanduser().resolve()
    except sqlite3.Error:
        pass
    return DEFAULT_BACKUP_DIR


_backup_lock = threading.Lock()


def create_database_backup(directory=None):
    """Write a timestamped SQLite backup file; never replace or prune older backups."""
    if not _backup_lock.acquire(blocking=False):
        raise RuntimeError("A database backup is already running")
    try:
        folder = Path(directory).expanduser().resolve() if directory else configured_backup_directory()
        if folder == Path(DB).resolve().parent or path_is_within(folder, Path(BASE_DIR).parent):
            raise ValueError("Choose a backup folder outside the live database and project folders")
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%dT%H%M%S.%f")
        destination = folder / f"central_{stamp}.db"
        return _copy_sqlite_database(DB, destination)
    finally:
        _backup_lock.release()


def restore_database_backup(name):
    """Restore a Central backup after making a fresh rollback backup."""
    folder = configured_backup_directory()
    if not re.fullmatch(r"central_[A-Za-z0-9_.-]+\.db", str(name or "")):
        raise ValueError("Choose a valid Central database backup")
    source_path = (folder / name).resolve()
    if source_path.parent != folder or not source_path.is_file() or source_path.resolve() == Path(DB).resolve():
        raise ValueError("The selected backup is not available in the configured backup folder")
    source = sqlite3.connect(f"file:{source_path.as_posix()}?mode=ro", uri=True, timeout=30)
    try:
        if source.execute("PRAGMA quick_check").fetchone()[0] != "ok":
            raise sqlite3.DatabaseError("The selected backup failed its integrity check")
        tables = {row[0] for row in source.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {"companies", "users", "scans"}.issubset(tables):
            raise sqlite3.DatabaseError("The selected file is not a complete Central database backup")
        rollback = create_database_backup(folder)
        if not _backup_lock.acquire(blocking=False):
            raise RuntimeError("A backup or restore is already running; retry in a moment")
        try:
            target = sqlite3.connect(DB, timeout=30)
            try:
                source.backup(target, pages=256, sleep=0.05)
                if target.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                    raise sqlite3.DatabaseError("Restored Central database failed its integrity check")
                target.commit()
            finally:
                target.close()
        finally:
            _backup_lock.release()
    finally:
        source.close()
    return rollback


def start_automatic_backup_worker():
    """Make a first backup and keep at least one new backup per day."""
    if getattr(app, "_rti_backup_worker_started", False):
        return
    app._rti_backup_worker_started = True

    def worker():
        while True:
            try:
                folder = configured_backup_directory()
                backups = list(folder.glob("central_*.db")) if folder.is_dir() else []
                newest = max((item.stat().st_mtime for item in backups), default=0)
                if not newest or time.time() - newest >= 24 * 60 * 60:
                    create_database_backup(folder)
            except Exception as exc:
                app.logger.warning("Automatic RTI database backup failed: %s", type(exc).__name__)
            time.sleep(60 * 60)

    threading.Thread(target=worker, name="rti-database-backup", daemon=True).start()

def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    rounds = 180000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), rounds).hex()
    return f"pbkdf2_sha256${rounds}${salt}${digest}"

def verify_password(password, stored):
    try:
        algo, rounds, salt, digest = stored.split("$", 3)
        test = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), int(rounds)).hex()
        return hmac.compare_digest(test, digest)
    except Exception:
        return False

# Reversible password storage is used only for the Super Admin's explicit
# password-reveal feature. Normal authentication continues to use PBKDF2 hashes.
def _secret_key():
    return hashlib.sha256(app.secret_key.encode("utf-8")).digest()

def protect_secret(value):
    if not value:
        return ""
    raw=value.encode("utf-8"); key=_secret_key()
    out=bytes(b ^ key[i % len(key)] for i,b in enumerate(raw))
    tag=hmac.new(key,out,hashlib.sha256).hexdigest()[:24]
    return tag+":"+out.hex()

def reveal_secret(value):
    try:
        tag, hx=value.split(":",1); raw=bytes.fromhex(hx); key=_secret_key()
        if not hmac.compare_digest(tag,hmac.new(key,raw,hashlib.sha256).hexdigest()[:24]): return None
        return bytes(b ^ key[i % len(key)] for i,b in enumerate(raw)).decode("utf-8")
    except Exception:
        return None

def table_columns(c, table):
    return {r["name"] for r in c.execute(f"PRAGMA table_info({table})").fetchall()}

def add_column_if_missing(c, table, column, definition):
    if column not in table_columns(c, table):
        c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

def ensure_device(c, company_id, device_id):
    """Register a device for a company. Returns an error message or None."""
    row = c.execute("SELECT * FROM devices WHERE device_id=?", (device_id,)).fetchone()
    if row:
        if row["status"] == "DELETED":
            return "This device was removed by the Super Admin. Ask the admin to restore access."
        if row["status"] != "ACTIVE":
            return "This device is blocked by the Super Admin. Ask the admin to enable access."
        if row["company_id"] != company_id:
            return "This device is already registered to another company"
        return None
    if "device_identifier" in table_columns(c, "devices"):
        c.execute("INSERT INTO devices(company_id,device_id,device_identifier,status,access_policy,created_at) VALUES(?,?,?,?,?,?)",
                  (company_id, device_id, device_id, "ACTIVE", "OPEN", now_str()))
    else:
        c.execute("INSERT INTO devices(company_id,device_id,status,access_policy,created_at) VALUES(?,?,?,?,?)",
                  (company_id, device_id, "ACTIVE", "OPEN", now_str()))
    return None

def undel(value):
    """Hide the internal '~del<id>' suffix added to soft-deleted unique names."""
    return re.sub(r"~del\d+$", "", value or "")

def audit(user_id, company_id, action, entity_type="", entity_id="", details=""):
    c = conn()
    try:
        c.execute("""INSERT INTO audit_logs(user_id, company_id, action, entity_type, entity_id, details, created_at)
                     VALUES (?,?,?,?,?,?,?)""",
                  (user_id, company_id, action, entity_type, str(entity_id), details, now_str()))
        c.commit()
    except Exception:
        c.rollback()
    finally:
        c.close()

def get_user():
    uid = session.get("user_id")
    if not uid:
        return None
    c = conn()
    row = c.execute("""SELECT u.*, c.name AS company_name, c.code AS company_code
                       FROM users u LEFT JOIN companies c ON c.id=u.company_id
                       WHERE u.id=? AND u.status='ACTIVE'
                         AND (u.role='SUPER_ADMIN' OR c.status='ACTIVE')""", (uid,)).fetchone()
    c.close()
    if not row:
        return None
    user = dict(row)
    # Password verifiers and recoverable credentials are never needed by page
    # handlers; keep them out of session-backed API responses such as /api/me.
    user.pop("password_hash", None)
    user.pop("password_secret", None)
    return user


@app.before_request
def protect_browser_mutations():
    """Require a session-bound CSRF token for browser form and API mutations."""
    if request.method in ("GET", "HEAD", "OPTIONS") or request.path.startswith(("/api/mobile/", "/api/client/")):
        if "_csrf_token" not in session:
            session["_csrf_token"] = secrets.token_urlsafe(32)
        return None
    expected = session.get("_csrf_token", "")
    supplied = request.headers.get("X-CSRFToken", "") or request.form.get("csrf_token", "")
    if not expected or not supplied or not hmac.compare_digest(str(expected), str(supplied)):
        if request.path.startswith("/api/"):
            return jsonify(ok=False, message="Your session security token is missing or expired. Refresh the page and try again."), 400
        abort(400, description="Your session security token is missing or expired. Refresh the page and try again.")
    return None

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = get_user()
        if not user:
            return redirect(url_for("login"))
        if user.get("must_change_password") and request.endpoint not in {
            "password_change_page", "api_me_password", "logout"
        }:
            if request.path.startswith("/api/"):
                return jsonify(ok=False, message="Change the first-run password before using the application."), 403
            return redirect(url_for("password_change_page"))
        return fn(*args, **kwargs)
    return wrapper

def roles_required(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            u = get_user()
            if not u:
                return redirect(url_for("login"))
            if u["role"] not in roles:
                return render_template_string(ERROR_HTML, user=u, message="Access denied"), 403
            return fn(*args, **kwargs)
        return wrapper
    return deco

def is_super(user=None):
    user = user or get_user()
    return bool(user and user["role"] == "SUPER_ADMIN")

def request_company_id(user, payload=None):
    payload = payload or {}
    if user["role"] != "SUPER_ADMIN":
        return user["company_id"]
    value = payload.get("company_id") or request.args.get("company_id")
    return int(value) if value and str(value).isdigit() else None

def current_license(company_id):
    if not company_id:
        return None
    c=conn(); row=c.execute("""SELECT * FROM licenses WHERE company_id=? AND status IN ('GENERATED','ACTIVE')
                               ORDER BY CASE WHEN status='ACTIVE' THEN 0 ELSE 1 END, id DESC LIMIT 1""",(company_id,)).fetchone(); c.close()
    if not row:
        return None
    d=dict(row)
    if d.get("status") == "ACTIVE" and d.get("expiry_date"):
        try:
            if datetime.fromisoformat(d["expiry_date"]) <= datetime.now():
                c=conn(); c.execute("UPDATE licenses SET status='EXPIRED' WHERE id=?",(d["id"],)); c.commit(); c.close(); d["status"]="EXPIRED"
        except ValueError:
            pass
    return d

def license_is_active(company_id):
    lic=current_license(company_id)
    return bool(lic and lic.get("status")=="ACTIVE" and lic.get("expiry_date") and datetime.fromisoformat(lic["expiry_date"]) > datetime.now())

def licensed_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        u=get_user()
        if not u:
            return redirect(url_for("login"))
        if u["role"] != "SUPER_ADMIN" and not license_is_active(u["company_id"]):
            if request.path.startswith("/api/"):
                return jsonify(ok=False, message="License is not active. Please activate a valid license."), 403
            return redirect(url_for("license_page"))
        return fn(*args, **kwargs)
    return wrapper

def init_db():
    c = conn()

    c.execute("""CREATE TABLE IF NOT EXISTS companies(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        code TEXT NOT NULL UNIQUE,
        address TEXT DEFAULT '',
        contact_person TEXT DEFAULT '',
        phone TEXT DEFAULT '',
        email TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        created_at TEXT NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER,
        username TEXT NOT NULL UNIQUE,
        full_name TEXT DEFAULT '',
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'COMPANY_ADMIN',
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        details TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(company_id) REFERENCES companies(id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS points(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        point_code TEXT NOT NULL,
        name TEXT NOT NULL,
        location TEXT DEFAULT '',
        description TEXT DEFAULT '',
        qr_token TEXT NOT NULL UNIQUE,
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        created_at TEXT NOT NULL,
        deleted_at TEXT,
        UNIQUE(company_id, point_code),
        FOREIGN KEY(company_id) REFERENCES companies(id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS inspectors(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        employee_id TEXT DEFAULT '',
        name TEXT NOT NULL,
        phone TEXT DEFAULT '',
        device_id TEXT DEFAULT '',
        login_username TEXT DEFAULT '',
        password_hash TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        created_at TEXT NOT NULL,
        FOREIGN KEY(company_id) REFERENCES companies(id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS devices(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        device_id TEXT NOT NULL UNIQUE,
        device_identifier TEXT NOT NULL UNIQUE,
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        created_at TEXT NOT NULL,
        deleted_at TEXT,
        FOREIGN KEY(company_id) REFERENCES companies(id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS scans(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER,
        point_id INTEGER,
        point_code TEXT,
        inspector_id INTEGER,
        inspector_name TEXT,
        device_id TEXT,
        scan_time TEXT NOT NULL,
        result TEXT NOT NULL,
        sync_source TEXT NOT NULL DEFAULT 'LIVE',
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(point_id) REFERENCES points(id),
        FOREIGN KEY(inspector_id) REFERENCES inspectors(id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS audit_logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        company_id INTEGER,
        action TEXT NOT NULL,
        entity_type TEXT DEFAULT '',
        entity_id TEXT DEFAULT '',
        details TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS settings(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER,
        setting_key TEXT NOT NULL,
        setting_value TEXT DEFAULT '',
        UNIQUE(company_id, setting_key)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS licenses(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        license_key TEXT NOT NULL UNIQUE,
        license_type TEXT NOT NULL,
        duration_days INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'GENERATED',
        issued_at TEXT NOT NULL,
        start_date TEXT,
        expiry_date TEXT,
        activated_at TEXT,
        activated_by INTEGER,
        created_by INTEGER,
        notes TEXT DEFAULT '',
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(activated_by) REFERENCES users(id),
        FOREIGN KEY(created_by) REFERENCES users(id)
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS mobile_sessions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        token TEXT NOT NULL UNIQUE,
        user_id INTEGER,
        inspector_id INTEGER,
        company_id INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        last_seen TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(inspector_id) REFERENCES inspectors(id),
        FOREIGN KEY(company_id) REFERENCES companies(id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS inspection_sessions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_token TEXT NOT NULL UNIQUE,
        company_id INTEGER NOT NULL,
        inspector_id INTEGER NOT NULL,
        device_id TEXT NOT NULL,
        started_at TEXT NOT NULL,
        ended_at TEXT,
        status TEXT NOT NULL DEFAULT 'ACTIVE',
        inspection_type TEXT NOT NULL DEFAULT 'MANUAL',
        schedule_id INTEGER,
        schedule_name TEXT NOT NULL DEFAULT '',
        scheduled_for TEXT NOT NULL DEFAULT '',
        checkpoint_ids TEXT NOT NULL DEFAULT '[]',
        FOREIGN KEY(company_id) REFERENCES companies(id),
        FOREIGN KEY(inspector_id) REFERENCES inspectors(id)
    )""")

    # Upgrade the original prototype schema safely.
    add_column_if_missing(c, "scans", "company_id", "INTEGER")
    add_column_if_missing(c, "scans", "point_code", "TEXT")
    add_column_if_missing(c, "scans", "inspector_id", "INTEGER")
    add_column_if_missing(c, "scans", "inspector_name", "TEXT")
    add_column_if_missing(c, "scans", "inspection_session_id", "INTEGER")
    add_column_if_missing(c, "scans", "repeat_count", "INTEGER DEFAULT 0")
    add_column_if_missing(c, "scans", "sync_source", "TEXT NOT NULL DEFAULT 'LIVE'")
    add_column_if_missing(c, "inspection_sessions", "inspection_type", "TEXT NOT NULL DEFAULT 'MANUAL'")
    add_column_if_missing(c, "inspection_sessions", "schedule_id", "INTEGER")
    add_column_if_missing(c, "inspection_sessions", "schedule_name", "TEXT NOT NULL DEFAULT ''")
    add_column_if_missing(c, "inspection_sessions", "scheduled_for", "TEXT NOT NULL DEFAULT ''")
    add_column_if_missing(c, "inspection_sessions", "checkpoint_ids", "TEXT NOT NULL DEFAULT '[]'")
    add_column_if_missing(c, "users", "details", "TEXT")
    add_column_if_missing(c, "users", "deleted_at", "TEXT")
    add_column_if_missing(c, "users", "password_secret", "TEXT DEFAULT ''" )
    add_column_if_missing(c, "users", "must_change_password", "INTEGER NOT NULL DEFAULT 0")
    add_column_if_missing(c, "companies", "deleted_at", "TEXT")
    add_column_if_missing(c, "inspectors", "deleted_at", "TEXT")
    add_column_if_missing(c, "inspectors", "device_id", "TEXT DEFAULT ''")
    add_column_if_missing(c, "inspectors", "login_username", "TEXT DEFAULT ''")
    add_column_if_missing(c, "inspectors", "password_hash", "TEXT DEFAULT ''")
    add_column_if_missing(c, "inspectors", "password_secret", "TEXT DEFAULT ''")
    add_column_if_missing(c, "inspectors", "permanently_deleted", "INTEGER NOT NULL DEFAULT 0")
    add_column_if_missing(c, "mobile_sessions", "inspector_id", "INTEGER")
    add_column_if_missing(c, "audit_logs", "user_id", "INTEGER")
    add_column_if_missing(c, "audit_logs", "company_id", "INTEGER")
    add_column_if_missing(c, "audit_logs", "action", "TEXT DEFAULT ''")
    add_column_if_missing(c, "audit_logs", "entity_type", "TEXT DEFAULT ''")
    add_column_if_missing(c, "audit_logs", "entity_id", "TEXT DEFAULT ''")
    add_column_if_missing(c, "audit_logs", "details", "TEXT DEFAULT ''")
    add_column_if_missing(c, "audit_logs", "created_at", "TEXT")

    # Upgrade legacy devices tables created by earlier versions.
    # CREATE TABLE IF NOT EXISTS does not change an existing SQLite table, so
    # explicitly add the V8 columns before the device backfill below.
    add_column_if_missing(c, "devices", "company_id", "INTEGER")
    add_column_if_missing(c, "devices", "device_id", "TEXT DEFAULT ''")
    add_column_if_missing(c, "devices", "status", "TEXT DEFAULT 'ACTIVE'")
    add_column_if_missing(c, "devices", "access_policy", "TEXT NOT NULL DEFAULT 'OPEN'")
    add_column_if_missing(c, "devices", "created_at", "TEXT")
    add_column_if_missing(c, "devices", "deleted_at", "TEXT")
    add_column_if_missing(c, "devices", "permanently_deleted", "INTEGER NOT NULL DEFAULT 0")
    # Some older builds used a required column named device_identifier. Keep it
    # synchronized with the new device_id column so old databases remain usable.
    device_cols = table_columns(c, "devices")
    if "device_identifier" in device_cols:
        c.execute("UPDATE devices SET device_id=COALESCE(NULLIF(TRIM(device_id),''),NULLIF(TRIM(device_identifier),''))")
        c.execute("UPDATE devices SET device_identifier=COALESCE(NULLIF(TRIM(device_identifier),''),NULLIF(TRIM(device_id),''))")
    c.execute("UPDATE devices SET status=COALESCE(NULLIF(TRIM(status),''),'ACTIVE')")
    c.execute("UPDATE devices SET created_at=COALESCE(NULLIF(TRIM(created_at),''),?)", (now_str(),))
    # Deleted inspectors must not block re-use of their User ID.
    c.execute("DROP INDEX IF EXISTS idx_inspector_login_username")
    c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_inspector_login_username_active ON inspectors(login_username) WHERE TRIM(COALESCE(login_username,''))!='' AND status!='DELETED'")
    # Free the unique names held by rows that were soft-deleted by earlier versions.
    c.execute("UPDATE users SET username=username||'~del'||id WHERE status='DELETED' AND username NOT LIKE '%~del%'")
    c.execute("UPDATE companies SET code=code||'~del'||id WHERE status='DELETED' AND code NOT LIKE '%~del%'")
    c.execute("UPDATE points SET point_code=point_code||'~del'||id WHERE status='DELETED' AND point_code NOT LIKE '%~del%'")
    # Original inspector_id was TEXT; SQLite permits retaining it while we use inspector_name
    # for legacy rows. New rows use the integer inspector_id column only if the DB was created fresh.
    c.execute("UPDATE scans SET point_code=COALESCE(point_code, CAST(point_id AS TEXT)) WHERE point_code IS NULL")
    c.execute("UPDATE scans SET inspector_name=COALESCE(inspector_name, CAST(inspector_id AS TEXT)) WHERE inspector_name IS NULL")

    # Fresh installation: keep the database clean and seed only the Super Admin.
    # Companies, users, inspectors and points are created from the Super Admin UI.
    c.execute("UPDATE companies SET name=code WHERE TRIM(COALESCE(name,''))=''")
    c.execute("UPDATE inspectors SET name=employee_id WHERE TRIM(COALESCE(name,''))='' AND TRIM(COALESCE(employee_id,''))!=''")
    c.execute("UPDATE points SET name=point_code WHERE TRIM(COALESCE(name,''))='' AND TRIM(COALESCE(point_code,''))!=''")

    # Backfill managed devices for legacy inspectors. New inspectors receive a
    # device automatically on their first mobile login; one physical device may
    # therefore be shared by multiple inspectors.
    for ir in c.execute("SELECT id,company_id,device_id FROM inspectors WHERE status!='DELETED'").fetchall():
        did=(ir["device_id"] or "").strip()
        if did:
            device_cols = table_columns(c, "devices")
            if "device_identifier" in device_cols:
                c.execute("INSERT OR IGNORE INTO devices(company_id,device_id,device_identifier,status,created_at) VALUES(?,?,?,?,?)",(ir["company_id"],did,did,"ACTIVE",now_str()))
            else:
                c.execute("INSERT OR IGNORE INTO devices(company_id,device_id,status,created_at) VALUES(?,?,?,?)",(ir["company_id"],did,"ACTIVE",now_str()))

    if c.execute("SELECT COUNT(*) n FROM users WHERE role='SUPER_ADMIN' AND status='ACTIVE'").fetchone()["n"] == 0:
        c.execute("INSERT INTO users(company_id,username,full_name,password_hash,password_secret,must_change_password,role,status,created_at) VALUES(NULL,?,?,?,?,?,?,?,?)",
                  ("admin","Super Admin",hash_password("admin123"),protect_secret("admin123"),1,"SUPER_ADMIN","ACTIVE",now_str()))

    # Force rotation of the published first-run credential, including databases
    # created by earlier releases that already contain the default admin row.
    bootstrap = c.execute("SELECT id,password_hash FROM users WHERE username='admin' AND role='SUPER_ADMIN' AND status='ACTIVE'").fetchone()
    if bootstrap and verify_password("admin123", bootstrap["password_hash"]):
        c.execute("UPDATE users SET must_change_password=1 WHERE id=?", (bootstrap["id"],))

    c.commit()
    c.close()

# ---------------------- HTML / UI ----------------------
STYLE = r"""
:root{--nav:#101d36;--nav2:#203556;--blue:#087eb8;--bg:#f3f6fa;--text:#172033;--muted:#718096;--line:#e5ebf3;--shadow:0 8px 28px #15264a0b}
*{box-sizing:border-box}html{scroll-padding-block:16px 40vh}body{margin:0;min-height:100vh;min-height:100dvh;font-family:Inter,Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--text)}
a{text-decoration:none;color:inherit}.app{display:flex;min-height:100vh}.side{width:252px;background:linear-gradient(180deg,#101d36,#162746);color:#dce6f7;padding:20px 14px;position:fixed;left:0;top:0;bottom:0;overflow:auto;z-index:20}
.brand{padding:8px 10px 20px;border-bottom:1px solid #2a3956;margin-bottom:14px}.brand b{display:block;color:#fff;font-size:20px}.brand small{color:#79c8ef;font-weight:800;letter-spacing:.3px}.brand span{display:block;margin-top:8px;font-size:12px;color:#9eabc0}
.nav a,.nav form button{display:block;width:100%;text-align:left;padding:11px 13px;border:0;border-radius:9px;margin:4px 0;color:#cbd5e7;font:inherit;font-size:14px;background:transparent;cursor:pointer}.nav a:hover,.nav a.active,.nav form button:hover{background:var(--nav2);color:#fff}.nav form{margin:0}
.main{margin-left:252px;width:calc(100% - 252px);padding:28px 34px}.top{display:flex;justify-content:space-between;gap:14px;align-items:center;margin-bottom:24px}.top h1{margin:0;font-size:26px;letter-spacing:-.025em}.top small{display:inline-block;color:var(--muted);margin-top:5px}.titlebar{display:flex;align-items:center;gap:12px}.user{background:#fff;border:1px solid var(--line);padding:9px 12px;border-radius:10px;font-size:13px;color:#46546a}.mobile-nav-toggle{display:none}
.cards{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin-bottom:18px}.card,.panel{background:#fff;border:1px solid var(--line);border-radius:13px;box-shadow:0 3px 15px #15264a0b}.card{padding:18px}.panel{padding:18px;margin-bottom:18px}.label{font-size:12px;color:#6d7a90;font-weight:800}.num{font-size:30px;font-weight:800;margin-top:7px}.sub{font-size:12px;color:#8a95a7;margin-top:4px}
.grid2{display:grid;grid-template-columns:1.55fr 1fr;gap:18px}.panel h2{font-size:16px;margin:0 0 15px;letter-spacing:-.01em}.tablewrap{overflow:auto;border-radius:8px}table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:11px;border-bottom:1px solid #edf1f6;white-space:nowrap}th{font-size:11px;color:#718096;text-transform:uppercase;letter-spacing:.045em}tbody tr:hover{background:#f8fafc}
.badge{display:inline-block;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:800}.green{background:#dff7e8;color:#168245}.red{background:#ffe3e3;color:#b3261e}.yellow{background:#fff1c7;color:#916a00}.gray{background:#eef1f5;color:#667085}.blue{background:#e2f2ff;color:#176aa0}
.progress{height:10px;background:#e9eef5;border-radius:99px;overflow:hidden}.bar{height:100%;background:var(--blue);border-radius:99px}.btn{border:0;border-radius:8px;padding:9px 13px;background:var(--blue);color:#fff;font-weight:700;cursor:pointer}.btn.dark{background:#172b4d}.btn.gray{background:#eef2f6;color:#26364f}.btn.red{background:#c83c3c;color:#fff}.toolbar{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}.field-label{display:block;margin:0;color:#667085;font-size:13px;font-weight:700;line-height:1.25}.field>label.muted,.field>label.field-label{display:block}.report-card{cursor:pointer;transition:.15s}.report-card:hover{transform:translateY(-2px);border-color:#168bd0}
input,select,textarea{padding:11px 12px;border:1px solid #d8e0eb;border-radius:8px;background:#fff;outline:none;font:inherit;width:100%;min-width:0}input:focus,select:focus,textarea:focus{border-color:#168bd0;box-shadow:0 0 0 3px #168bd01a}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid #168bd055;outline-offset:2px}textarea{min-height:80px;width:100%}.formgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.field{display:flex;flex-direction:column;gap:6px;min-width:0}.field.full{grid-column:1/-1}.formgrid>.field{width:100%}.toolbar .field{min-width:180px}.toolbar{align-items:flex-end}.full{grid-column:1/-1}.notice{padding:12px 14px;border:1px solid #dbeefe;border-radius:10px;background:#f0f8ff;color:#24527a;font-size:13px;margin-bottom:14px}
.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.mini{padding:15px;background:#f8fafc;border:1px solid var(--line);border-radius:10px}.mini b{font-size:21px}
.login{min-height:100vh;min-height:100dvh;display:grid;place-items:center;background:radial-gradient(ellipse at top right,#233e67 0,var(--nav) 55%)}.loginbox{width:min(420px,calc(100vw - 32px));background:#fff;border:1px solid #ffffff33;border-radius:18px;padding:34px;box-shadow:0 24px 80px #0004}.loginbox h1{margin:0 0 4px;letter-spacing:-.03em}.loginbox p{color:#718096;margin-top:5px}.loginbox input{width:100%;margin:7px 0;scroll-margin-block:16px 45vh}.loginbox .btn{width:100%;margin-top:10px}.flash{background:#ffe6e6;color:#9c2f2f;padding:10px;border-radius:8px;margin-bottom:10px}
.empty{text-align:center;color:#7b8798;padding:25px}.muted{color:#718096}.danger-text{color:#b3261e}
@media(max-width:1100px){.cards{grid-template-columns:repeat(3,1fr)}.grid2{grid-template-columns:1fr}}@media(max-width:750px){.side{width:min(84vw,310px);transform:translateX(-102%);transition:transform .2s ease;box-shadow:12px 0 35px #06132955}.side.open{transform:translateX(0)}.main{margin:0;width:100%;padding:18px 16px}.cards{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.card{padding:14px}.num{font-size:25px}.formgrid,.kpis{grid-template-columns:1fr}.top{align-items:flex-start}.top h1{font-size:22px}.mobile-nav-toggle{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border:1px solid var(--line);border-radius:10px;background:#fff;color:var(--text);font-size:19px;cursor:pointer}.user{font-size:12px}.panel{padding:15px}.toolbar .field{min-width:min(100%,220px)}}
@media(max-height:620px){.login{align-items:start;padding:16px 0}.loginbox{padding:24px}}
"""

def nav_html(user, active="dashboard"):
    links = [
        ("dashboard","▣","Dashboard","/"),
        ("companies","🏢","Companies","/companies"),
        ("points","📍","Check Points","/points"),
        ("inspectors","👮","Inspectors","/inspectors"),
        ("devices","📱","Device Access","/devices"),
        ("monitor","📡","Live Monitoring","/monitor"),
        ("history","📋","Scan History","/history"),
        ("reports","📊","Reports","/reports"),
    ]
    s = '<div class="side"><div class="brand"><b>AB SECURITAS</b><small>ELECTRONIC SECURITY DIVISION</small><span>REAL TIME INSPECTOR</span></div><div class="nav">'
    for key, icon, label, href in links:
        if key=="companies" and user["role"]!="SUPER_ADMIN":
            continue
        if key=="inspectors" and user["role"]!="SUPER_ADMIN":
            continue
        if key=="devices" and user["role"]!="SUPER_ADMIN":
            continue
        s += f'<a class="{"active" if key==active else ""}" href="{href}">{icon} {label}</a>'
    if user["role"]=="SUPER_ADMIN":
        s += '<a class="'+("active" if active=="schedules" else "")+'" href="/schedules">🗓 Schedules & Client Access</a>'
        s += '<a class="'+("active" if active=="backups" else "")+'" href="/backups">🛡 Database Backups</a>'
        s += '<a class="'+("active" if active=="users" else "")+'" href="/users">👤 Users & Roles</a>'
        s += '<a class="'+("active" if active=="licenses" else "")+'" href="/licenses">🔑 License Management</a>'
        s += '<a class="'+("active" if active=="audit" else "")+'" href="/audit">🔐 Audit Logs</a>'
        s += '<a class="'+("active" if active=="deleted" else "")+'" href="/deleted">🗑 Deleted History</a>'
    else:
        s += '<a class="'+("active" if active=="licenses" else "")+'" href="/licenses">🔑 License</a>'
    s += '<a class="'+("active" if active=="settings" else "")+'" href="/settings">⚙ Settings</a>'
    s += f'<form method="post" action="/logout"><input type="hidden" name="csrf_token" value="{html.escape(session.get("_csrf_token", ""), quote=True)}"><button type="submit">↪ Sign out</button></form></div></div>'
    return s

LABEL_SCRIPT = r"""
<script>
(function(){
 const labels={username:'Username',full_name:'Full Name',password:'Password',role:'User Role',company_id:'Company',details:'User Details',company_name:'Company Name',company_code:'Company Code',contact_person:'Contact Person',phone:'Phone',email:'Email',address:'Address',point_code:'Point Code',point_name:'Point Name',point_location:'Location',point_desc:'Description',employee_id:'Employee ID',inspector_name:'Inspector Name',device_id:'Device ID',search:'Search',result:'Result',reportType:'Report Type',reportCompany:'Company',start:'Start Date',end:'End Date',point:'Point Code',inspector:'Inspector',device:'Device ID',statusSelect:'Status',lic_company:'Company',lic_type:'License Type',lic_notes:'Notes / Payment Reference',license_key:'License Key',daily_target:'Daily Target Points',repeat_policy:'Repeat Policy',company_label:'Company Dashboard Label',notes:'Internal Notes',deletedSearch:'Search Deleted Records',companySelect:'Company'};
 function titleFor(el){return labels[el.id] || (el.getAttribute('aria-label')||el.getAttribute('placeholder')||el.id||'').replace(/\s*e\.g\..*$/i,'').replace(/\b(Optional|Select)\b/gi,'').trim()}
 document.querySelectorAll('input[id],select[id],textarea[id]').forEach(el=>{
   if(el.closest('.loginbox')) return;
   let parent=el.parentElement;
   let existing=parent.querySelector(':scope > label');
   if(existing){
     existing.classList.add('field-label');
     if(!parent.classList.contains('field')) parent.classList.add('field');
     return;
   }
   let text=titleFor(el); if(!text) return;
   const wrap=document.createElement('div'); wrap.className='field';
   parent.insertBefore(wrap,el); wrap.appendChild(el);
   const lab=document.createElement('label'); lab.className='field-label'; lab.htmlFor=el.id; lab.textContent=text;
   wrap.insertBefore(lab,el);
 });
 document.querySelectorAll('.formgrid > .full').forEach(el=>el.classList.add('full'));
 const navToggle=document.getElementById('navToggle'),nav=document.querySelector('.side');
 if(navToggle&&nav){navToggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');navToggle.setAttribute('aria-expanded',String(open));navToggle.textContent=open?'×':'☰'});nav.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{nav.classList.remove('open');navToggle.setAttribute('aria-expanded','false');navToggle.textContent='☰'}))}
 let focusedField=null;document.addEventListener('focusin',event=>{if(event.target.matches('input:not([type="hidden"]),textarea,select'))focusedField=event.target});document.addEventListener('focusout',event=>{if(event.target===focusedField)focusedField=null});if(window.visualViewport)window.visualViewport.addEventListener('resize',()=>{if(focusedField&&window.visualViewport.height<window.innerHeight*.82)setTimeout(()=>focusedField&&focusedField.scrollIntoView({block:'center',behavior:'smooth'}),80)});
})();
</script>
"""

PAGE_STATE_SCRIPT = r"""
<script>
(()=>{
 const key='rti.activePage';
  const paths=new Set(['/','/companies','/points','/inspectors','/devices','/monitor','/history','/reports','/schedules','/users','/licenses','/audit','/deleted','/settings','/backups','/account/password']);
 try{
  const navigation=performance.getEntriesByType('navigation')[0];
  const saved=sessionStorage.getItem(key);
  if(location.pathname==='/'&&navigation&&navigation.type==='reload'&&saved&&saved!=='/'&&paths.has(new URL(saved,location.origin).pathname)){location.replace(saved);return}
  if(paths.has(location.pathname))sessionStorage.setItem(key,location.pathname+location.search);
  document.querySelectorAll('.nav a').forEach(link=>link.addEventListener('click',()=>{const target=new URL(link.href,location.origin);if(target.origin===location.origin&&paths.has(target.pathname))sessionStorage.setItem(key,target.pathname+target.search)}));
 }catch(_){ }
})();
</script>
"""


def shell(title, body, user, active="dashboard"):
    return f"""<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="{html.escape(session.get('_csrf_token', ''), quote=True)}"><meta name="theme-color" content="#101d36">
<title>{title} — AB Securitas</title><style>{STYLE}</style><script>
window.rtiJsArg=value=>JSON.stringify(value).replace(/'/g,'\\u0027').replace(/\\u2028/g,'\\\\u2028').replace(/\\u2029/g,'\\\\u2029').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
(()=>{{const token=document.querySelector('meta[name="csrf-token"]').content;const original=window.fetch.bind(window);window.fetch=(resource,options={{}})=>{{const url=new URL(typeof resource==='string'?resource:resource.url,location.href);const method=(options.method||(typeof resource!=='string'&&resource.method)||'GET').toUpperCase();if(url.origin===location.origin&&!['GET','HEAD','OPTIONS'].includes(method)){{const headers=new Headers(options.headers||(typeof resource!=='string'?resource.headers:undefined));headers.set('X-CSRFToken',token);options={{...options,headers}}}}return original(resource,options)}}}})();
</script></head><body><div class="app">
{nav_html(user,active)}<main class="main"><div class="top"><div class="titlebar"><button class="mobile-nav-toggle" id="navToggle" type="button" aria-label="Toggle navigation" aria-expanded="false">☰</button><div><h1>{title}</h1><small>AB SECURITAS PVT LTD · Electronic Security Division</small></div></div>
<div class="user">{html.escape(user['full_name'] or '')} · {html.escape(user['role'])}</div></div>{body}{PAGE_STATE_SCRIPT}{LABEL_SCRIPT}</main></div></body></html>"""

LOGIN_HTML = f"""<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>AB Securitas — Login</title><style>{STYLE}</style></head><body>
<div class="login"><div class="loginbox"><h1>AB SECURITAS</h1><p>ELECTRONIC SECURITY DIVISION<br><b>REAL TIME INSPECTOR</b></p>
{{% with messages=get_flashed_messages() %}}{{% for msg in messages %}}<div class="flash">{{{{msg}}}}</div>{{% endfor %}}{{% endwith %}}
<form method="post"><input type="hidden" name="csrf_token" value="{{{{csrf_token}}}}"><label class="field-label" style="color:#718096">Username</label><input name="username" placeholder="Enter username" autocomplete="username" required><label class="field-label" style="color:#718096">Password</label><input name="password" type="password" placeholder="Enter password" autocomplete="current-password" required><button class="btn">Sign In</button></form>
</div></div></body></html>"""

ERROR_HTML = """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Error</title><style>{{style}}</style></head><body><div class="login"><div class="loginbox"><h1>Access Denied</h1><p>{{message}}</p><a class="btn" href="/">Back to Dashboard</a></div></div></body></html>""".replace("{{style}}", STYLE)

# ---------------------- Auth ----------------------
@app.route("/login", methods=["GET","POST"])
def login():
    current = get_user()
    if current:
        return redirect(url_for("password_change_page" if current.get("must_change_password") else "home"))
    if request.method=="POST":
        username=request.form.get("username","").strip()
        password=request.form.get("password","")
        c=conn(); u=c.execute("""SELECT u.* FROM users u LEFT JOIN companies co ON co.id=u.company_id
                               WHERE u.username=? AND u.status='ACTIVE'
                                 AND (u.role='SUPER_ADMIN' OR co.status='ACTIVE')""",(username,)).fetchone(); c.close()
        if u and verify_password(password,u["password_hash"]):
            session.clear(); session["user_id"]=u["id"]
            audit(u["id"],u["company_id"],"LOGIN","USER",u["id"],"Successful login")
            if u["must_change_password"]:
                return redirect(url_for("password_change_page"))
            if u["role"] != "SUPER_ADMIN" and not license_is_active(u["company_id"]):
                return redirect(url_for("license_page"))
            return redirect(url_for("home"))
        flash("Invalid username or password")
    return render_template_string(LOGIN_HTML, csrf_token=session.get("_csrf_token", ""))

@app.post("/logout")
def logout():
    u=get_user()
    if u: audit(u["id"],u["company_id"],"LOGOUT","USER",u["id"],"Logout")
    session.clear(); return redirect(url_for("login"))

# ---------------------- Pages ----------------------
@app.get("/")
@login_required
@licensed_required
def home():
    u=get_user()
    return shell("Security Inspection Dashboard", DASHBOARD_BODY, u, "dashboard")

@app.get("/companies")
@login_required
@roles_required("SUPER_ADMIN")
def companies_page():
    return shell("Companies", COMPANIES_BODY, get_user(), "companies")

@app.get("/licenses")
@login_required
def license_page():
    return shell("License Management" if get_user()["role"]=="SUPER_ADMIN" else "License Activation", LICENSE_BODY, get_user(), "licenses")

@app.get("/points")
@login_required
@licensed_required
def points_page():
    return shell("Check Points", POINTS_BODY, get_user(), "points")

@app.get("/inspectors")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def inspectors_page():
    return shell("Inspectors", INSPECTORS_BODY, get_user(), "inspectors")

@app.get("/devices")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def devices_page():
    return shell("Device Access", DEVICE_BODY, get_user(), "devices")

@app.get("/monitor")
@login_required
@licensed_required
def monitor_page():
    return shell("Live Monitoring", MONITOR_BODY, get_user(), "monitor")

@app.get("/history")
@login_required
@licensed_required
def history_page():
    return shell("Scan History", HISTORY_BODY, get_user(), "history")

@app.get("/reports")
@login_required
@licensed_required
def reports_page():
    return shell("Reports & Export", REPORTS_BODY, get_user(), "reports")

@app.get("/users")
@login_required
@roles_required("SUPER_ADMIN")
def users_page():
    return shell("Users & Roles", USERS_BODY, get_user(), "users")

@app.get("/audit")
@login_required
@roles_required("SUPER_ADMIN")
def audit_page():
    return shell("Audit Logs", AUDIT_BODY, get_user(), "audit")

@app.get("/deleted")
@login_required
@roles_required("SUPER_ADMIN")
def deleted_page():
    return shell("Deleted History", DELETED_BODY, get_user(), "deleted")

@app.get("/settings")
@login_required
@licensed_required
def settings_page():
    return shell("Settings", SETTINGS_BODY, get_user(), "settings")

@app.get("/backups")
@login_required
@roles_required("SUPER_ADMIN")
def backups_page():
    return shell("Database Backups", BACKUPS_BODY, get_user(), "backups")

@app.get("/account/password")
@login_required
def password_change_page():
    return shell("Change Password", PASSWORD_BODY, get_user(), "password")

# ---------------------- License APIs ----------------------
@app.get("/api/license")
@login_required
def api_license():
    u=get_user(); c=conn()
    if u["role"]=="SUPER_ADMIN":
        rows=c.execute("""SELECT l.*,co.name company_name,co.code company_code FROM licenses l
                          JOIN companies co ON co.id=l.company_id ORDER BY l.id DESC""").fetchall()
    else:
        rows=c.execute("""SELECT l.*,co.name company_name,co.code company_code FROM licenses l
                          JOIN companies co ON co.id=l.company_id WHERE l.company_id=? ORDER BY l.id DESC""",(u["company_id"],)).fetchall()
    c.close(); return jsonify([dict(r) for r in rows])

@app.post("/api/license/generate")
@login_required
@roles_required("SUPER_ADMIN")
def api_license_generate():
    d=request.get_json(silent=True) or {}
    try: cid=int(d.get("company_id"))
    except Exception: return jsonify(ok=False,message="Company is required"),400
    plan=str(d.get("license_type","3_MONTHS")).upper()
    plans={"1_DAY_TRIAL":("1 Day Trial",1),"3_MONTHS":("3 Months",90),"6_MONTHS":("6 Months",180),"1_YEAR":("1 Year",365)}
    if plan not in plans: return jsonify(ok=False,message="Invalid license type"),400
    c=conn(); co=c.execute("SELECT id,name,code FROM companies WHERE id=? AND status='ACTIVE'",(cid,)).fetchone()
    if not co: c.close(); return jsonify(ok=False,message="Company not found or disabled"),404
    key=f"RTI-{co['code']}-{secrets.token_hex(3).upper()}-{secrets.token_hex(3).upper()}-{secrets.token_hex(3).upper()}"
    label,days=plans[plan]
    c.execute("""INSERT INTO licenses(company_id,license_key,license_type,duration_days,status,issued_at,created_by,notes)
                 VALUES(?,?,?,?,?,?,?,?)""",(cid,key,label,days,"GENERATED",now_str(),get_user()["id"],d.get("notes","")))
    lid=c.execute("SELECT last_insert_rowid()").fetchone()[0]; c.commit(); c.close()
    audit(get_user()["id"],cid,"GENERATE","LICENSE",lid,f"{label} / {key}")
    return jsonify(ok=True,id=lid,license_key=key,license_type=label,duration_days=days)

@app.post("/api/license/activate")
@login_required
def api_license_activate():
    u=get_user()
    if u["role"]=="SUPER_ADMIN": return jsonify(ok=False,message="Super Admin does not need a client license"),400
    key=str((request.get_json(silent=True) or {}).get("license_key","")).strip().upper()
    if not key: return jsonify(ok=False,message="Enter a license key"),400
    c=conn(); row=c.execute("SELECT * FROM licenses WHERE license_key=? AND company_id=?",(key,u["company_id"])).fetchone()
    if not row: c.close(); return jsonify(ok=False,message="Invalid license key for this company"),400
    if row["status"]=="DISABLED": c.close(); return jsonify(ok=False,message="This license has been disabled"),400
    if row["status"]=="ACTIVE" and row["expiry_date"] and datetime.fromisoformat(row["expiry_date"]) > datetime.now():
        c.close(); return jsonify(ok=True,message="License already active",license=dict(row))
    if row["status"] not in ("GENERATED","EXPIRED"):
        c.close(); return jsonify(ok=False,message="License cannot be activated"),400
    # Only a newly generated license can be activated. Expired licenses must be newly generated by Super Admin.
    if row["status"]=="EXPIRED": c.close(); return jsonify(ok=False,message="This license is expired. Please request a new license."),400
    start=datetime.now(); expiry=start+timedelta(days=int(row["duration_days"]))
    c.execute("UPDATE licenses SET status='SUPERSEDED' WHERE company_id=? AND status='ACTIVE'",(u["company_id"],))
    c.execute("UPDATE licenses SET status='ACTIVE',start_date=?,expiry_date=?,activated_at=?,activated_by=? WHERE id=?",(start.strftime("%Y-%m-%d %H:%M:%S"),expiry.strftime("%Y-%m-%d %H:%M:%S"),now_str(),u["id"],row["id"]))
    c.commit(); updated=c.execute("SELECT * FROM licenses WHERE id=?",(row["id"],)).fetchone(); c.close()
    audit(u["id"],u["company_id"],"ACTIVATE","LICENSE",row["id"],key)
    return jsonify(ok=True,license=dict(updated))

@app.post("/api/license/<int:lid>/disable")
@login_required
@roles_required("SUPER_ADMIN")
def api_license_disable(lid):
    c=conn(); row=c.execute("SELECT * FROM licenses WHERE id=?",(lid,)).fetchone()
    if not row: c.close(); return jsonify(ok=False,message="License not found"),404
    c.execute("UPDATE licenses SET status='DISABLED' WHERE id=?",(lid,)); c.commit(); c.close(); audit(get_user()["id"],row["company_id"],"DISABLE","LICENSE",lid,row["license_key"]); return jsonify(ok=True)

@app.get("/api/me")
@login_required
def api_me():
    return jsonify(get_user())

@app.post("/api/me/password")
@login_required
def api_me_password():
    user=get_user()
    data=request.get_json(silent=True) or {}
    current=str(data.get("current_password", ""))
    new=str(data.get("new_password", ""))
    confirm=str(data.get("confirm_password", ""))
    c=conn()
    try:
        row=c.execute("SELECT password_hash FROM users WHERE id=? AND status='ACTIVE'",(user["id"],)).fetchone()
        if not row or not verify_password(current,row["password_hash"]):
            return jsonify(ok=False,message="Current password is incorrect"),400
        if len(new)<10:
            return jsonify(ok=False,message="Use at least 10 characters for the new password"),400
        if new != confirm:
            return jsonify(ok=False,message="The new passwords do not match"),400
        if hmac.compare_digest(current,new):
            return jsonify(ok=False,message="Choose a new password different from the current one"),400
        c.execute("UPDATE users SET password_hash=?,password_secret=?,must_change_password=0 WHERE id=?",
                  (hash_password(new),protect_secret(new),user["id"]))
        c.commit()
    except Exception:
        c.rollback()
        return jsonify(ok=False,message="Password could not be changed. Try again."),500
    finally:
        c.close()
    audit(user["id"],user["company_id"],"CHANGE_PASSWORD","USER",user["id"],"Password changed")
    session.clear()
    session["user_id"]=user["id"]
    session["_csrf_token"]=secrets.token_urlsafe(32)
    return jsonify(ok=True,message="Password changed successfully")

@app.get("/api/companies")
@login_required
def api_companies():
    u=get_user(); c=conn()
    if u["role"]=="SUPER_ADMIN":
        rows=c.execute("""SELECT co.*, COALESCE(NULLIF(TRIM(co.name),''), co.code) AS display_name,
            (SELECT COUNT(*) FROM inspectors i WHERE i.company_id=co.id AND i.status='ACTIVE') AS active_inspectors,
            (SELECT COUNT(*) FROM devices d WHERE d.company_id=co.id AND d.status='ACTIVE') AS active_devices
            FROM companies co WHERE co.status NOT IN ('DELETED') ORDER BY co.id DESC""").fetchall()
    else:
        rows=c.execute("""SELECT co.*, COALESCE(NULLIF(TRIM(co.name),''), co.code) AS display_name,
            (SELECT COUNT(*) FROM inspectors i WHERE i.company_id=co.id AND i.status='ACTIVE') AS active_inspectors,
            (SELECT COUNT(*) FROM devices d WHERE d.company_id=co.id AND d.status='ACTIVE') AS active_devices
            FROM companies co WHERE co.id=? AND co.status NOT IN ('DELETED')""",(u["company_id"],)).fetchall()
    c.close(); return jsonify([dict(r) for r in rows])

@app.post("/api/companies")
@login_required
@roles_required("SUPER_ADMIN")
def api_company_create():
    d=request.get_json(silent=True) or {}
    name=d.get("name","").strip(); code=d.get("code","").strip().upper()
    if not name or not code: return jsonify(ok=False,message="Company name and code are required"),400
    c=conn()
    try:
        c.execute("""INSERT INTO companies(name,code,address,contact_person,phone,email,status,created_at)
                     VALUES(?,?,?,?,?,?,?,?)""",(name,code,d.get("address",""),d.get("contact_person",""),
                     d.get("phone",""),d.get("email",""),"ACTIVE",now_str()))
        cid=c.execute("SELECT last_insert_rowid()").fetchone()[0]; c.commit(); c.close()
        audit(get_user()["id"],cid,"CREATE","COMPANY",cid,name)
        return jsonify(ok=True,id=cid)
    except sqlite3.IntegrityError:
        c.close(); return jsonify(ok=False,message="Company code already exists"),400

@app.put("/api/companies/<int:cid>")
@login_required
@roles_required("SUPER_ADMIN")
def api_company_update(cid):
    d=request.get_json(silent=True) or {}; c=conn()
    try:
        row=c.execute("SELECT * FROM companies WHERE id=? AND status!='DELETED'",(cid,)).fetchone()
        if not row:
            return jsonify(ok=False,message="Company not found"),404
        values={key: str(d.get(key, row[key]) or "").strip() for key in ("name","address","contact_person","phone","email")}
        status=str(d.get("status",row["status"])).strip().upper()
        if not values["name"]:
            return jsonify(ok=False,message="Company name is required"),400
        if status not in ("ACTIVE","DISABLED"):
            return jsonify(ok=False,message="Invalid company status"),400
        c.execute("""UPDATE companies SET name=?,address=?,contact_person=?,phone=?,email=?,status=? WHERE id=?""",
                  (values["name"],values["address"],values["contact_person"],values["phone"],values["email"],status,cid))
        if status != "ACTIVE":
            c.execute("UPDATE mobile_sessions SET status='REVOKED' WHERE company_id=? AND status='ACTIVE'",(cid,))
            c.execute("UPDATE inspection_sessions SET status='ENDED',ended_at=? WHERE company_id=? AND status='ACTIVE'",(now_str(),cid))
        c.commit()
        audit(get_user()["id"],cid,"UPDATE","COMPANY",cid,values["name"])
        return jsonify(ok=True)
    except Exception:
        c.rollback()
        return jsonify(ok=False,message="Company could not be updated"),500
    finally:
        c.close()

@app.delete("/api/companies/<int:cid>")
@login_required
@roles_required("SUPER_ADMIN")
def api_company_delete(cid):
    c=conn()
    try:
        row=c.execute("SELECT * FROM companies WHERE id=? AND status!='DELETED'",(cid,)).fetchone()
        if not row:
            return jsonify(ok=False,message="Active company not found"),404
        stamp=now_str()
        # Soft-delete only. Historical scans and records remain intact.
        c.execute("UPDATE companies SET status='DELETED',deleted_at=?,code=code||'~del'||id WHERE id=?",(stamp,cid))
        c.execute("UPDATE users SET status='DELETED',deleted_at=?,username=username||'~del'||id WHERE company_id=? AND status!='DELETED'",(stamp,cid))
        c.execute("UPDATE inspectors SET status='DELETED',deleted_at=? WHERE company_id=? AND status!='DELETED'",(stamp,cid))
        c.execute("UPDATE points SET status='DELETED',deleted_at=?,point_code=point_code||'~del'||id WHERE company_id=? AND status!='DELETED'",(stamp,cid))
        if table_columns(c,'licenses'):
            c.execute("UPDATE licenses SET status='DISABLED' WHERE company_id=? AND status IN ('GENERATED','ACTIVE')",(cid,))
        if table_columns(c,'mobile_sessions'):
            c.execute("UPDATE mobile_sessions SET status='REVOKED' WHERE company_id=?",(cid,))
        if table_columns(c,'inspection_sessions'):
            c.execute("UPDATE inspection_sessions SET status='ENDED',ended_at=? WHERE company_id=? AND status='ACTIVE'",(stamp,cid))
        if table_columns(c,'devices'):
            c.execute("UPDATE devices SET status='DELETED',deleted_at=? WHERE company_id=? AND status!='DELETED'",(stamp,cid))
        c.commit()
        actor=get_user()
        audit(actor['id'],cid,'DELETE','COMPANY',cid,row['name'])
        return jsonify(ok=True,message="Company deleted",deleted_id=cid)
    except Exception as e:
        c.rollback()
        return jsonify(ok=False,message="Company delete failed: "+str(e)),500
    finally:
        c.close()

@app.get("/api/points")
@login_required
@licensed_required
def api_points():
    u=get_user(); cid=request_company_id(u)
    c=conn()
    if cid:
        rows=c.execute("""SELECT p.*,
          (SELECT s.scan_time FROM scans s WHERE s.point_id=p.id AND s.result='ACCEPTED' ORDER BY s.id DESC LIMIT 1) AS last_scan,
          (SELECT s.inspector_name FROM scans s WHERE s.point_id=p.id AND s.result='ACCEPTED' ORDER BY s.id DESC LIMIT 1) AS last_inspector,
          (SELECT COUNT(*) FROM scans s WHERE s.point_id=p.id AND s.result='ACCEPTED' AND date(s.scan_time)=date('now','localtime')) AS scanned_today
          FROM points p WHERE p.company_id=? AND p.status!='DELETED' ORDER BY p.id""",(cid,)).fetchall()
    else:
        rows=c.execute("""SELECT p.*, c.name AS company_name, c.code AS company_code,
          (SELECT s.scan_time FROM scans s WHERE s.point_id=p.id AND s.result='ACCEPTED' ORDER BY s.id DESC LIMIT 1) AS last_scan,
          (SELECT s.inspector_name FROM scans s WHERE s.point_id=p.id AND s.result='ACCEPTED' ORDER BY s.id DESC LIMIT 1) AS last_inspector,
          (SELECT COUNT(*) FROM scans s WHERE s.point_id=p.id AND s.result='ACCEPTED' AND date(s.scan_time)=date('now','localtime')) AS scanned_today
          FROM points p JOIN companies c ON c.id=p.company_id WHERE p.status!='DELETED' AND c.status='ACTIVE' ORDER BY p.company_id,p.id""").fetchall()
    out=[]
    for r in rows:
        d=dict(r)
        if u["role"] != "SUPER_ADMIN": d.pop("qr_token",None)
        out.append(d)
    c.close(); return jsonify(out)

@app.post("/api/points")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def api_point_create():
    u=get_user(); d=request.get_json(silent=True) or {}
    cid=u["company_id"] if u["role"]!="SUPER_ADMIN" else (int(d["company_id"]) if str(d.get("company_id","")).isdigit() else None)
    code=d.get("point_code","").strip().upper(); name=d.get("name","").strip()
    if not cid: return jsonify(ok=False,message="Company selection is required"),400
    if not code or not name: return jsonify(ok=False,message="Point code and name are required"),400
    c=conn()
    try:
        token=f"RTI-{cid}-{code}-{secrets.token_urlsafe(14)}"
        c.execute("""INSERT INTO points(company_id,point_code,name,location,description,qr_token,status,created_at)
                     VALUES(?,?,?,?,?,?,?,?)""",(cid,code,name,d.get("location",""),d.get("description",""),token,"ACTIVE",now_str()))
        pid=c.execute("SELECT last_insert_rowid()").fetchone()[0]; c.commit(); c.close()
        audit(u["id"],cid,"CREATE","POINT",pid,name)
        return jsonify(ok=True,id=pid,qr_token=token)
    except sqlite3.IntegrityError:
        c.close(); return jsonify(ok=False,message="Point code already exists in this company"),400

@app.put("/api/points/<int:pid>")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def api_point_update(pid):
    u=get_user(); d=request.get_json(silent=True) or {}; c=conn()
    row=c.execute("SELECT * FROM points WHERE id=?",(pid,)).fetchone()
    if not row or (u["role"]!="SUPER_ADMIN" and row["company_id"]!=u["company_id"]):
        c.close(); return jsonify(ok=False,message="Not allowed"),403
    c.execute("""UPDATE points SET point_code=?,name=?,location=?,description=?,status=? WHERE id=?""",
              (d.get("point_code",row["point_code"]).strip().upper(),d.get("name",row["name"]),
               d.get("location",row["location"]),d.get("description",row["description"]),
               d.get("status",row["status"]),pid))
    c.commit(); c.close(); audit(u["id"],row["company_id"],"UPDATE","POINT",pid,d.get("name",row["name"]))
    return jsonify(ok=True)

@app.delete("/api/points/<int:pid>")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def api_point_delete(pid):
    u=get_user(); c=conn(); row=c.execute("SELECT * FROM points WHERE id=?",(pid,)).fetchone()
    if not row or (u["role"]!="SUPER_ADMIN" and row["company_id"]!=u["company_id"]):
        c.close(); return jsonify(ok=False,message="Not allowed"),403
    c.execute("UPDATE points SET status='DELETED',deleted_at=?,point_code=point_code||'~del'||id WHERE id=? AND status!='DELETED'",(now_str(),pid))
    c.commit(); c.close(); audit(u["id"],row["company_id"],"DELETE","POINT",pid,row["name"])
    return jsonify(ok=True)

@app.get("/points/<int:pid>/qr")
@login_required
@licensed_required
def point_qr_page(pid):
    import qrcode, base64
    u=get_user()
    if u["role"] != "SUPER_ADMIN":
        return "QR printing is managed by AB SECURITAS.",403
    c=conn()
    row=c.execute("SELECT p.*, co.name AS company_name FROM points p JOIN companies co ON co.id=p.company_id WHERE p.id=?",(pid,)).fetchone(); c.close()
    if not row:
        return "Point not found",404
    if u["role"]!="SUPER_ADMIN" and row["company_id"]!=u["company_id"]:
        return "Forbidden",403
    if row["status"]!="ACTIVE":
        return "Point is inactive",400
    img=qrcode.make(row["qr_token"])
    buf=io.BytesIO(); img.save(buf,format="PNG"); b64=base64.b64encode(buf.getvalue()).decode("ascii")
    safe_name=row["name"] or undel(row["point_code"])
    safe_code=undel(row["point_code"])
    safe_company=row["company_name"] or ""
    safe_token=row["qr_token"]
    return render_template_string("""
<!doctype html><html><head><meta charset="utf-8"><title>QR - {{name}}</title>
<style>@page{size:A4;margin:15mm}body{font-family:Arial,sans-serif;text-align:center;color:#10213f;background:#f4f7fb;margin:0}.card{width:520px;max-width:92vw;margin:35px auto;background:#fff;padding:35px;border-radius:18px;box-shadow:0 10px 35px #0002}.brand{font-size:30px;font-weight:800}.division{color:#168dcc;font-size:14px;font-weight:700;letter-spacing:1px;margin-top:5px}.title{font-size:14px;color:#667085;margin:12px 0 24px}.point{font-size:25px;font-weight:800}.code{color:#667085;margin-top:5px}.qr{width:320px;height:320px;margin:22px auto}.qr img{width:320px;height:320px}.token{font-size:10px;color:#667085;word-break:break-all}.actions{margin-top:25px}button{padding:11px 22px;border:0;border-radius:8px;background:#168dcc;color:white;font-weight:700;font-size:15px;cursor:pointer}@media print{body{background:#fff}.card{box-shadow:none;margin:0 auto}.actions{display:none}}
</style></head><body><div class="card"><div class="brand">AB SECURITAS</div><div class="division">ELECTRONIC SECURITY DIVISION</div><div class="title">REAL TIME INSPECTOR · CHECK POINT QR</div><div class="point">{{name}}</div><div class="code">{{code}} · {{company}}</div><div class="qr"><img src="data:image/png;base64,{{b64}}" alt="QR Code"></div><div class="token">{{token}}</div><div class="actions"><button onclick="window.print()">Print / Save as PDF</button></div></div></body></html>
""",name=safe_name,code=safe_code,company=safe_company,b64=b64,token=safe_token)

@app.get("/api/qr-image")
@login_required
def api_qr_image():
    import qrcode
    from urllib.parse import unquote
    token = request.args.get("token", "").strip()
    if not token:
        return Response("Missing QR token", status=400, mimetype="text/plain")
    u = get_user()
    if u["role"] != "SUPER_ADMIN":
        return Response("QR printing is managed by AB SECURITAS", status=403, mimetype="text/plain")
    c = conn()
    row = c.execute("SELECT company_id FROM points WHERE qr_token=? AND status='ACTIVE'", (token,)).fetchone(); c.close()
    if not row:
        return Response("Invalid QR token", status=404, mimetype="text/plain")
    if u["role"] != "SUPER_ADMIN" and row["company_id"] != u["company_id"]:
        return Response("Forbidden", status=403, mimetype="text/plain")
    if u["role"] != "SUPER_ADMIN" and not license_is_active(row["company_id"]):
        return Response("Company license is not active", status=403, mimetype="text/plain")
    img = qrcode.make(token)
    buf = io.BytesIO(); img.save(buf, format="PNG"); buf.seek(0)
    return send_file(buf, mimetype="image/png", max_age=0)

@app.post("/api/points/<int:pid>/regenerate-qr")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def api_point_qr(pid):
    u=get_user(); c=conn(); row=c.execute("SELECT * FROM points WHERE id=?",(pid,)).fetchone()
    if not row or (u["role"]!="SUPER_ADMIN" and row["company_id"]!=u["company_id"]):
        c.close(); return jsonify(ok=False,message="Not allowed"),403
    token=f"RTI-{row['company_id']}-{row['point_code']}-{secrets.token_urlsafe(14)}"
    c.execute("UPDATE points SET qr_token=? WHERE id=?",(token,pid)); c.commit(); c.close()
    audit(u["id"],row["company_id"],"REGENERATE_QR","POINT",pid,row["point_code"])
    return jsonify(ok=True,qr_token=token)

@app.get("/api/devices")
@login_required
@roles_required("SUPER_ADMIN")
def api_devices():
    cid=request.args.get("company_id",type=int)
    include_deleted=request.args.get("include_deleted","").lower() in ("1","true","yes")
    c=conn()
    try:
        clauses=[]; params=[]
        if not include_deleted: clauses.append("d.status!='DELETED'")
        if cid: clauses.append("d.company_id=?"); params.append(cid)
        else: clauses.append("co.status='ACTIVE'")
        where=" WHERE "+" AND ".join(clauses) if clauses else ""
        rows=c.execute("SELECT d.*,co.name company_name,co.code company_code FROM devices d JOIN companies co ON co.id=d.company_id"+where+" ORDER BY d.id DESC",params).fetchall()
        result=[]
        for row in rows:
            item=dict(row)
            inspectors=c.execute("SELECT id,employee_id,name,login_username,status FROM inspectors WHERE company_id=? AND device_id=? AND status!='DELETED' ORDER BY name,id",(row["company_id"],row["device_id"])).fetchall()
            item["assigned_inspectors"]=[dict(inspector) for inspector in inspectors]
            item["assigned_inspector_ids"]=[inspector["id"] for inspector in inspectors]
            seen=c.execute("SELECT MAX(last_seen) last_seen FROM mobile_sessions WHERE company_id=? AND device_id=?",(row["company_id"],row["device_id"])).fetchone()
            item["last_seen"]=seen["last_seen"] or ""
            result.append(item)
        return jsonify(result)
    finally:
        c.close()

@app.put("/api/devices/<int:device_pk>")
@login_required
@roles_required("SUPER_ADMIN")
def api_device_update(device_pk):
    data=request.get_json(silent=True) or {}
    c=conn()
    try:
        row=c.execute("SELECT * FROM devices WHERE id=?",(device_pk,)).fetchone()
        if not row:
            return jsonify(ok=False,message="Device not found"),404
        if int(row["permanently_deleted"] or 0):
            return jsonify(ok=False,message="This device was permanently removed and cannot be restored or edited"),409
        old_id=str(row["device_id"] or "").strip()
        new_id=str(data.get("device_id",old_id)).strip()
        status=str(data.get("status",row["status"])).upper().strip()
        access_policy=str(data.get("access_policy",row["access_policy"] or "OPEN")).upper().strip()
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{2,79}",new_id):
            return jsonify(ok=False,message="Device ID must contain 3–80 letters, numbers, dot, dash, underscore or colon"),400
        if status not in ("ACTIVE","DISABLED","DELETED"):
            return jsonify(ok=False,message="Choose Active, Blocked or Removed"),400
        if access_policy not in ("OPEN","ASSIGNED"):
            return jsonify(ok=False,message="Choose Open registration or Assigned inspectors only"),400
        duplicate=c.execute("SELECT id FROM devices WHERE device_id=? AND id!=?",(new_id,device_pk)).fetchone()
        if duplicate:
            return jsonify(ok=False,message="That Device ID is already registered"),409

        requested_ids=None
        if "inspector_ids" in data:
            raw_ids=data.get("inspector_ids")
            if not isinstance(raw_ids,list):
                return jsonify(ok=False,message="Inspector assignments must be a list"),400
            try: requested_ids=sorted({int(value) for value in raw_ids})
            except (TypeError,ValueError):
                return jsonify(ok=False,message="Inspector assignment contains an invalid ID"),400
            if requested_ids:
                marks=",".join("?" for _ in requested_ids)
                valid=c.execute(f"SELECT id FROM inspectors WHERE company_id=? AND status='ACTIVE' AND id IN ({marks})",(row["company_id"],*requested_ids)).fetchall()
                if len(valid)!=len(requested_ids):
                    return jsonify(ok=False,message="Every assigned inspector must be active in this device's company"),400

        affected=c.execute("SELECT id,device_id FROM inspectors WHERE company_id=? AND device_id=? AND status!='DELETED'",(row["company_id"],old_id)).fetchall()
        affected_inspector_ids={int(value["id"]) for value in affected}
        if requested_ids is not None:
            affected_inspector_ids.update(requested_ids)
            c.execute("UPDATE inspectors SET device_id='' WHERE company_id=? AND device_id IN (?,?)",(row["company_id"],old_id,new_id))
            if requested_ids:
                marks=",".join("?" for _ in requested_ids)
                c.execute(f"UPDATE inspectors SET device_id=? WHERE company_id=? AND status='ACTIVE' AND id IN ({marks})",(new_id,row["company_id"],*requested_ids))
        elif new_id!=old_id:
            c.execute("UPDATE inspectors SET device_id=? WHERE company_id=? AND device_id=?",(new_id,row["company_id"],old_id))

        columns=table_columns(c,"devices")
        if "device_identifier" in columns:
            c.execute("UPDATE devices SET device_id=?,device_identifier=?,status=?,access_policy=?,deleted_at=? WHERE id=?",
                      (new_id,new_id,status,access_policy,now_str() if status=="DELETED" else None,device_pk))
        else:
            c.execute("UPDATE devices SET device_id=?,status=?,access_policy=?,deleted_at=? WHERE id=?",
                      (new_id,status,access_policy,now_str() if status=="DELETED" else None,device_pk))
        affected_marks=",".join("?" for _ in affected_inspector_ids)
        if affected_inspector_ids:
            ids=tuple(sorted(affected_inspector_ids))
            c.execute(f"UPDATE mobile_sessions SET status='REVOKED' WHERE company_id=? AND (device_id IN (?,?) OR inspector_id IN ({affected_marks}))",(row["company_id"],old_id,new_id,*ids))
            c.execute(f"UPDATE inspection_sessions SET status='ENDED',ended_at=? WHERE company_id=? AND status='ACTIVE' AND (device_id IN (?,?) OR inspector_id IN ({affected_marks}))",(now_str(),row["company_id"],old_id,new_id,*ids))
        elif status!="ACTIVE" or new_id!=old_id:
            c.execute("UPDATE mobile_sessions SET status='REVOKED' WHERE company_id=? AND device_id IN (?,?)",(row["company_id"],old_id,new_id))
            c.execute("UPDATE inspection_sessions SET status='ENDED',ended_at=? WHERE company_id=? AND status='ACTIVE' AND device_id IN (?,?)",(now_str(),row["company_id"],old_id,new_id))
        c.commit()
        admin=get_user()
        c.close()
        audit(admin["id"],row["company_id"],"UPDATE","DEVICE",device_pk,f"{old_id} → {new_id}; {status}; access={access_policy}")
        return jsonify(ok=True,message="Device access updated. Affected inspectors must sign in again.")
    except sqlite3.IntegrityError:
        c.rollback()
        return jsonify(ok=False,message="Device ID is already in use"),409
    except sqlite3.Error as exc:
        c.rollback()
        return jsonify(ok=False,message="Device update failed: "+str(exc)),500
    finally:
        try: c.close()
        except Exception: pass

@app.delete("/api/devices/<int:device_pk>")
@login_required
@roles_required("SUPER_ADMIN")
def api_device_delete(device_pk):
    c=conn()
    try:
        row=c.execute("SELECT * FROM devices WHERE id=?",(device_pk,)).fetchone()
        if not row:
            return jsonify(ok=False,message="Device not found"),404
        c.execute("UPDATE devices SET status='DELETED',deleted_at=? WHERE id=?",(now_str(),device_pk))
        c.execute("UPDATE mobile_sessions SET status='REVOKED' WHERE company_id=? AND device_id=?",(row["company_id"],row["device_id"]))
        c.execute("UPDATE inspection_sessions SET status='ENDED',ended_at=? WHERE company_id=? AND device_id=? AND status='ACTIVE'",(now_str(),row["company_id"],row["device_id"]))
        c.commit()
        admin=get_user()
        audit(admin["id"],row["company_id"],"DELETE","DEVICE",device_pk,row["device_id"])
        return jsonify(ok=True,message="Device removed from access. Historical scan records were kept.")
    finally:
        c.close()

@app.delete("/api/devices/<int:device_pk>/permanent")
@login_required
@roles_required("SUPER_ADMIN")
def api_device_permanent_delete(device_pk):
    c=conn()
    try:
        row=c.execute("SELECT * FROM devices WHERE id=?",(device_pk,)).fetchone()
        if not row:
            return jsonify(ok=False,message="Device not found"),404
        if row["status"]!="DELETED":
            return jsonify(ok=False,message="Remove the device first, then permanently delete it"),409
        if int(row["permanently_deleted"] or 0):
            return jsonify(ok=False,message="This device was already permanently removed"),409
        # Keep a tombstone and its immutable ID to prevent automatic re-registration.
        # The device has no direct personal profile; scan history keeps its original ID.
        c.execute("UPDATE devices SET permanently_deleted=1 WHERE id=?",(device_pk,))
        c.execute("UPDATE mobile_sessions SET status='REVOKED' WHERE company_id=? AND device_id=?",(row["company_id"],row["device_id"]))
        c.execute("UPDATE inspection_sessions SET status='ENDED',ended_at=? WHERE company_id=? AND device_id=? AND status='ACTIVE'",(now_str(),row["company_id"],row["device_id"]))
        c.commit()
        actor=get_user()
        audit(actor["id"],row["company_id"],"PERMANENT_DELETE","DEVICE",device_pk,
              f"Device access permanently removed; history-preserving tombstone retained for {row['device_id']}")
        return jsonify(ok=True,message="Device access permanently removed. Its ID remains blocked, and historical scans and audit records are retained.")
    except sqlite3.Error as exc:
        c.rollback()
        return jsonify(ok=False,message="Device could not be permanently removed: "+str(exc)),500
    finally:
        c.close()

@app.get("/api/inspectors")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def api_inspectors():
    c=conn(); rows=c.execute("""SELECT i.id,i.company_id,i.employee_id,i.name,i.phone,i.device_id,
        i.login_username,i.status,i.created_at,c.name company_name
        FROM inspectors i JOIN companies c ON c.id=i.company_id
        WHERE i.status!='DELETED' AND c.status='ACTIVE' ORDER BY i.id DESC""").fetchall(); c.close(); return jsonify([dict(r) for r in rows])

@app.post("/api/inspectors")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def api_inspector_create():
    u=get_user(); d=request.get_json(silent=True) or {}
    cid=int(d["company_id"]) if str(d.get("company_id","")).isdigit() else None
    name=str(d.get("name","")).strip(); emp=str(d.get("employee_id","")).strip()
    login_username=str(d.get("login_username","")).strip(); login_password=str(d.get("login_password",""))
    phone=str(d.get("phone","")).strip()
    if not cid or not name or not emp or not login_username or len(login_password)<6:
        return jsonify(ok=False,message="Company, Inspector ID, Name, User ID and password (minimum 6 characters) are required"),400
    c=conn()
    try:
        company=c.execute("SELECT id FROM companies WHERE id=? AND status='ACTIVE'",(cid,)).fetchone()
        if not company:
            return jsonify(ok=False,message="Selected company is not active"),400
        if c.execute("SELECT id FROM inspectors WHERE employee_id=? AND status!='DELETED'",(emp,)).fetchone():
            return jsonify(ok=False,message="Inspector ID already exists"),400
        if c.execute("SELECT id FROM inspectors WHERE login_username=? AND status!='DELETED'",(login_username,)).fetchone():
            return jsonify(ok=False,message="Inspector User ID already exists"),400

        # Device ID is generated automatically by the Android device on first
        # login. Super Admin never types or edits it here. Once the phone logs
        # in, the server binds that immutable device ID to this inspector.
        # Multiple inspectors may later use the same physical device.
        did=str(d.get("device_id","")).strip()
        if did and did != "NEW":
            device=c.execute("SELECT * FROM devices WHERE company_id=? AND device_id=? AND status='ACTIVE'",(cid,did)).fetchone()
            if not device:
                return jsonify(ok=False,message="Selected Device ID does not belong to this company or is inactive"),400

        c.execute("""INSERT INTO inspectors(company_id,employee_id,name,phone,device_id,login_username,password_hash,password_secret,status,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""",
                  (cid,emp,name,phone,did,login_username,hash_password(login_password),protect_secret(login_password),"ACTIVE",now_str()))
        iid=c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
        c.commit()
        audit(u["id"],cid,"CREATE","INSPECTOR",iid,name)
        return jsonify(ok=True,id=iid,device_id=did or "NOT_REGISTERED")
    except sqlite3.IntegrityError as e:
        c.rollback()
        return jsonify(ok=False,message="Inspector could not be created: "+str(e)),400
    finally:
        c.close()

@app.put("/api/inspectors/<int:iid>")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def api_inspector_update(iid):
    d=request.get_json(silent=True) or {}
    c=conn()
    row=c.execute("SELECT * FROM inspectors WHERE id=? AND status!='DELETED'",(iid,)).fetchone()
    if not row:
        c.close(); return jsonify(ok=False,message="Active inspector not found"),404
    username=str(d.get("login_username",row["login_username"] or "")).strip()
    emp=str(d.get("employee_id",row["employee_id"] or "")).strip()
    name=str(d.get("name",row["name"] or "")).strip()
    phone=str(d.get("phone",row["phone"] or "")).strip()
    if not emp or not name or not username:
        c.close(); return jsonify(ok=False,message="Inspector ID, Name and User ID are required"),400
    if c.execute("SELECT id FROM inspectors WHERE employee_id=? AND id!=? AND status!='DELETED'",(emp,iid)).fetchone():
        c.close(); return jsonify(ok=False,message="Inspector ID already exists"),400
    if c.execute("SELECT id FROM inspectors WHERE login_username=? AND id!=? AND status!='DELETED'",(username,iid)).fetchone():
        c.close(); return jsonify(ok=False,message="Inspector User ID already exists"),400
    try:
        password=str(d.get("login_password","")).strip()
        if password and len(password)<6:
            c.close(); return jsonify(ok=False,message="Password must be at least 6 characters"),400
        if password:
            c.execute("UPDATE inspectors SET employee_id=?,name=?,phone=?,login_username=?,password_hash=?,password_secret=? WHERE id=?",(emp,name,phone,username,hash_password(password),protect_secret(password),iid))
        else:
            c.execute("UPDATE inspectors SET employee_id=?,name=?,phone=?,login_username=? WHERE id=?",(emp,name,phone,username,iid))
        if "status" in d and d["status"] in ("ACTIVE","DISABLED"):
            c.execute("UPDATE inspectors SET status=? WHERE id=?",(d["status"],iid))
        c.commit()
        company_id=row["company_id"]
    except sqlite3.IntegrityError as e:
        c.rollback(); c.close(); return jsonify(ok=False,message="Inspector could not be updated: "+str(e)),400
    c.close()
    audit(get_user()["id"],company_id,"UPDATE","INSPECTOR",iid,name)
    return jsonify(ok=True)

@app.delete("/api/inspectors/<int:iid>")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def api_inspector_delete(iid):
    c=conn()
    try:
        row=c.execute("SELECT * FROM inspectors WHERE id=? AND status!='DELETED'",(iid,)).fetchone()
        if not row:
            return jsonify(ok=False,message="Active inspector not found"),404
        stamp=now_str()
        c.execute("UPDATE inspectors SET status='DELETED',deleted_at=? WHERE id=?",(stamp,iid))
        c.execute("UPDATE mobile_sessions SET status='REVOKED' WHERE inspector_id=?",(iid,))
        # Keep the managed device active because one device may be shared by multiple inspectors.
        c.commit()
        actor=get_user()
        try:
            audit(actor["id"],row["company_id"],"DELETE","INSPECTOR",iid,row["name"])
        except Exception:
            pass
        return jsonify(ok=True,message="Inspector deleted",deleted_id=iid)
    except Exception as e:
        c.rollback()
        return jsonify(ok=False,message="Inspector delete failed: "+str(e)),500
    finally:
        c.close()

@app.delete("/api/inspectors/<int:iid>/permanent")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def api_inspector_permanent_delete(iid):
    c=conn()
    try:
        row=c.execute("SELECT * FROM inspectors WHERE id=?",(iid,)).fetchone()
        if not row:
            return jsonify(ok=False,message="Inspector not found"),404
        if row["status"]!="DELETED":
            return jsonify(ok=False,message="Delete the inspector first, then permanently delete the profile"),409
        if int(row["permanently_deleted"] or 0):
            return jsonify(ok=False,message="This inspector profile was already permanently removed"),409
        stamp=now_str()
        c.execute("UPDATE mobile_sessions SET status='REVOKED' WHERE inspector_id=?",(iid,))
        c.execute("UPDATE inspection_sessions SET status='ENDED',ended_at=? WHERE inspector_id=? AND status='ACTIVE'",(stamp,iid))
        # Preserve the foreign-key tombstone and scan snapshots while erasing profile data and credentials.
        c.execute("""UPDATE inspectors SET employee_id=?,name=?,phone='',device_id='',login_username='',
                  password_hash='',password_secret='',permanently_deleted=1,deleted_at=COALESCE(deleted_at,?) WHERE id=?""",
                  (f"REMOVED-{iid}",f"Permanently deleted inspector #{iid}",stamp,iid))
        c.commit()
        actor=get_user()
        audit(actor["id"],row["company_id"],"PERMANENT_DELETE","INSPECTOR",iid,
              f"Inspector profile and credentials erased; scan snapshots and audit history retained (employee ID {row['employee_id']})")
        return jsonify(ok=True,message="Inspector profile and login credentials permanently erased. Historical scan records and audit history are retained.")
    except sqlite3.Error as exc:
        c.rollback()
        return jsonify(ok=False,message="Inspector could not be permanently removed: "+str(exc)),500
    finally:
        c.close()

@app.get("/api/history")
@login_required
@licensed_required
def api_history():
    u=get_user(); cid=request_company_id(u); start=request.args.get("start","").strip(); end=request.args.get("end","").strip(); point=request.args.get("point","").strip(); inspector=request.args.get("inspector","").strip(); inspector_id=request.args.get("inspector_id","").strip(); device=request.args.get("device","").strip(); schedule=request.args.get("schedule","").strip(); search=request.args.get("q","").strip(); result=request.args.get("result","").strip().upper(); inspection_type=request.args.get("inspection_type","").strip().upper(); sync_source=request.args.get("sync_source","").strip().upper(); rtype=request.args.get("type","ALL").strip().upper()
    if rtype=="DAILY" and not start: start=end=date.today().isoformat()
    elif rtype=="WEEKLY" and not start: end=date.today().isoformat(); start=(date.today()-timedelta(days=6)).isoformat()
    elif rtype=="MONTHLY" and not start: end=date.today().isoformat(); start=date.today().replace(day=1).isoformat()
    c=conn()
    if rtype=="MISSED":
        q="""SELECT NULL scan_time,NULL inspection_session_id,NULL inspection_type,NULL schedule_name,NULL sync_source,p.point_code,p.name point_name,NULL inspector_name,NULL device_id,'MISSED' result,co.name company_name FROM points p JOIN companies co ON co.id=p.company_id WHERE p.status='ACTIVE' AND co.status='ACTIVE' AND NOT EXISTS (SELECT 1 FROM scans s WHERE s.point_id=p.id AND date(s.scan_time)=date('now','localtime') AND s.result='ACCEPTED')"""; params=[]
        if cid: q+=" AND p.company_id=?"; params.append(cid)
        if u["role"]=="SUPER_ADMIN" and request.args.get("company_id"): q+=" AND p.company_id=?"; params.append(request.args.get("company_id",type=int) or 0)
        if point: q+=" AND (p.point_code LIKE ? OR p.name LIKE ?)"; params.extend(["%"+point+"%","%"+point+"%"])
        if search:
            term="%"+search+"%"; q+=" AND (p.point_code LIKE ? OR p.name LIKE ? OR co.name LIKE ?)"; params.extend([term,term,term])
        q+=" ORDER BY co.name,p.point_code LIMIT 1000"
    else:
        q="""SELECT s.*,p.name point_name,c.name company_name,COALESCE(ins.inspection_type,'MANUAL') inspection_type,COALESCE(ins.schedule_name,'') schedule_name,COALESCE(s.sync_source,'LIVE') sync_source,COALESCE(i.employee_id,'') inspector_employee_id FROM scans s LEFT JOIN points p ON p.id=s.point_id OR (s.point_id IS NULL AND p.company_id=s.company_id AND p.point_code=s.point_code) LEFT JOIN companies c ON c.id=s.company_id LEFT JOIN inspection_sessions ins ON ins.id=s.inspection_session_id LEFT JOIN inspectors i ON i.id=s.inspector_id WHERE 1=1"""; params=[]
        if cid: q+=" AND s.company_id=?"; params.append(cid)
        if u["role"]=="SUPER_ADMIN" and request.args.get("company_id"): q+=" AND s.company_id=?"; params.append(request.args.get("company_id",type=int) or 0)
        if start: q+=" AND date(s.scan_time)>=?"; params.append(start)
        if end: q+=" AND date(s.scan_time)<=?"; params.append(end)
        if point: q+=" AND (s.point_code LIKE ? OR COALESCE(p.name,'') LIKE ?)"; params.extend(["%"+point+"%","%"+point+"%"])
        if inspector: q+=" AND (COALESCE(s.inspector_name,'') LIKE ? OR COALESCE(i.name,'') LIKE ? OR COALESCE(i.login_username,'') LIKE ?)"; params.extend(["%"+inspector+"%","%"+inspector+"%","%"+inspector+"%"])
        if inspector_id: q+=" AND (CAST(s.inspector_id AS TEXT) LIKE ? OR COALESCE(i.employee_id,'') LIKE ?)"; params.extend(["%"+inspector_id+"%","%"+inspector_id+"%"])
        if device: q+=" AND s.device_id LIKE ?"; params.append("%"+device+"%")
        if schedule: q+=" AND COALESCE(ins.schedule_name,'') LIKE ?"; params.append("%"+schedule+"%")
        if search:
            term="%"+search+"%"; q+=" AND (COALESCE(s.point_code,'') LIKE ? OR COALESCE(p.name,'') LIKE ? OR COALESCE(s.inspector_name,'') LIKE ? OR COALESCE(i.name,'') LIKE ? OR COALESCE(i.employee_id,'') LIKE ? OR COALESCE(s.device_id,'') LIKE ? OR COALESCE(ins.schedule_name,'') LIKE ? OR COALESCE(c.name,'') LIKE ?)"; params.extend([term]*8)
        if result: q+=" AND s.result=?"; params.append(result)
        if inspection_type in ("MANUAL","SCHEDULED"): q+=" AND COALESCE(ins.inspection_type,'MANUAL')=?"; params.append(inspection_type)
        if sync_source in ("LIVE","OFFLINE_QUEUE"): q+=" AND COALESCE(s.sync_source,'LIVE')=?"; params.append(sync_source)
        if rtype=="REPEAT": q+=" AND s.result='REPEAT'"
        q+=" ORDER BY s.id DESC LIMIT 1000"
    rows=c.execute(q,params).fetchall(); c.close(); return jsonify([dict(r) for r in rows])

@app.post("/api/history/delete")
@login_required
@roles_required("SUPER_ADMIN")
@licensed_required
def api_history_delete():
    data=request.get_json(silent=True) or {}
    raw_ids=data.get("ids")
    if not isinstance(raw_ids,list) or not raw_ids:
        return jsonify(ok=False,message="Select at least one scan record"),400
    if len(raw_ids)>500:
        return jsonify(ok=False,message="Delete no more than 500 scan records at a time"),400
    ids=[]
    for value in raw_ids:
        if isinstance(value,bool) or not str(value).isdigit() or int(value)<1:
            return jsonify(ok=False,message="A selected scan ID is invalid"),400
        ids.append(int(value))
    ids=sorted(set(ids))
    actor=get_user(); c=conn()
    try:
        marks=",".join("?" for _ in ids)
        rows=c.execute(f"""SELECT s.id,s.company_id,s.scan_time,s.point_code,s.inspector_name,s.device_id,s.result
            FROM scans s WHERE s.id IN ({marks})""",ids).fetchall()
        if not rows:
            return jsonify(ok=False,message="The selected history records are no longer available"),404
        stamp=now_str()
        for row in rows:
            details=(f"Deleted scan history; time={row['scan_time']}; point={row['point_code'] or ''}; "
                     f"inspector={row['inspector_name'] or ''}; device={row['device_id'] or ''}; result={row['result']}")
            c.execute("""INSERT INTO audit_logs(user_id,company_id,action,entity_type,entity_id,details,created_at)
                         VALUES(?,?,?,?,?,?,?)""",
                      (actor["id"],row["company_id"],"DELETE","SCAN",str(row["id"]),details,stamp))
        c.execute(f"DELETE FROM scans WHERE id IN ({marks})",ids)
        deleted=c.total_changes
        c.commit()
        return jsonify(ok=True,deleted=len(rows),message=f"Deleted {len(rows)} scan record(s). Each deletion was written to Audit Logs.")
    except sqlite3.Error as exc:
        c.rollback()
        return jsonify(ok=False,message="History was not deleted: "+str(exc)),500
    finally:
        c.close()

@app.get("/api/history/options")
@login_required
@licensed_required
def api_history_options():
    u=get_user(); cid=request_company_id(u)
    if u["role"] == "SUPER_ADMIN" and request.args.get("company_id"):
        try: cid=int(request.args.get("company_id"))
        except (TypeError,ValueError): return jsonify(ok=False,message="Invalid company ID"),400
    where=" WHERE 1=1"; params=[]
    if cid: where+=" AND s.company_id=?"; params.append(cid)
    c=conn()
    try:
        points=[dict(r) for r in c.execute("""SELECT DISTINCT COALESCE(s.point_code,'') AS code,COALESCE(p.name,'') AS name
            FROM scans s LEFT JOIN points p ON p.id=s.point_id OR (s.point_id IS NULL AND p.company_id=s.company_id AND p.point_code=s.point_code)
            """+where+" AND COALESCE(s.point_code,'')!='' ORDER BY code,name LIMIT 2000",params).fetchall()]
        inspectors=[dict(r) for r in c.execute("""SELECT DISTINCT COALESCE(NULLIF(TRIM(s.inspector_name),''),i.name,'') AS name,
            COALESCE(i.employee_id,'') AS employee_id,COALESCE(i.login_username,'') AS username
            FROM scans s LEFT JOIN inspectors i ON i.id=s.inspector_id
            """+where+" AND (COALESCE(s.inspector_name,'')!='' OR COALESCE(i.name,'')!='') ORDER BY name,employee_id LIMIT 2000",params).fetchall()]
        devices=[r[0] for r in c.execute("SELECT DISTINCT COALESCE(s.device_id,'') FROM scans s"+where+" AND COALESCE(s.device_id,'')!='' ORDER BY 1 LIMIT 2000",params).fetchall()]
        schedules=[r[0] for r in c.execute("""SELECT DISTINCT COALESCE(ins.schedule_name,'') FROM scans s
            LEFT JOIN inspection_sessions ins ON ins.id=s.inspection_session_id"""+where+" AND COALESCE(ins.schedule_name,'')!='' ORDER BY 1 LIMIT 2000",params).fetchall()]
        companies=[]
        if u["role"] == "SUPER_ADMIN":
            companies=[dict(r) for r in c.execute("SELECT id,name,code FROM companies WHERE status!='DELETED' ORDER BY name LIMIT 2000").fetchall()]
        return jsonify(ok=True,points=points,inspectors=inspectors,devices=devices,schedules=schedules,companies=companies)
    finally: c.close()

def mobile_auth():
    auth=request.headers.get("Authorization","")
    token=auth[7:].strip() if auth.lower().startswith("bearer ") else str((request.get_json(silent=True) or {}).get("mobile_token","")).strip()
    if not token: return None
    c=conn(); row=c.execute("""SELECT ms.*,
        i.id inspector_id,i.name inspector_name,i.employee_id inspector_employee_id,i.login_username inspector_username,
        u.username admin_username,u.full_name admin_full_name,
        c.name company_name,c.code company_code,c.status company_status
        FROM mobile_sessions ms
        LEFT JOIN inspectors i ON i.id=ms.inspector_id
        LEFT JOIN users u ON u.id=ms.user_id
        JOIN companies c ON c.id=ms.company_id
        WHERE ms.token=? AND ms.status='ACTIVE' AND c.status='ACTIVE'
          AND (i.id IS NULL OR i.status='ACTIVE')
          AND (u.id IS NULL OR u.status='ACTIVE')
          AND EXISTS (SELECT 1 FROM devices d WHERE d.company_id=ms.company_id AND d.device_id=ms.device_id AND d.status='ACTIVE')""",(token,)).fetchone()
    if row:
        stamp=now_str()
        try:
            previous=datetime.strptime(row["last_seen"],"%Y-%m-%d %H:%M:%S")
            if datetime.now()-previous > timedelta(minutes=2):
                if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='notifications'").fetchone():
                    c.execute("INSERT OR IGNORE INTO notifications(company_id,kind,title,body,source_key,occurred_at,created_at) VALUES(?,?,?,?,?,?,?)",
                              (row["company_id"],"DEVICE_ONLINE","Inspector device online",
                               f"{row['inspector_name'] or row['inspector_username'] or 'Inspector'} · {row['device_id']} reconnected",
                               f"mobile-session:{row['id']}:ONLINE:{row['last_seen']}",stamp,stamp))
        except (TypeError,ValueError):
            pass
        c.execute("UPDATE mobile_sessions SET last_seen=? WHERE id=?",(stamp,row["id"])); c.commit()
    c.close(); return dict(row) if row else None

@app.post("/api/mobile/login")
def api_mobile_login():
    d=request.get_json(silent=True) or {}; username=str(d.get("user_id",d.get("username",""))).strip(); password=str(d.get("password","")); device_id=str(d.get("device_id","")).strip()
    if not username or not password or not device_id: return jsonify(ok=False,message="Device ID, User ID and Password are required"),400
    c=conn(); row=c.execute("""SELECT i.*,c.name company_name,c.code company_code,c.status company_status
                               FROM inspectors i JOIN companies c ON c.id=i.company_id
                               WHERE i.login_username=? AND i.status='ACTIVE' AND c.status='ACTIVE'""",(username,)).fetchone()
    if not row or not row["password_hash"] or not verify_password(password,row["password_hash"]):
        c.close(); return jsonify(ok=False,message="Invalid Inspector User ID or Password"),401
    if not license_is_active(row["company_id"]): c.close(); return jsonify(ok=False,message="Company license is not active"),403
    assigned=(row["device_id"] or "").strip()
    device=c.execute("SELECT * FROM devices WHERE company_id=? AND device_id=?",(row["company_id"],device_id)).fetchone()
    if device and device["status"]!="ACTIVE":
        status_message="This device was removed by the Super Admin. Ask the admin to restore access." if device["status"]=="DELETED" else "This device is blocked by the Super Admin. Ask the admin to enable access."
        c.close(); return jsonify(ok=False,message=status_message),403
    if assigned and assigned != device_id:
        c.close(); return jsonify(ok=False,message="This Inspector is assigned to a different Device ID"),403
    if not assigned:
        if device and device["access_policy"]=="ASSIGNED":
            c.close(); return jsonify(ok=False,message="This device accepts only inspectors assigned by the Super Admin"),403
        if not device:
            err=ensure_device(c,row["company_id"],device_id)
            if err:
                c.close(); return jsonify(ok=False,message=err),403
        c.execute("UPDATE inspectors SET device_id=? WHERE id=?",(device_id,row["id"]))
    elif not device:
        c.close(); return jsonify(ok=False,message="Assigned Device ID is not registered or is inactive"),403
    token=secrets.token_urlsafe(32); stamp=now_str()
    admin=c.execute("SELECT id FROM users WHERE company_id=? AND status='ACTIVE' ORDER BY id LIMIT 1",(row["company_id"],)).fetchone(); admin_id=admin["id"] if admin else None
    c.execute("UPDATE mobile_sessions SET status='REVOKED' WHERE inspector_id=? AND device_id=? AND status='ACTIVE'",(row["id"],device_id))
    c.execute("INSERT INTO mobile_sessions(token,user_id,inspector_id,company_id,device_id,created_at,last_seen,status) VALUES(?,?,?,?,?,?,?,?)",(token,admin_id,row["id"],row["company_id"],device_id,stamp,stamp,"ACTIVE"))
    c.commit(); c.close()
    return jsonify(ok=True,mobile_token=token,company_id=row["company_id"],company_name=row["company_name"],company_code=row["company_code"],user_id=row["login_username"],user_name=row["name"],inspector_id=row["employee_id"],inspector_record_id=row["id"],device_id=device_id,server_time_utc=datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00","Z"))

@app.post("/api/mobile/logout")
def api_mobile_logout():
    u=mobile_auth()
    if not u: return jsonify(ok=False,message="Invalid mobile session"),401
    auth=request.headers.get("Authorization",""); token=auth[7:].strip() if auth.lower().startswith("bearer ") else str((request.get_json(silent=True) or {}).get("mobile_token","")).strip()
    c=conn(); c.execute("UPDATE mobile_sessions SET status='REVOKED' WHERE token=?",(token,)); c.execute("UPDATE inspection_sessions SET status='ENDED',ended_at=? WHERE inspector_id=? AND device_id=? AND status='ACTIVE'",(now_str(),u["inspector_id"],u["device_id"])); c.commit(); c.close(); return jsonify(ok=True)

@app.post("/api/mobile/start-inspection")
def api_mobile_start_inspection():
    u=mobile_auth()
    if not u: return jsonify(ok=False,message="Login required"),401
    if not license_is_active(u["company_id"]): return jsonify(ok=False,message="Company license is not active"),403
    data=request.get_json(silent=True) or {}
    inspection_type=str(data.get("inspection_type","MANUAL")).strip().upper()
    if inspection_type not in ("MANUAL","SCHEDULED"):
        return jsonify(ok=False,message="Inspection type must be MANUAL or SCHEDULED"),400
    schedule=None; schedule_id=None; schedule_name=""; checkpoint_ids=[]
    c=conn()
    try:
        if inspection_type == "SCHEDULED":
            try: schedule_id=int(data.get("schedule_id"))
            except (TypeError,ValueError): schedule_id=0
            schedule=c.execute("SELECT * FROM schedules WHERE id=? AND company_id=? AND enabled=1 AND (inspector_id IS NULL OR inspector_id=?)",(schedule_id,u["company_id"],u["inspector_id"])).fetchone()
            if not schedule:
                return jsonify(ok=False,message="This scheduled inspection is no longer assigned to this inspector"),409
            schedule_name=schedule["name"]
            try: checkpoint_ids=sorted(set(int(v) for v in json.loads(schedule["checkpoint_ids"] or "[]")))
            except (ValueError,TypeError,json.JSONDecodeError): checkpoint_ids=[]
        stamp=now_str()
        c.execute("UPDATE inspection_sessions SET status='ENDED',ended_at=? WHERE inspector_id=? AND device_id=? AND status='ACTIVE'",(stamp,u["inspector_id"],u["device_id"]))
        token=secrets.token_urlsafe(20)
        c.execute("INSERT INTO inspection_sessions(session_token,company_id,inspector_id,device_id,started_at,status,inspection_type,schedule_id,schedule_name,scheduled_for,checkpoint_ids) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                  (token,u["company_id"],u["inspector_id"],u["device_id"],stamp,"ACTIVE",inspection_type,schedule_id,schedule_name,datetime.now().strftime("%Y-%m-%d") if schedule_id else "",json.dumps(checkpoint_ids)))
        sid=c.execute("SELECT last_insert_rowid()").fetchone()[0]
        if "notifications" in {r["name"] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}:
            c.execute("INSERT OR IGNORE INTO notifications(company_id,kind,title,body,source_key,occurred_at,created_at) VALUES(?,?,?,?,?,?,?)",
                      (u["company_id"],"INSPECTION_STARTED","Inspection started",f"{u.get('inspector_name') or u.get('inspector_username') or 'Inspector'} began {inspection_type.lower()} inspection on {u['device_id']}",f"online-session:{sid}:STARTED",stamp,stamp))
        c.commit()
        return jsonify(ok=True,inspection_session_token=token,inspection_session_id=sid,started_at=stamp,status="ACTIVE",inspection_type=inspection_type,schedule_id=schedule_id,schedule_name=schedule_name,checkpoint_ids=checkpoint_ids)
    except Exception:
        c.rollback(); raise
    finally:
        c.close()

@app.post("/api/mobile/end-inspection")
def api_mobile_end_inspection():
    u=mobile_auth()
    if not u: return jsonify(ok=False,message="Login required"),401
    d=request.get_json(silent=True) or {}; st=str(d.get("inspection_session_token","")).strip()
    c=conn(); row=c.execute("SELECT * FROM inspection_sessions WHERE session_token=? AND company_id=? AND inspector_id=? AND device_id=? AND status='ACTIVE'",(st,u["company_id"],u["inspector_id"],u["device_id"])).fetchone()
    if not row: c.close(); return jsonify(ok=False,message="Active inspection session not found"),404
    stamp=now_str(); c.execute("UPDATE inspection_sessions SET status='ENDED',ended_at=? WHERE id=?",(stamp,row["id"])); c.commit(); c.close(); return jsonify(ok=True,status="ENDED",ended_at=stamp)

@app.get("/api/mobile/state")
def api_mobile_state():
    u=mobile_auth()
    if not u: return jsonify(ok=False,message="Login required"),401
    if not license_is_active(u["company_id"]): return jsonify(ok=False,message="Company license is not active"),403
    c=conn(); active=c.execute("SELECT * FROM inspection_sessions WHERE inspector_id=? AND device_id=? AND status='ACTIVE' ORDER BY id DESC LIMIT 1",(u["inspector_id"],u["device_id"])).fetchone()
    sid=active["id"] if active else None
    active_checkpoint_ids=[]
    if active:
        try: active_checkpoint_ids=sorted(set(int(v) for v in json.loads(active["checkpoint_ids"] or "[]")))
        except (ValueError,TypeError,json.JSONDecodeError): active_checkpoint_ids=[]
    sql="""SELECT p.id,p.point_code,p.name,p.location,p.qr_token,
        CASE WHEN ? IS NOT NULL AND EXISTS(SELECT 1 FROM scans s WHERE s.inspection_session_id=? AND s.point_id=p.id AND s.result='ACCEPTED') THEN 1 ELSE 0 END scanned
        FROM points p WHERE p.company_id=? AND p.status='ACTIVE'"""
    args=[sid,sid,u["company_id"]]
    if active_checkpoint_ids:
        sql += " AND p.id IN ("+",".join("?" for _ in active_checkpoint_ids)+")"; args.extend(active_checkpoint_ids)
    rows=c.execute(sql+" ORDER BY p.id",args).fetchall()
    schedules=[]
    if "schedules" in {r["name"] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}:
        for schedule in c.execute("SELECT id,name,schedule_time,days,grace_minutes,checkpoint_ids,enabled,inspector_id,updated_at FROM schedules WHERE company_id=? AND enabled=1 AND (inspector_id IS NULL OR inspector_id=?) ORDER BY schedule_time,id",(u["company_id"],u["inspector_id"])).fetchall():
            item=dict(schedule)
            item["days"]=item["days"].split(",") if item["days"] else []
            try: item["checkpoint_ids"]=json.loads(item["checkpoint_ids"] or "[]")
            except (TypeError,json.JSONDecodeError): item["checkpoint_ids"]=[]
            schedules.append(item)
    gap=minimum_point_gap(c)
    c.close(); scanned=sum(1 for r in rows if r["scanned"]==1); total=len(rows); pending=total-scanned
    return jsonify(ok=True,company_id=u["company_id"],company_name=u["company_name"],inspector_name=u.get("inspector_name") or u.get("inspector_username") or "Inspector",inspector_id=u.get("inspector_employee_id") or u.get("inspector_username") or "",inspector_record_id=u.get("inspector_id") or 0,user_id=u.get("inspector_username") or "",device_id=u.get("device_id") or "",inspection_active=bool(active),inspection_session_token=active["session_token"] if active else "",inspection_session_id=sid or 0,inspection_type=active["inspection_type"] if active else "",schedule_id=active["schedule_id"] if active else None,schedule_name=active["schedule_name"] if active else "",checkpoint_ids=active_checkpoint_ids,scanned_points=scanned,pending_points=pending,total_points=total,inspection_complete=bool(active and total>0 and scanned>=total),scan_gap_seconds=gap,locations=[dict(r) for r in rows],schedules=schedules,server_time_utc=datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00","Z"))

@app.get("/api/client/events")
def api_client_events():
    """Read-only, company-scoped scan sync for Client PC monitors."""
    try:
        company_id = int(request.args.get("company_id", ""))
        after_id = max(0, int(request.args.get("after_id", "0")))
        limit = min(100, max(1, int(request.args.get("limit", "100"))))
    except (TypeError, ValueError):
        return jsonify(ok=False, message="Invalid sync cursor or company ID."), 400

    configured_token = client_sync_token(company_id)
    if not configured_token:
        return jsonify(ok=False, message="Client sync is not configured for this company."), 403
    scheme, separator, supplied_token = request.headers.get("Authorization", "").partition(" ")
    if not separator or scheme.lower() != "bearer" or not hmac.compare_digest(supplied_token.strip(), configured_token):
        return jsonify(ok=False, message="Client sync authentication failed."), 401

    c = conn()
    try:
        rows = c.execute("""SELECT s.id AS cursor_id, CAST(s.company_id AS TEXT)||':'||CAST(s.id AS TEXT) AS event_id,
                s.company_id, COALESCE(co.name,'') AS company_name, COALESCE(s.point_code,'') AS point_code,
                COALESCE(p.name,'') AS point_name, COALESCE(s.inspector_name,'') AS inspector_name,
                COALESCE(s.device_id,'') AS device_id, s.scan_time, s.result, COALESCE(s.repeat_count,0) AS repeat_count,
                COALESCE(s.inspection_session_id,0) AS inspection_session_id,COALESCE(ins.inspection_type,'MANUAL') AS inspection_type,
                COALESCE(ins.schedule_name,'') AS schedule_name,COALESCE(s.sync_source,'LIVE') AS sync_source
            FROM scans s
            LEFT JOIN companies co ON co.id=s.company_id
            LEFT JOIN points p ON p.id=s.point_id
            LEFT JOIN inspection_sessions ins ON ins.id=s.inspection_session_id
            WHERE s.company_id=? AND s.id>?
            ORDER BY s.id ASC LIMIT ?""", (company_id, after_id, limit)).fetchall()
        events = [dict(row) for row in rows]
        next_after_id = int(rows[-1]["cursor_id"]) if rows else after_id
        return jsonify(ok=True, events=events, next_after_id=next_after_id, has_more=len(rows) == limit)
    finally:
        c.close()

@app.post("/api/mobile/scan")
def api_mobile_scan():
    u=mobile_auth()
    if not u: return jsonify(ok=False,message="Login required"),401
    d=request.get_json(silent=True) or {}; qr=str(d.get("qr_token","")).strip(); device=str(d.get("device_id",u["device_id"])).strip() or u["device_id"]; st=str(d.get("inspection_session_token","")).strip()
    if not qr: return jsonify(ok=False,message="QR token is required"),400
    if device != u["device_id"]: return jsonify(ok=False,message="Device ID does not match the logged-in device"),403
    if not st: return jsonify(ok=False,message="Start Inspection is required before scanning"),400
    if not license_is_active(u["company_id"]): return jsonify(ok=False,message="Company license is not active"),403
    c=conn()
    # Serialize the read/decide/write sequence so simultaneous scans cannot both
    # be recorded as the first accepted scan for one point in the same session.
    c.execute("BEGIN IMMEDIATE")
    sess=c.execute("SELECT * FROM inspection_sessions WHERE session_token=? AND company_id=? AND inspector_id=? AND device_id=? AND status='ACTIVE'",(st,u["company_id"],u["inspector_id"],u["device_id"])).fetchone()
    if not sess: c.close(); return jsonify(ok=False,message="Inspection session is not active. Press Start Inspection."),409
    point=c.execute("SELECT * FROM points WHERE qr_token=? AND status='ACTIVE' AND company_id=?",(qr,u["company_id"])).fetchone()
    if not point: c.close(); return jsonify(ok=False,message="Invalid QR or QR belongs to another company"),400
    try: assigned_ids=sorted(set(int(value) for value in json.loads(sess["checkpoint_ids"] or "[]")))
    except (TypeError,ValueError,json.JSONDecodeError): assigned_ids=[]
    if assigned_ids and point["id"] not in assigned_ids:
        c.close(); return jsonify(ok=False,message="Checkpoint is not assigned to this inspection schedule"),403
    count=c.execute("SELECT COUNT(*) n FROM scans WHERE inspection_session_id=? AND point_id=?",(sess["id"],point["id"])).fetchone()["n"]
    if count >= MAX_REPEATS + 1:
        c.close(); return jsonify(ok=True,result="REPEAT_ALERT",point_name=point["name"],point_code=point["point_code"],repeat_count=count,alert=True,message="Repeat Alert: this point has already been repeated in this inspection."),200
    point_gap=minimum_point_gap(c)
    if count==0 and point_gap>0:
        last=c.execute("SELECT scan_time FROM scans WHERE inspection_session_id=? ORDER BY id DESC LIMIT 1",(sess["id"],)).fetchone()
        if last:
            try:
                gap=(datetime.now()-datetime.strptime(last["scan_time"],"%Y-%m-%d %H:%M:%S")).total_seconds()
                if gap < point_gap:
                    c.close(); return jsonify(ok=False,result="TOO_FAST",message="Scanning too fast. Walk to the next point and scan the real QR code."),429
            except ValueError: pass
    inspector_name=u.get("inspector_name") or u.get("inspector_username") or "Inspector"; inspector_fk=u.get("inspector_id"); stamp=now_str()
    result="ACCEPTED" if count==0 else "REPEAT"; repeat_count=count
    c.execute("INSERT INTO scans(company_id,point_id,point_code,inspector_id,inspector_name,device_id,scan_time,result,inspection_session_id,repeat_count) VALUES(?,?,?,?,?,?,?,?,?,?)",(u["company_id"],point["id"],point["point_code"],inspector_fk,inspector_name,device,stamp,result,sess["id"],repeat_count))
    if assigned_ids:
        marks=",".join("?" for _ in assigned_ids)
        scanned=c.execute(f"SELECT COUNT(DISTINCT point_id) n FROM scans WHERE inspection_session_id=? AND result='ACCEPTED' AND point_id IN ({marks})",(sess["id"],*assigned_ids)).fetchone()["n"]
        total=len(assigned_ids)
    else:
        scanned=c.execute("SELECT COUNT(DISTINCT point_id) n FROM scans WHERE inspection_session_id=? AND result='ACCEPTED'",(sess["id"],)).fetchone()["n"]
        total=c.execute("SELECT COUNT(*) n FROM points WHERE company_id=? AND status='ACTIVE'",(u["company_id"],)).fetchone()["n"]
    complete=(total>0 and scanned>=total)
    if complete: c.execute("UPDATE inspection_sessions SET status='COMPLETED',ended_at=? WHERE id=?",(stamp,sess["id"]))
    c.commit(); c.close()
    return jsonify(ok=True,result=result,point_name=point["name"],point_code=point["point_code"],repeat_count=repeat_count,alert=False,scanned_points=scanned,pending_points=max(0,total-scanned),total_points=total,inspection_complete=complete,inspection_session_token=st)

@app.post("/api/admin/reveal-password")
@login_required
@roles_required("SUPER_ADMIN")
def api_admin_reveal_password():
    d=request.get_json(silent=True) or {}
    admin_password=str(d.get("admin_password", ""))
    target_type=str(d.get("target_type", "")).upper().strip()
    target_id=int(d.get("target_id",0) or 0)
    if not admin_password or not target_id or target_type not in ("USER","INSPECTOR"):
        return jsonify(ok=False,message="Invalid password-view request"),400
    me=get_user()
    c=conn()
    try:
        admin=c.execute("SELECT password_hash FROM users WHERE id=? AND role='SUPER_ADMIN' AND status='ACTIVE'",(me['id'],)).fetchone()
        if not admin or not verify_password(admin_password,admin['password_hash']):
            return jsonify(ok=False,message="Incorrect Super Admin password"),403
        if target_type=="USER":
            row=c.execute("SELECT password_secret,status FROM users WHERE id=?",(target_id,)).fetchone()
        else:
            row=c.execute("SELECT password_secret,status FROM inspectors WHERE id=?",(target_id,)).fetchone()
        if not row or row['status']=='DELETED':
            return jsonify(ok=False,message="Account not found"),404
        pw=reveal_secret(row['password_secret'] or '')
        if pw is None:
            return jsonify(ok=False,message="Password cannot be revealed because no recoverable password is stored. Use Reset Password."),409
        return jsonify(ok=True,password=pw)
    finally:
        c.close()

@app.get("/api/users")
@login_required
@roles_required("SUPER_ADMIN")
def api_users():
    c=conn()
    rows=c.execute("""SELECT u.id,u.company_id,u.username,u.full_name,u.role,u.status,u.details,u.created_at,u.deleted_at,
                     c.name company_name, c.code company_code
                     FROM users u LEFT JOIN companies c ON c.id=u.company_id
                     ORDER BY u.id DESC""").fetchall()
    c.close()
    return jsonify([dict(r) for r in rows])

@app.post("/api/users")
@login_required
@roles_required("SUPER_ADMIN")
def api_user_create():
    d=request.get_json(silent=True) or {}
    username=str(d.get('username','')).strip()
    full_name=str(d.get('full_name','')).strip()
    password=str(d.get('password',''))
    role=str(d.get('role','COMPANY_ADMIN')).strip().upper()
    company_id=d.get('company_id')
    details=str(d.get('details','')).strip()
    if not username or not full_name or len(password)<6 or role not in ('SUPER_ADMIN','COMPANY_ADMIN'):
        return jsonify(ok=False,message='Username, Full Name, valid role and password (minimum 6 characters) are required'),400
    if role=='COMPANY_ADMIN' and not str(company_id or '').isdigit():
        return jsonify(ok=False,message='Company is required for COMPANY_ADMIN'),400
    cid=int(company_id) if str(company_id or '').isdigit() else None
    c=conn()
    try:
        if c.execute("SELECT id FROM users WHERE lower(username)=lower(?) AND status!='DELETED'",(username,)).fetchone():
            return jsonify(ok=False,message='Username already exists'),400
        if cid and not c.execute("SELECT id FROM companies WHERE id=? AND status='ACTIVE'",(cid,)).fetchone():
            return jsonify(ok=False,message='Selected company is not active'),400
        c.execute("""INSERT INTO users(company_id,username,full_name,password_hash,password_secret,role,status,details,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?)""",(cid,username,full_name,hash_password(password),protect_secret(password),role,'ACTIVE',details,now_str()))
        uid=c.execute('SELECT last_insert_rowid()').fetchone()[0]
        c.commit(); audit(get_user()['id'],cid,'CREATE','USER',uid,username)
        return jsonify(ok=True,id=uid)
    except sqlite3.IntegrityError as e:
        c.rollback(); return jsonify(ok=False,message='User could not be created: '+str(e)),400
    finally: c.close()

@app.put("/api/users/<int:uid>")
@login_required
@roles_required("SUPER_ADMIN")
def api_user_update(uid):
    d=request.get_json(silent=True) or {}; c=conn()
    try:
        row=c.execute("SELECT * FROM users WHERE id=? AND status!='DELETED'",(uid,)).fetchone()
        if not row: return jsonify(ok=False,message='Active user not found'),404
        username=str(d.get('username',row['username'])).strip()
        full_name=str(d.get('full_name',row['full_name'] or '')).strip()
        details=str(d.get('details',row['details'] or '')).strip()
        role=str(d.get('role',row['role'])).upper().strip()
        company_id=d.get('company_id',row['company_id'])
        cid=int(company_id) if str(company_id or '').isdigit() else None
        if not username or not full_name or role not in ('SUPER_ADMIN','COMPANY_ADMIN'):
            return jsonify(ok=False,message='Username, Full Name and valid role are required'),400
        if role=='COMPANY_ADMIN' and not cid: return jsonify(ok=False,message='Company is required for COMPANY_ADMIN'),400
        if c.execute("SELECT id FROM users WHERE lower(username)=lower(?) AND id!=? AND status!='DELETED'",(username,uid)).fetchone():
            return jsonify(ok=False,message='Username already exists'),400
        if cid and not c.execute("SELECT id FROM companies WHERE id=? AND status='ACTIVE'",(cid,)).fetchone():
            return jsonify(ok=False,message='Selected company is not active'),400
        c.execute("UPDATE users SET company_id=?,username=?,full_name=?,details=?,role=? WHERE id=?",(cid,username,full_name,details,role,uid))
        if str(d.get('password','')).strip():
            pw=str(d['password']).strip()
            if len(pw)<6:return jsonify(ok=False,message='Password must be at least 6 characters'),400
            c.execute("UPDATE users SET password_hash=?,password_secret=? WHERE id=?",(hash_password(pw),protect_secret(pw),uid))
        c.commit(); audit(get_user()['id'],cid,'UPDATE','USER',uid,username)
        return jsonify(ok=True)
    except sqlite3.IntegrityError as e:
        c.rollback(); return jsonify(ok=False,message='User update failed: '+str(e)),400
    finally: c.close()

@app.post("/api/users/<int:uid>/reset-password")
@login_required
@roles_required("SUPER_ADMIN")
def api_user_reset_password(uid):
    d=request.get_json(silent=True) or {}; pw=str(d.get('password','')).strip()
    if len(pw)<6:return jsonify(ok=False,message='Password must be at least 6 characters'),400
    c=conn()
    row=c.execute("SELECT * FROM users WHERE id=? AND status!='DELETED'",(uid,)).fetchone()
    if not row:c.close();return jsonify(ok=False,message='Active user not found'),404
    c.execute("UPDATE users SET password_hash=?,password_secret=? WHERE id=?",(hash_password(pw),protect_secret(pw),uid));c.commit();c.close();audit(get_user()['id'],row['company_id'],'RESET_PASSWORD','USER',uid,row['username']);return jsonify(ok=True)

@app.put("/api/users/<int:uid>/status")
@login_required
@roles_required("SUPER_ADMIN")
def api_user_status(uid):
    d=request.get_json(silent=True) or {}; status=str(d.get('status','')).upper()
    if status not in ('ACTIVE','DISABLED'):return jsonify(ok=False,message='Invalid status'),400
    c=conn(); row=c.execute("SELECT * FROM users WHERE id=? AND status!='DELETED'",(uid,)).fetchone()
    if not row:c.close();return jsonify(ok=False,message='User not found'),404
    c.execute("UPDATE users SET status=? WHERE id=?",(status,uid));c.commit();c.close();audit(get_user()['id'],row['company_id'],'STATUS','USER',uid,status);return jsonify(ok=True)

@app.delete("/api/users/<int:uid>")
@login_required
@roles_required("SUPER_ADMIN")
def api_user_delete(uid):
    me=get_user()
    if uid==me['id']:return jsonify(ok=False,message='You cannot delete the currently logged-in Super Admin'),400
    c=conn()
    try:
        row=c.execute("SELECT * FROM users WHERE id=? AND status!='DELETED'",(uid,)).fetchone()
        if not row:return jsonify(ok=False,message='Active user not found'),404
        stamp=now_str(); c.execute("UPDATE users SET status='DELETED',deleted_at=?,username=username||'~del'||id WHERE id=?",(stamp,uid))
        # Do not delete historical audit/license records.
        c.commit(); audit(me['id'],row['company_id'],'DELETE','USER',uid,row['username'])
        return jsonify(ok=True,message='User deleted',deleted_id=uid)
    except Exception as e:
        c.rollback(); return jsonify(ok=False,message='User delete failed: '+str(e)),500
    finally:c.close()

# ---------------------- Dashboard / Audit / Deleted / Settings / Report APIs ----------------------
@app.get("/api/dashboard")
@login_required
@licensed_required
def api_dashboard():
    u=get_user(); cid=request_company_id(u); c=conn()
    today="date(s.scan_time)=date('now','localtime')"
    wp=" AND p.company_id=?" if cid else ""; args=[cid] if cid else []
    pts=[dict(r) for r in c.execute(f"""SELECT p.id,p.point_code,p.name,co.name company_name,
        (SELECT MAX(s.scan_time) FROM scans s WHERE s.point_id=p.id AND s.result='ACCEPTED' AND {today}) AS last_scan,
        (SELECT s.inspector_name FROM scans s WHERE s.point_id=p.id AND s.result='ACCEPTED' AND {today} ORDER BY s.id DESC LIMIT 1) AS last_inspector
        FROM points p JOIN companies co ON co.id=p.company_id
        WHERE p.status='ACTIVE' AND co.status='ACTIVE'{wp} ORDER BY p.company_id,p.id""",args).fetchall()]
    total=len(pts); scanned=sum(1 for x in pts if x["last_scan"])
    ws=" AND s.company_id=?" if cid else ""
    repeat_today=c.execute(f"SELECT COUNT(*) n FROM scans s WHERE s.result='REPEAT' AND {today}{ws}",args).fetchone()["n"]
    wi=" AND i.company_id=?" if cid else ""
    active_inspectors=c.execute(f"SELECT COUNT(*) n FROM inspectors i JOIN companies co ON co.id=i.company_id WHERE i.status='ACTIVE' AND co.status='ACTIVE'{wi}",args).fetchone()["n"]
    wd=" AND d.company_id=?" if cid else ""
    active_devices=c.execute(f"SELECT COUNT(*) n FROM devices d JOIN companies co ON co.id=d.company_id WHERE d.status='ACTIVE' AND co.status='ACTIVE'{wd}",args).fetchone()["n"]
    total_companies=c.execute("SELECT COUNT(*) n FROM companies WHERE status='ACTIVE'").fetchone()["n"]
    company_name=None
    if cid:
        r=c.execute("SELECT name FROM companies WHERE id=?",(cid,)).fetchone(); company_name=r["name"] if r else None
    recent=[dict(r) for r in c.execute(f"""SELECT s.scan_time,s.inspection_session_id,s.point_code,s.inspector_name,s.device_id,s.result,s.repeat_count,
        COALESCE(ins.inspection_type,'MANUAL') inspection_type,COALESCE(ins.schedule_name,'') schedule_name,COALESCE(s.sync_source,'LIVE') sync_source,
        p.name point_name,co.name company_name FROM scans s LEFT JOIN points p ON p.id=s.point_id LEFT JOIN companies co ON co.id=s.company_id
        LEFT JOIN inspection_sessions ins ON ins.id=s.inspection_session_id
        WHERE 1=1{ws} ORDER BY s.id DESC LIMIT 15""",args).fetchall()]
    c.close()
    return jsonify(company_name=company_name,total_companies=total_companies,total_points=total,accepted_today=scanned,
                   pending=max(0,total-scanned),repeat_today=repeat_today,active_inspectors=active_inspectors,
                   active_devices=active_devices,completion=round(100*scanned/total) if total else 0,
                   points=pts,recent=recent)

@app.get("/api/audit")
@login_required
@roles_required("SUPER_ADMIN")
def api_audit():
    start=request.args.get("start","").strip(); end=request.args.get("end","").strip()
    username=request.args.get("username","").strip(); company_id=request.args.get("company_id","").strip()
    action=request.args.get("action","").strip(); entity_type=request.args.get("entity_type","").strip()
    entity_id=request.args.get("entity_id","").strip(); record_id=request.args.get("record_id","").strip()
    search=request.args.get("q","").strip(); where=" WHERE 1=1"; params=[]
    if start: where+=" AND date(a.created_at)>=?"; params.append(start)
    if end: where+=" AND date(a.created_at)<=?"; params.append(end)
    if username: where+=" AND COALESCE(u.username,'system') LIKE ?"; params.append("%"+username+"%")
    if company_id:
        try: where+=" AND a.company_id=?"; params.append(int(company_id))
        except (TypeError,ValueError): return jsonify(ok=False,message="Invalid company ID"),400
    if action: where+=" AND a.action LIKE ?"; params.append("%"+action+"%")
    if entity_type: where+=" AND COALESCE(a.entity_type,'') LIKE ?"; params.append("%"+entity_type+"%")
    if entity_id: where+=" AND COALESCE(a.entity_id,'') LIKE ?"; params.append("%"+entity_id+"%")
    if record_id:
        try: where+=" AND a.id=?"; params.append(int(record_id))
        except (TypeError,ValueError): return jsonify(ok=False,message="Audit record ID must be a number"),400
    if search:
        term="%"+search+"%"; where+=" AND (COALESCE(u.username,'system') LIKE ? OR COALESCE(co.name,'') LIKE ? OR a.action LIKE ? OR COALESCE(a.entity_type,'') LIKE ? OR COALESCE(a.entity_id,'') LIKE ? OR COALESCE(a.details,'') LIKE ?)"; params.extend([term,term,term,term,term,term])
    c=conn()
    rows=c.execute("""SELECT a.id,a.created_at,COALESCE(u.username,'system') AS username,co.name AS company_name,a.action,
        COALESCE(a.entity_type,'') AS entity_type,COALESCE(a.entity_id,'') AS entity_id,COALESCE(a.details,'') AS details
        FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id LEFT JOIN companies co ON co.id=a.company_id"""+where+
        " ORDER BY a.id DESC LIMIT 2000",params).fetchall(); c.close()
    out=[]
    for r in rows:
        d=dict(r); d["username"]=undel(d["username"]); out.append(d)
    return jsonify(out)

@app.get("/api/audit/options")
@login_required
@roles_required("SUPER_ADMIN")
def api_audit_options():
    c=conn()
    try:
        return jsonify(
            users=[undel(r[0]) for r in c.execute("SELECT DISTINCT COALESCE(u.username,'system') FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY 1 LIMIT 2000").fetchall()],
            companies=[{"id":r["id"],"name":undel(r["name"]),"code":undel(r["code"])} for r in c.execute("SELECT id,name,code FROM companies ORDER BY name LIMIT 2000").fetchall()],
            actions=[r[0] for r in c.execute("SELECT DISTINCT action FROM audit_logs WHERE TRIM(COALESCE(action,''))!='' ORDER BY action LIMIT 2000").fetchall()],
            entity_types=[r[0] for r in c.execute("SELECT DISTINCT entity_type FROM audit_logs WHERE TRIM(COALESCE(entity_type,''))!='' ORDER BY entity_type LIMIT 2000").fetchall()],
            entity_ids=[r[0] for r in c.execute("SELECT DISTINCT entity_id FROM audit_logs WHERE TRIM(COALESCE(entity_id,''))!='' ORDER BY entity_id LIMIT 2000").fetchall()])
    finally: c.close()

@app.get("/api/deleted")
@login_required
@roles_required("SUPER_ADMIN")
def api_deleted():
    c=conn()
    companies=[dict(r) for r in c.execute("SELECT id,name,code,deleted_at FROM companies WHERE status='DELETED' ORDER BY deleted_at DESC,id DESC").fetchall()]
    users=[dict(r) for r in c.execute("""SELECT u.id,u.username,u.full_name,u.deleted_at,co.name company_name FROM users u
        LEFT JOIN companies co ON co.id=u.company_id WHERE u.status='DELETED' ORDER BY u.deleted_at DESC,u.id DESC""").fetchall()]
    inspectors=[dict(r) for r in c.execute("""SELECT i.id,i.employee_id,i.name,i.deleted_at,i.permanently_deleted,co.name company_name FROM inspectors i
        LEFT JOIN companies co ON co.id=i.company_id WHERE i.status='DELETED' ORDER BY i.deleted_at DESC,i.id DESC""").fetchall()]
    devices=[dict(r) for r in c.execute("""SELECT d.id,d.device_id,d.deleted_at,d.permanently_deleted,co.name company_name FROM devices d
        LEFT JOIN companies co ON co.id=d.company_id WHERE d.status='DELETED' ORDER BY d.deleted_at DESC,d.id DESC""").fetchall()]
    points=[dict(r) for r in c.execute("""SELECT p.id,p.point_code,p.name,p.deleted_at,co.name company_name FROM points p
        LEFT JOIN companies co ON co.id=p.company_id WHERE p.status='DELETED' ORDER BY p.deleted_at DESC,p.id DESC""").fetchall()]
    c.close()
    for x in companies: x["code"]=undel(x["code"])
    for x in users: x["username"]=undel(x["username"])
    for x in points: x["point_code"]=undel(x["point_code"])
    return jsonify(companies=companies,users=users,inspectors=inspectors,devices=devices,points=points)

SETTING_KEYS=("daily_target","repeat_policy","company_label","notes","min_point_gap_seconds")

@app.route("/api/settings", methods=["GET","POST"])
@login_required
@licensed_required
def api_settings():
    u=get_user(); cid=u["company_id"] or 0
    c=conn()
    try:
        if request.method=="GET":
            rows=c.execute("SELECT setting_key,setting_value FROM settings WHERE company_id=?",(cid,)).fetchall()
            result={r["setting_key"]:r["setting_value"] for r in rows if r["setting_key"] in SETTING_KEYS}
            if u["role"] == "SUPER_ADMIN":
                result.setdefault("min_point_gap_seconds", str(minimum_point_gap(c)))
            return jsonify(result)
        d=request.get_json(silent=True) or {}
        allowed_keys=SETTING_KEYS if u["role"] == "SUPER_ADMIN" else SETTING_KEYS[:-1]
        values={k:str(d.get(k,"")).strip()[:500] for k in allowed_keys if k in d}
        if values.get("daily_target") and not values["daily_target"].isdigit():
            return jsonify(ok=False,message="Daily target must be a number"),400
        if "min_point_gap_seconds" in values:
            try:
                gap=int(values["min_point_gap_seconds"])
            except ValueError:
                gap=-1
            if not 0 <= gap <= 300:
                return jsonify(ok=False,message="Scan gap must be from 0 to 300 seconds"),400
            values["min_point_gap_seconds"]=str(gap)
            cid=0
        for k,v in values.items():
            c.execute("""INSERT INTO settings(company_id,setting_key,setting_value) VALUES(?,?,?)
                         ON CONFLICT(company_id,setting_key) DO UPDATE SET setting_value=excluded.setting_value""",(cid,k,v))
        c.commit()
    except Exception as e:
        c.rollback(); return jsonify(ok=False,message="Settings could not be saved: "+str(e)),500
    finally:
        c.close()
    audit(u["id"],u["company_id"],"UPDATE","SETTINGS",cid,"Settings updated")
    return jsonify(ok=True)


@app.route("/api/admin/backups", methods=["GET", "POST"])
@login_required
@roles_required("SUPER_ADMIN")
def api_admin_backups():
    if request.method == "GET":
        folder=configured_backup_directory()
        files=[]
        if folder.is_dir():
            for item in sorted(folder.glob("central_*.db"), key=lambda path: path.stat().st_mtime, reverse=True)[:50]:
                try:
                    stat=item.stat()
                    files.append({"name":item.name,"size_bytes":stat.st_size,"created_at":datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")})
                except OSError:
                    continue
        return jsonify(ok=True,directory=str(folder),database=str(Path(DB).resolve()),automatic_backup="Daily; older backups are kept",backups=files)

    user=get_user(); data=request.get_json(silent=True) or {}; action=str(data.get("action", "")).strip().lower()
    try:
        if action == "save_directory":
            raw=str(data.get("directory", "")).strip()
            folder=Path(raw).expanduser().resolve() if raw else DEFAULT_BACKUP_DIR
            if folder == Path(DB).resolve().parent or path_is_within(folder, Path(BASE_DIR).parent):
                return jsonify(ok=False,message="Choose a backup folder outside the live database and project folders"),400
            folder.mkdir(parents=True, exist_ok=True)
            probe=folder / (".rti-write-check-"+secrets.token_hex(8))
            try:
                with probe.open("xb") as handle:
                    handle.write(b"ok")
            finally:
                probe.unlink(missing_ok=True)
            c=conn()
            try:
                c.execute("INSERT INTO settings(company_id,setting_key,setting_value) VALUES(0,'backup_directory',?) ON CONFLICT(company_id,setting_key) DO UPDATE SET setting_value=excluded.setting_value",(str(folder),))
                c.commit()
            finally:
                c.close()
            audit(user["id"],None,"UPDATE","BACKUP_SETTINGS","0",str(folder))
            return jsonify(ok=True,directory=str(folder),message="Backup folder saved")
        if action == "backup_now":
            created=create_database_backup()
            audit(user["id"],None,"BACKUP","DATABASE","0",created.name)
            return jsonify(ok=True,name=created.name,path=str(created),size_bytes=created.stat().st_size,message="Backup completed")
        if action == "restore":
            rollback=restore_database_backup(str(data.get("name", "")))
            try:
                audit(user["id"],None,"RESTORE","DATABASE","0",str(data.get("name", "")))
            except sqlite3.Error:
                app.logger.warning("Restore succeeded but the previous audit actor is absent from the restored database")
            return jsonify(ok=True,name=str(data.get("name", "")),rollback_backup=rollback.name,
                           message="Restore completed. The database that was active before restore is saved as " + rollback.name)
        return jsonify(ok=False,message="Choose a valid backup action"),400
    except (OSError, ValueError, sqlite3.Error, RuntimeError) as exc:
        return jsonify(ok=False,message="Backup operation failed: "+str(exc)),400

def _csv_safe(value):
    text="" if value is None else str(value)
    return "'"+text if text[:1] in ("=","+","-","@","\t","\r") else text

@app.get("/api/report.csv")
@login_required
@licensed_required
def api_report_csv():
    resp=api_history()
    if not hasattr(resp,"get_json"):
        return resp
    rows=resp.get_json() or []
    buf=io.StringIO(); w=csv.writer(buf)
    w.writerow(["Company","Scan Time","Session ID","Inspection Type","Schedule","Sync Source","Point Code","Point Name","Inspector","Inspector ID","Device ID","Result","Repeat #"])
    for r in rows:
        w.writerow([_csv_safe(r.get(k)) for k in ("company_name","scan_time","inspection_session_id","inspection_type","schedule_name","sync_source","point_code","point_name","inspector_name","inspector_employee_id","device_id","result","repeat_count")])
    return Response("\ufeff"+buf.getvalue(),mimetype="text/csv",
                    headers={"Content-Disposition":"attachment; filename=AB_Securitas_Report_"+date.today().isoformat()+".csv"})

# ---------------------- Page bodies ----------------------
DASHBOARD_BODY = r"""
<div id="companybar" class="panel" style="display:none"><div class="toolbar" style="margin:0"><div class="field"><label class="field-label" for="companySelect">Company View</label><select id="companySelect" onchange="load()"><option value="">All Companies</option></select></div></div></div>
<div id="cards" class="cards"></div>
<div class="grid2">
<div class="panel"><h2>Inspection Points — Live Status</h2><div class="tablewrap"><table><thead><tr><th>Company</th><th>Point</th><th>Status</th><th>Last Scan</th><th>Inspector</th></tr></thead><tbody id="points"></tbody></table></div></div>
<div><div class="panel"><h2>Today's Scan Progress</h2><div id="progressText" style="font-size:30px;font-weight:800">0%</div><div class="progress"><div id="bar" class="bar" style="width:0%"></div></div><p id="progressSub" class="sub"></p></div>
<div class="panel"><h2>Latest Activity</h2><div id="latest" class="muted">No scans yet</div></div></div></div>
<div class="panel"><h2>Recent Activity</h2><div class="tablewrap"><table><thead><tr><th>Time</th><th>Session</th><th>Mode</th><th>Schedule</th><th>Sync Source</th><th>Company</th><th>Point</th><th>Inspector</th><th>Device</th><th>Result</th><th>Repeat #</th></tr></thead><tbody id="recent"></tbody></table></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
let companiesLoaded=false;
async function loadCompanies(){
 const me=await (await fetch('/api/me')).json();
 if(me.role==='SUPER_ADMIN'){companybar.style.display='block';let cs=await(await fetch('/api/companies')).json();companySelect.innerHTML='<option value="">All Companies</option>'+cs.map(c=>`<option value="${c.id}">${esc(c.name)} (${esc(c.code)})</option>`).join('');companiesLoaded=true}
}
async function load(){
 if(!companiesLoaded) await loadCompanies();
 let url='/api/dashboard'; if(companySelect && companySelect.value) url+='?company_id='+encodeURIComponent(companySelect.value);
 const d=await(await fetch(url)).json();
 cards.innerHTML=[
 [d.company_name?'COMPANY NAME':'TOTAL COMPANIES',d.company_name||d.total_companies,d.company_name?'Customer account':'Active customer companies'],
 ['TOTAL POINTS',d.total_points,'Configured active points'],
 ['SCANNED TODAY',d.accepted_today,'Accepted first scans'],
 ['PENDING',d.pending,'Not yet accepted today'],
 ['REPEAT SCANS',d.repeat_today,'Repeated scans today'],
 ['ACTIVE INSPECTORS',d.active_inspectors,'Active inspectors'],
 ['ACTIVE DEVICES',d.active_devices,'Active mobile devices']
 ].map(x=>`<div class="card"><div class="label">${x[0]}</div><div class="num">${x[1]}</div><div class="sub">${x[2]}</div></div>`).join('');
 progressText.textContent=d.completion+'%';bar.style.width=d.completion+'%';progressSub.textContent=d.accepted_today+' of '+d.total_points+' points completed today';
 points.innerHTML=d.points.length?d.points.map(x=>`<tr><td>${esc(x.company_name||'Current Company')}</td><td><b>${esc(x.point_code)}</b> — ${esc(x.name)}</td><td><span class="badge ${x.last_scan?'green':'gray'}">${x.last_scan?'SCANNED':'PENDING'}</span></td><td>${esc(x.last_scan||'—')}</td><td>${esc(x.last_inspector||'—')}</td></tr>`).join(''):'<tr><td colspan="5" class="empty">No active points found.</td></tr>';
  recent.innerHTML=d.recent.length?d.recent.map(x=>`<tr><td>${esc(x.scan_time)}</td><td>${esc(x.inspection_session_id||'—')}</td><td>${esc(x.inspection_type||'MANUAL')}</td><td>${esc(x.schedule_name||'—')}</td><td>${esc(x.sync_source||'LIVE')}</td><td>${esc(x.company_name||'')}</td><td>${esc(x.point_code)} — ${esc(x.point_name||'')}</td><td>${esc(x.inspector_name)}</td><td>${esc(x.device_id)}</td><td><span class="badge ${x.result==='ACCEPTED'?'green':'yellow'}">${esc(x.result)}</span></td><td>${esc(x.repeat_count||0)}</td></tr>`).join(''):'<tr><td colspan="11" class="empty">No recent scans.</td></tr>';
 const r=d.recent[0];latest.innerHTML=r?`<b>${esc(r.point_code)} — ${esc(r.point_name||'')}</b><br><span class="muted">${esc(r.scan_time)} · ${esc(r.inspector_name)} · ${esc(r.result)}</span>`:'No scans yet';
}
load();setInterval(load,5000);
</script>
"""

COMPANIES_BODY = r"""
<div class="panel"><h2>Add Customer Company</h2><div class="formgrid">
<div class="field"><label class="field-label" for="company_name">Company Name</label><input id="company_name" placeholder="Enter company name"></div>
<div class="field"><label class="field-label" for="company_code">Company Code</label><input id="company_code" placeholder="e.g. CUST001"></div>
<div class="field"><label class="field-label" for="contact_person">Contact Person</label><input id="contact_person" placeholder="Enter contact person"></div>
<div class="field"><label class="field-label" for="phone">Phone</label><input id="phone" placeholder="Enter phone"></div>
<div class="field"><label class="field-label" for="email">Email</label><input id="email" placeholder="Enter email"></div>
<div class="field full"><label class="field-label" for="address">Address</label><input id="address" placeholder="Enter address"></div>
</div><br><button class="btn" onclick="addCompany()">Create Company</button></div>
<div class="panel"><h2>Company Directory</h2><div class="notice"><b>Company ID</b> is the visible numeric ID to enter on Client PC Setup. Company Code is a different value.</div><div class="tablewrap"><table><thead><tr><th>Company ID</th><th>Company</th><th>Code</th><th>Contact</th><th>Phone</th><th>Email</th><th>Active Inspectors</th><th>Active Devices</th><th>Status</th><th>Actions</th></tr></thead><tbody id="companyRows"></tbody></table></div></div>
<div id="companyEditModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:center;justify-content:center"><div class="panel" style="width:min(760px,92vw)"><h2>Edit Company</h2><div class="formgrid">
<div class="field"><label class="field-label">Company Name</label><input id="edit_company_name"></div>
<div class="field"><label class="field-label">Company Code</label><input id="edit_company_code" readonly></div>
<div class="field"><label class="field-label">Contact Person</label><input id="edit_contact"></div>
<div class="field"><label class="field-label">Phone</label><input id="edit_phone"></div>
<div class="field"><label class="field-label">Email</label><input id="edit_email"></div>
<div class="field full"><label class="field-label">Address</label><input id="edit_address"></div>
</div><br><button class="btn" onclick="saveCompanyEdit()">Save Changes</button> <button class="btn gray" onclick="closeCompanyEdit()">Cancel</button><span id="companyEditMsg" class="sub" style="margin-left:10px"></span></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const companyRows=document.getElementById('companyRows'); let editingCompanyId=null,companyRowsData=[];
async function load(){const r=await (await fetch('/api/companies',{cache:'no-store'})).json();companyRowsData=Array.isArray(r)?r:[];companyRows.innerHTML=companyRowsData.map(x=>{const name=x.name||x.code,id=Number(x.id);return '<tr><td><strong class="badge blue">'+esc(id)+'</strong></td><td><b>'+esc(name)+'</b></td><td>'+esc(x.code)+'</td><td>'+esc(x.contact_person||'—')+'</td><td>'+esc(x.phone||'—')+'</td><td>'+esc(x.email||'—')+'</td><td>'+esc(x.active_inspectors||0)+'</td><td>'+esc(x.active_devices||0)+'</td><td><span class="badge '+(x.status==='ACTIVE'?'green':'gray')+'">'+esc(x.status)+'</span></td><td><button class="btn gray" onclick="openCompanyEditById('+id+')">Edit</button> <button class="btn gray" onclick="setStatus('+id+',&quot;'+(x.status==='ACTIVE'?'DISABLED':'ACTIVE')+'&quot;)">'+(x.status==='ACTIVE'?'Disable':'Enable')+'</button> <button class="btn red" data-company="'+esc(name)+'" onclick="deleteCompany('+id+',this.dataset.company)">Delete</button></td></tr>'}).join('')||'<tr><td colspan="10" class="empty">No companies found.</td></tr>'}
function openCompanyEditById(id){const row=companyRowsData.find(x=>Number(x.id)===Number(id));if(row)openCompanyEdit(row)}
async function addCompany(){const d={name:company_name.value.trim(),code:company_code.value.trim(),contact_person:contact_person.value.trim(),phone:phone.value.trim(),email:email.value.trim(),address:address.value.trim()};if(!d.name||!d.code)return alert('Company Name and Company Code are required.');const r=await fetch('/api/companies',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});const x=await r.json();if(!x.ok)return alert(x.message||'Unable to create company');['company_name','company_code','contact_person','phone','email','address'].forEach(id=>document.getElementById(id).value='');await load();alert('Company created. Use Company ID '+x.id+' in Client PC Setup.')}
function openCompanyEdit(x){editingCompanyId=x.id;edit_company_name.value=x.name||'';edit_company_code.value=x.code||'';edit_contact.value=x.contact_person||'';edit_phone.value=x.phone||'';edit_email.value=x.email||'';edit_address.value=x.address||'';companyEditMsg.textContent='';companyEditModal.style.display='flex'}
function closeCompanyEdit(){companyEditModal.style.display='none';editingCompanyId=null}
async function saveCompanyEdit(){if(!editingCompanyId)return;const d={name:edit_company_name.value.trim(),address:edit_address.value.trim(),contact_person:edit_contact.value.trim(),phone:edit_phone.value.trim(),email:edit_email.value.trim()};if(!d.name)return companyEditMsg.textContent='Company name is required';const r=await fetch('/api/companies/'+editingCompanyId,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});const x=await r.json();if(!r.ok||!x.ok)return companyEditMsg.textContent=x.message||'Update failed';closeCompanyEdit();await load();alert('Company updated successfully')}
async function setStatus(id,status){const r=await fetch('/api/companies/'+id,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});const x=await r.json();if(!x.ok)return alert(x.message||'Status update failed');await load()}
async function deleteCompany(id,name){if(!confirm('Delete '+name+'? It will disappear from active lists and remain in Deleted History.'))return;const r=await fetch('/api/companies/'+id,{method:'DELETE',cache:'no-store'});let x={};try{x=await r.json()}catch(e){}if(!r.ok||!x.ok)return alert(x.message||('Delete failed (HTTP '+r.status+')'));await load();alert('Company deleted successfully.')}
load();
</script>
"""

POINTS_BODY = r"""
<div id="companyBox" class="panel" style="display:none"><div class="field"><label class="field-label" for="company_id">Company</label><select id="company_id" onchange="load()"><option value="">Select Company</option></select></div></div>
<div id="companyPrompt" class="notice" style="display:none">Select a company above to view its check points.</div>
<div id="clientNotice" class="notice" style="display:none">Check points are managed by AB SECURITAS. Your company can view and print the assigned QR codes, but cannot add or modify check points.</div>
<div id="adminAdd" class="panel" style="display:none"><h2>Add Check Point</h2><div class="formgrid"><div class="field"><label class="field-label" for="point_code">Point Code</label><input id="point_code" placeholder="e.g. P11"></div><div class="field"><label class="field-label" for="point_name">Point Name</label><input id="point_name" placeholder="Enter point name"></div><div class="field"><label class="field-label" for="point_location">Location</label><input id="point_location" placeholder="Enter location"></div><div class="field"><label class="field-label" for="point_desc">Description</label><input id="point_desc" placeholder="Enter description"></div></div><br><button class="btn" onclick="addPoint()">Add Point</button></div>
<div class="panel"><h2>Point Directory</h2><div class="tablewrap"><table><thead><tr><th>Company</th><th>Code</th><th>Name</th><th>Location</th><th>Status</th><th>Last Scan</th><th>QR</th><th>Actions</th></tr></thead><tbody id="rows"></tbody></table></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const rowsEl=document.getElementById('rows'); const modal=document.getElementById('qrModal');
async function setup(){let me=await(await fetch('/api/me')).json();if(me.role==='SUPER_ADMIN'){adminAdd.style.display='block';companyBox.style.display='block';let cs=await(await fetch('/api/companies')).json();company_id.innerHTML='<option value="">Select Company</option>'+cs.filter(c=>c.status==='ACTIVE').map(c=>`<option value="${c.id}">${esc(c.name)} (${esc(c.code)})</option>`).join('');companyPrompt.style.display='block'}else{clientNotice.style.display='block'}load()}
async function load(){let cid=document.getElementById('company_id');if(cid && !cid.value && companyBox.style.display!=='none'){rowsEl.innerHTML='<tr><td colspan="8" class="empty">Select a company to view its check points.</td></tr>';return}let q=cid&&cid.value?'?company_id='+encodeURIComponent(cid.value):'';let r=await(await fetch('/api/points'+q)).json();if(!Array.isArray(r)){rowsEl.innerHTML='<tr><td colspan="8" class="empty">Unable to load points.</td></tr>';return}let superAdmin=companyBox.style.display!=='none';rowsEl.innerHTML=r.map(x=>`<tr><td>${esc(x.company_name||'Current Company')}</td><td><b>${esc(x.point_code)}</b></td><td>${esc(x.name)}</td><td>${esc(x.location)}</td><td><span class="badge ${x.status==='ACTIVE'?'green':'gray'}">${esc(x.status)}</span></td><td>${esc(x.last_scan||'—')}</td><td>${superAdmin&&x.status==='ACTIVE'?`<a class="btn gray" href="/points/${x.id}/qr">View/Print</a>`:'—'}</td><td>${superAdmin&&x.status==='ACTIVE'?`<button class="btn gray" onclick='editPoint(${x.id},${rtiJsArg(x.point_code)},${rtiJsArg(x.name)},${rtiJsArg(x.location||'')},${rtiJsArg(x.description||'')})'>Edit</button> <button class="btn red" onclick="disablePoint(${x.id})">Disable</button> <button class="btn gray" onclick="regen(${x.id})">Regenerate</button>`:'—'}</td></tr>`).join('')||'<tr><td colspan="8" class="empty">No check points for this company.</td></tr>'}
async function addPoint(){let d={point_code:point_code.value,name:point_name.value,location:point_location.value,description:point_desc.value,company_id:company_id.value};let r=await fetch('/api/points',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});let x=await r.json();if(!x.ok)return alert(x.message);load()}
async function editPoint(id,code,name,loc,desc){let n=prompt('Point name',name);if(n===null)return;let r=await fetch('/api/points/'+id,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({point_code:code,name:n,location:loc,description:desc,status:'ACTIVE'})});let x=await r.json();if(!x.ok)return alert(x.message);load()}
async function disablePoint(id){if(!confirm('Delete this point? It will disappear from active lists and historical scans will remain.'))return;let r=await fetch('/api/points/'+id,{method:'DELETE'});let x=await r.json();if(!x.ok)return alert(x.message);load()}
async function regen(id){if(!confirm('Regenerate QR? The old QR will stop being valid.'))return;let r=await fetch('/api/points/'+id+'/regenerate-qr',{method:'POST'});let x=await r.json();if(!x.ok)return alert(x.message);load()}
setup();
</script>
"""

INSPECTORS_BODY = r"""
<div id="companyBox" class="panel" style="display:none"><div class="field"><label class="field-label" for="company_id">Company</label><select id="company_id"></select></div></div>
<div class="panel"><h2>Add Inspector</h2><div class="formgrid">
<div class="field"><label class="field-label" for="employee_id">Inspector ID / Employee ID</label><input id="employee_id" placeholder="Inspector ID"></div>
<div class="field"><label class="field-label" for="inspector_name">Inspector Name</label><input id="inspector_name" placeholder="Inspector Name"></div>
<div class="field"><label class="field-label" for="phone">Phone</label><input id="phone" placeholder="Phone"></div>
<div class="field"><label class="field-label" for="login_username">User ID</label><input id="login_username" placeholder="Mobile login User ID"></div>
<div class="field"><label class="field-label" for="login_password">Password</label><input id="login_password" type="password" placeholder="Mobile login Password"></div>
<div class="field"><label class="field-label" for="device_display">Device ID</label><input id="device_display" value="AUTO — assigned on first mobile login" readonly><small class="muted">Device ID is generated automatically by the mobile device and is non-editable. The first login binds it to this company; the same device can be shared by multiple inspectors.</small></div>
</div><br><button class="btn" onclick="addInspector()">Add Inspector</button><span id="addMsg" class="sub" style="margin-left:10px"></span></div>
<div class="panel"><h2>Active Inspectors & Devices</h2><div class="tablewrap"><table><thead><tr><th>Company</th><th>Inspector ID</th><th>Name</th><th>User ID</th><th>Phone</th><th>Device ID</th><th>Status</th><th>Actions</th></tr></thead><tbody id="rows"></tbody></table></div></div>
<div id="editModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:center;justify-content:center"><div class="panel" style="width:min(650px,92vw)"><h2>Edit Inspector</h2><div class="formgrid"><div class="field"><label class="field-label">Inspector ID / Employee ID</label><input id="edit_emp"></div><div class="field"><label class="field-label">Inspector Name</label><input id="edit_name"></div><div class="field"><label class="field-label">Phone</label><input id="edit_phone"></div><div class="field"><label class="field-label">User ID</label><input id="edit_user"></div><div class="field"><label class="field-label">New Password (optional)</label><input id="edit_pass" type="password" placeholder="Leave blank to keep current"></div><div class="field"><label class="field-label">Device ID</label><input id="edit_device" readonly></div></div><br><button class="btn" onclick="saveEdit()">Save Changes</button> <button class="btn gray" onclick="closeEdit()">Cancel</button><span id="editMsg" class="sub" style="margin-left:10px"></span></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
let editingId=null;
async function setup(){let me=await(await fetch('/api/me')).json();if(me.role==='SUPER_ADMIN'){companyBox.style.display='block';let cs=await(await fetch('/api/companies')).json();company_id.innerHTML=cs.filter(c=>c.status==='ACTIVE').map(c=>`<option value="${c.id}">${esc(c.name)} (${esc(c.code)})</option>`).join('');} await load();}
async function load(){let rr=await fetch('/api/inspectors');let r=await rr.json();if(!rr.ok){alert(r.message||'Unable to load inspectors');return;}rows.innerHTML=r.map(x=>`<tr><td>${esc(x.company_name||'')}</td><td>${esc(x.employee_id)}</td><td><b>${esc(x.name)}</b></td><td>${esc(x.login_username||'—')}</td><td>${esc(x.phone||'—')}</td><td><b>${esc(x.device_id||'—')}</b></td><td><span class="badge ${x.status==='ACTIVE'?'green':'gray'}">${esc(x.status)}</span></td><td><button class="btn gray" onclick='openEdit(${rtiJsArg(x)})'>Edit</button> <button class="btn gray" onclick="viewPassword('INSPECTOR',${x.id})">View Password</button> <button class="btn gray" onclick="setStatus(${x.id},'${x.status==='ACTIVE'?'DISABLED':'ACTIVE'}')">${x.status==='ACTIVE'?'Disable':'Enable'}</button> <button class="btn red" onclick="deleteInspector(${x.id},${rtiJsArg(x.name)})">Delete</button></td></tr>`).join('')||'<tr><td colspan="8" class="empty">No active inspectors.</td></tr>'}
async function addInspector(){let d={employee_id:employee_id.value.trim(),name:inspector_name.value.trim(),phone:phone.value.trim(),login_username:login_username.value.trim(),login_password:login_password.value};if(company_id&&company_id.value)d.company_id=company_id.value;if(!d.employee_id||!d.name||!d.login_username||!d.login_password)return alert('Inspector ID, Name, User ID and Password are required.');let rr=await fetch('/api/inspectors',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});let x=await rr.json();if(!rr.ok||!x.ok)return alert(x.message||'Inspector creation failed');alert('Inspector created. Device ID: '+x.device_id);['employee_id','inspector_name','phone','login_username','login_password'].forEach(id=>document.getElementById(id).value='');device_display.value='AUTO — assigned on first mobile login';await load();}
function openEdit(x){editingId=x.id;edit_emp.value=x.employee_id||'';edit_name.value=x.name||'';edit_phone.value=x.phone||'';edit_user.value=x.login_username||'';edit_pass.value='';edit_device.value=x.device_id||'';editMsg.textContent='';editModal.style.display='flex';}
function closeEdit(){editModal.style.display='none';editingId=null;}
async function saveEdit(){if(!editingId)return;let d={employee_id:edit_emp.value.trim(),name:edit_name.value.trim(),phone:edit_phone.value.trim(),login_username:edit_user.value.trim()};if(edit_pass.value)d.login_password=edit_pass.value;let rr=await fetch('/api/inspectors/'+editingId,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});let x=await rr.json();if(!rr.ok||!x.ok){editMsg.textContent=x.message||'Update failed';return;}closeEdit();await load();alert('Inspector updated successfully');}
async function setStatus(id,status){let rr=await fetch('/api/inspectors/'+id,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});let x=await rr.json();if(!rr.ok||!x.ok)return alert(x.message||'Status update failed');await load();}
async function deleteInspector(id,name){if(!confirm('Delete inspector '+name+'? It will disappear from the active list and remain in Deleted History.'))return;let rr=await fetch('/api/inspectors/'+id,{method:'DELETE'});let x=await rr.json();if(!rr.ok||!x.ok)return alert(x.message||'Delete failed');await load();alert('Inspector deleted successfully');}
async function viewPassword(type,id){const pw=prompt('Enter Super Admin password to view this password:');if(pw===null)return;const rr=await fetch('/api/admin/reveal-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({admin_password:pw,target_type:type,target_id:id})});const x=await rr.json();if(!rr.ok||!x.ok)return alert(x.message||'Unable to reveal password');alert('Password: '+x.password);}
setup();
</script>
"""
MONITOR_BODY = r"""
<div class="notice">Live view refreshes every 5 seconds. A point becomes <b>SCANNED</b> after its first accepted scan for the current day.</div>
<div class="panel"><div class="toolbar"><div class="field"><label class="field-label" for="companySelect">Company</label><select id="companySelect" onchange="load()"><option value="">All Companies</option></select></div><div class="field"><label class="field-label" for="statusSelect">Status</label><select id="statusSelect" onchange="load()"><option value="">All Status</option><option value="SCANNED">Scanned</option><option value="PENDING">Pending</option></select></div>
<div class="tablewrap"><table><thead><tr><th>Company</th><th>Point</th><th>Status</th><th>Last Scan</th><th>Inspector</th></tr></thead><tbody id="rows"></tbody></table></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
async function setup(){let me=await(await fetch('/api/me')).json();if(me.role==='SUPER_ADMIN'){let cs=await(await fetch('/api/companies')).json();companySelect.innerHTML='<option value="">All Companies</option>'+cs.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}else{companySelect.style.display='none'}}
async function load(){let q=companySelect.value?'?company_id='+companySelect.value:'';let r=await(await fetch('/api/points'+q)).json();let s=statusSelect.value;r=r.filter(x=>!s||((x.scanned_today?'SCANNED':'PENDING')===s));rows.innerHTML=r.map(x=>`<tr><td>${esc(x.company_name||'')}</td><td><b>${esc(x.point_code)}</b> — ${esc(x.name)}</td><td><span class="badge ${x.scanned_today?'green':'gray'}">${x.scanned_today?'SCANNED':'PENDING'}</span></td><td>${esc(x.last_scan||'—')}</td><td>${esc(x.last_inspector||'—')}</td></tr>`).join('')}
setup();load();setInterval(load,5000);
</script>
"""

DEVICE_BODY = r"""
<div class="notice"><b>Device ID must match the ID shown in the Android app.</b> Blocking or removing a device revokes its live sessions. Permanent removal keeps a blocked ID tombstone so the phone cannot silently register again; scan history and audit records remain. “Assigned inspectors only” rejects any inspector who has not been explicitly assigned below.</div>
<div class="panel"><div class="toolbar"><div class="field"><label class="field-label" for="deviceCompany">Company</label><select id="deviceCompany"><option value="">All companies</option></select></div><div class="field" style="flex:1"><label class="field-label" for="deviceSearch">Find a device</label><input id="deviceSearch" type="search" placeholder="Device ID, inspector, username…"></div><label class="field-label" style="display:flex;align-items:center;gap:8px;padding:10px"><input id="showRemovedDevices" type="checkbox" style="width:auto"> Show removed</label><button class="btn gray" type="button" onclick="loadDevices()">Refresh</button><span id="deviceCount" class="sub" role="status" aria-live="polite"></span></div>
<div class="tablewrap"><table><thead><tr><th>Company</th><th>Device ID</th><th>Inspectors with access</th><th>Access policy</th><th>Last seen</th><th>Status</th><th>Actions</th></tr></thead><tbody id="deviceRows"><tr><td colspan="7" class="empty">Loading devices…</td></tr></tbody></table></div></div>
<div id="deviceEditor" class="panel" style="display:none"><h2>Edit device access</h2><p id="deviceEditHelp" class="muted"></p><div class="formgrid"><div class="field"><label class="field-label" for="editDeviceId">Device ID</label><input id="editDeviceId" maxlength="80" autocomplete="off"></div><div class="field"><label class="field-label" for="editDevicePolicy">Login access</label><select id="editDevicePolicy"><option value="OPEN">Allow active company inspectors to register</option><option value="ASSIGNED">Assigned inspectors only</option></select></div><div class="field"><label class="field-label" for="editDeviceStatus">Device status</label><select id="editDeviceStatus"><option value="ACTIVE">Active</option><option value="DISABLED">Blocked</option><option value="DELETED">Removed (soft delete)</option></select></div><div class="field"><label class="field-label" for="editDeviceInspectors">Allowed inspectors</label><select id="editDeviceInspectors" multiple size="7" aria-describedby="deviceAssignmentHelp"></select><small id="deviceAssignmentHelp" class="muted">Use Ctrl-click or long-press to choose more than one inspector. Assigned inspectors use this exact Device ID.</small></div></div><div class="toolbar" style="margin-top:14px"><button class="btn" type="button" onclick="saveDevice()">Save device access</button><button class="btn gray" type="button" onclick="closeDeviceEditor()">Cancel</button><span id="deviceEditMessage" class="sub" role="status" aria-live="polite"></span></div></div>
<script>
const deviceEsc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
let managedDevices=[],managedInspectors=[],editingDevice=null;
async function loadDevices(){try{const query=new URLSearchParams();if(deviceCompany.value)query.set('company_id',deviceCompany.value);if(showRemovedDevices.checked)query.set('include_deleted','1');const [dr,ir]=await Promise.all([fetch('/api/devices?'+query,{cache:'no-store'}),fetch('/api/inspectors',{cache:'no-store'})]);if(!dr.ok||!ir.ok)throw new Error('Only Super Admin can manage devices.');managedDevices=await dr.json();managedInspectors=await ir.json();renderDevices()}catch(e){deviceRows.innerHTML='<tr><td colspan="7" class="empty">'+deviceEsc(e.message||'Unable to load devices')+'</td></tr>';deviceCount.textContent=''}}
function renderDevices(){const q=deviceSearch.value.trim().toLowerCase();const rows=managedDevices.filter(d=>!q||[d.company_name,d.device_id,d.status,d.access_policy,...(d.assigned_inspectors||[]).flatMap(i=>[i.name,i.employee_id,i.login_username])].join(' ').toLowerCase().includes(q));deviceRows.innerHTML=rows.map(d=>{const status=d.status==='ACTIVE'?'green':d.status==='DELETED'?'red':'yellow';const access=(d.assigned_inspectors||[]).map(i=>deviceEsc(i.name)+' · '+deviceEsc(i.employee_id||i.login_username||'')).join('<br>')||'<span class="muted">No inspectors assigned</span>';const policy=d.access_policy==='ASSIGNED'?'Assigned only':'Open registration';const action=d.permanently_deleted?'<span class="muted">Permanently removed · ID blocked</span>':d.status==='DELETED'?`<button class="btn gray" onclick="setDeviceStatus(${d.id},'ACTIVE')">Restore</button> <button class="btn red" onclick="permanentlyRemoveDevice(${d.id})">Permanently delete</button>`:`<button class="btn gray" onclick="editDevice(${d.id})">Edit / Access</button> <button class="btn gray" onclick="setDeviceStatus(${d.id},'${d.status==='ACTIVE'?'DISABLED':'ACTIVE'}')">${d.status==='ACTIVE'?'Block':'Enable'}</button> <button class="btn red" onclick="removeDevice(${d.id})">Remove</button>`;return `<tr><td>${deviceEsc(d.company_name||'')}<br><span class="muted">${deviceEsc(d.company_code||'')}</span></td><td><b>${deviceEsc(d.device_id)}</b></td><td>${access}</td><td>${deviceEsc(policy)}</td><td>${deviceEsc(d.last_seen||'Not connected yet')}</td><td><span class="badge ${status}">${deviceEsc(d.permanently_deleted?'PERMANENTLY REMOVED':d.status)}</span></td><td>${action}</td></tr>`}).join('')||'<tr><td colspan="7" class="empty">No devices match. A phone appears after its first successful login.</td></tr>';deviceCount.textContent=`${rows.length} device${rows.length===1?'':'s'}`}
async function loadDeviceCompanies(){const response=await fetch('/api/companies',{cache:'no-store'});if(!response.ok)return;const companies=await response.json();deviceCompany.replaceChildren(new Option('All companies',''),...companies.filter(c=>c.status!=='DELETED').map(c=>new Option(`${c.name} (${c.code})`,c.id)))}
function editDevice(id){const d=managedDevices.find(x=>x.id===id);if(!d)return;editingDevice=d;editDeviceId.value=d.device_id;editDevicePolicy.value=d.access_policy||'OPEN';editDeviceStatus.value=d.status;deviceEditHelp.textContent=`${d.company_name||''} · Changing this ID requires it to match the ID shown in that phone's login screen.`;const allowed=managedInspectors.filter(i=>i.company_id===d.company_id);editDeviceInspectors.replaceChildren(...allowed.map(i=>{const opt=new Option(`${i.name} · ${i.employee_id} · ${i.login_username}`,i.id);opt.selected=(d.assigned_inspector_ids||[]).includes(i.id);return opt}));deviceEditor.style.display='block';deviceEditMessage.textContent='';deviceEditor.scrollIntoView({behavior:'smooth',block:'start'})}
function closeDeviceEditor(){deviceEditor.style.display='none';editingDevice=null}
async function saveDevice(){if(!editingDevice)return;const d={device_id:editDeviceId.value.trim(),status:editDeviceStatus.value,access_policy:editDevicePolicy.value,inspector_ids:[...editDeviceInspectors.selectedOptions].map(o=>Number(o.value))};deviceEditMessage.textContent='Saving…';try{const r=await fetch('/api/devices/'+editingDevice.id,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}),x=await r.json();if(!r.ok||!x.ok){deviceEditMessage.textContent=x.message||'Update failed';return}deviceEditMessage.textContent=x.message||'Saved';await loadDevices();closeDeviceEditor()}catch(_){deviceEditMessage.textContent='Could not reach the server. Check the device list before retrying.'}}
async function setDeviceStatus(id,status){const d=managedDevices.find(x=>x.id===id);if(!d)return;const action=status==='ACTIVE'?'enable':'block';if(!confirm(`Do you want to ${action} ${d.device_id}?`))return;const r=await fetch('/api/devices/'+id,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({status,device_id:d.device_id,access_policy:d.access_policy,inspector_ids:(d.assigned_inspector_ids||[])})}),x=await r.json();if(!r.ok||!x.ok){alert(x.message||'Device status could not be updated');return}await loadDevices()}
async function removeDevice(id){const d=managedDevices.find(x=>x.id===id);if(!d||!confirm(`Remove ${d.device_id} from access? Historical scans will remain.`))return;const r=await fetch('/api/devices/'+id,{method:'DELETE'}),x=await r.json();if(!r.ok||!x.ok){alert(x.message||'Device could not be removed');return}await loadDevices()}
async function permanentlyRemoveDevice(id){const d=managedDevices.find(x=>x.id===id);if(!d||!confirm('Permanently block '+d.device_id+'? Its access will be erased, the ID will stay blocked, and history/audit will remain.'))return;const r=await fetch('/api/devices/'+id+'/permanent',{method:'DELETE'}),x=await r.json();if(!r.ok||!x.ok)return alert(x.message||'Device could not be permanently removed');await loadDevices();alert(x.message)}
deviceCompany.addEventListener('change',loadDevices);showRemovedDevices.addEventListener('change',loadDevices);deviceSearch.addEventListener('input',renderDevices);loadDeviceCompanies().then(loadDevices);
</script>
"""

HISTORY_BODY = r"""
<div class="panel"><div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap"><div><h2 style="margin-bottom:5px">Inspection history</h2><p class="muted" style="margin:0">Filter, review and trace every inspection scan. This view checks for new records automatically.</p></div><div id="historyLastUpdated" class="sub" role="status" aria-live="polite">Loading records…</div></div><div id="historyStats" class="cards" style="margin-top:16px"></div></div>
<div class="panel"><h2>Find inspection records</h2><div class="formgrid">
<div class="field"><label class="field-label" for="historySearch">Quick search</label><input id="historySearch" placeholder="Name, ID, point, schedule, device…"></div>
<div class="field"><label class="field-label" for="historyCompany">Company</label><select id="historyCompany"><option value="">All Companies</option></select></div>
<div class="field"><label class="field-label" for="historyStart">From date</label><input id="historyStart" type="date"></div><div class="field"><label class="field-label" for="historyEnd">To date</label><input id="historyEnd" type="date"></div>
<div class="field"><label class="field-label" for="historyPoint">Point code / name</label><input id="historyPoint" list="historyPointOptions" placeholder="Choose or type"><datalist id="historyPointOptions"></datalist></div>
<div class="field"><label class="field-label" for="historyInspector">Inspector name / username</label><input id="historyInspector" list="historyInspectorOptions" placeholder="Choose or type"><datalist id="historyInspectorOptions"></datalist></div>
<div class="field"><label class="field-label" for="historyInspectorId">Inspector ID</label><input id="historyInspectorId" list="historyInspectorIdOptions" placeholder="Employee or record ID"><datalist id="historyInspectorIdOptions"></datalist></div>
<div class="field"><label class="field-label" for="historyDevice">Device ID</label><input id="historyDevice" list="historyDeviceOptions" placeholder="Choose or type"><datalist id="historyDeviceOptions"></datalist></div>
<div class="field"><label class="field-label" for="historySchedule">Schedule</label><input id="historySchedule" list="historyScheduleOptions" placeholder="Choose or type"><datalist id="historyScheduleOptions"></datalist></div>
<div class="field"><label class="field-label" for="historyMode">Inspection category</label><select id="historyMode"><option value="">All categories</option><option value="MANUAL">Manual</option><option value="SCHEDULED">Scheduled</option></select></div>
<div class="field"><label class="field-label" for="historySource">Sync source</label><select id="historySource"><option value="">All sources</option><option value="LIVE">Live</option><option value="OFFLINE_QUEUE">Offline Queue</option></select></div>
<div class="field"><label class="field-label" for="historyResult">Result</label><select id="historyResult"><option value="">All results</option><option>ACCEPTED</option><option>REPEAT</option><option>REPEAT_ALERT</option><option>TOO_FAST</option></select></div></div>
<div class="toolbar" style="margin-top:14px"><button class="btn" type="button" onclick="loadHistory()">Search records</button><button class="btn dark" type="button" onclick="refreshHistoryNow()">Refresh now</button><button class="btn gray" type="button" onclick="resetHistoryFilters()">Clear filters</button><span id="historyCount" class="sub" role="status" aria-live="polite"></span><span id="historyAdminActions" style="display:none"><button id="deleteSelectedHistory" class="btn red" type="button" onclick="deleteSelectedHistoryRecords()">Delete selected history</button></span></div></div>
<div class="panel"><div class="tablewrap"><table><thead><tr><th><input id="historySelectAll" type="checkbox" aria-label="Select all visible scan records" style="display:none;width:auto"> Time</th><th>Session</th><th>Inspection</th><th>Schedule</th><th>Sync Source</th><th>Company</th><th>Point</th><th>Inspector</th><th>Inspector ID</th><th>Device</th><th>Result</th><th>Repeat #</th></tr></thead><tbody id="historyRows"></tbody></table></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const historyById=id=>document.getElementById(id);
let historyLoading=false;
let historyIsAdmin=false;
function historyDatalist(id,values){const node=historyById(id);node.replaceChildren(...[...new Set((values||[]).map(v=>String(v??'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b)).map(v=>{const o=document.createElement('option');o.value=v;return o}))}
async function loadHistoryAccess(){const response=await fetch('/api/me',{cache:'no-store'}),me=await response.json();historyIsAdmin=me.role==='SUPER_ADMIN';historyAdminActions.style.display=historyIsAdmin?'inline-flex':'none';historySelectAll.style.display=historyIsAdmin?'inline-block':'none'}
async function loadHistoryOptions(){const p=new URLSearchParams();if(historyCompany.value)p.set('company_id',historyCompany.value);const r=await fetch('/api/history/options?'+p.toString(),{cache:'no-store'}),x=await r.json();if(!r.ok||!x.ok)return;historyDatalist('historyPointOptions',(x.points||[]).flatMap(v=>[v.code,v.name]));historyDatalist('historyInspectorOptions',(x.inspectors||[]).flatMap(v=>[v.name,v.username]));historyDatalist('historyInspectorIdOptions',(x.inspectors||[]).map(v=>v.employee_id));historyDatalist('historyDeviceOptions',x.devices);historyDatalist('historyScheduleOptions',x.schedules);const current=historyCompany.value;if((x.companies||[]).length){historyCompany.replaceChildren(new Option('All Companies',''),...(x.companies||[]).map(v=>new Option(`${v.name} (${v.code})`,v.id)));historyCompany.value=current}else{historyCompany.closest('.field').style.display='none'}}
async function loadHistory(){if(historyLoading)return;historyLoading=true;const p=new URLSearchParams(),search=historySearch.value.trim();[['start',historyStart.value],['end',historyEnd.value],['company_id',historyCompany.value],['point',historyPoint.value.trim()],['inspector',historyInspector.value.trim()],['inspector_id',historyInspectorId.value.trim()],['device',historyDevice.value.trim()],['schedule',historySchedule.value.trim()],['inspection_type',historyMode.value],['sync_source',historySource.value],['result',historyResult.value]].forEach(([k,v])=>{if(v)p.set(k,v)});historyCount.textContent='Loading…';try{const response=await fetch('/api/history?'+p.toString(),{cache:'no-store'}),r=await response.json();if(!response.ok||!Array.isArray(r))throw new Error('Unable to load history');const q=search.toLowerCase(),filtered=r.filter(x=>!q||[x.scan_time,x.inspection_session_id,x.company_name,x.point_code,x.point_name,x.inspector_name,x.inspector_employee_id,x.inspector_id,x.device_id,x.inspection_type,x.schedule_name,x.sync_source,x.result].join(' ').toLowerCase().includes(q));historyRows.innerHTML=filtered.map(x=>`<tr><td>${esc(x.scan_time)}</td><td>${esc(x.inspection_session_id||'—')}</td><td>${esc(x.inspection_type||'MANUAL')}</td><td>${esc(x.schedule_name||'—')}</td><td>${esc(x.sync_source||'LIVE')}</td><td>${esc(x.company_name||'')}</td><td>${esc(x.point_code)} — ${esc(x.point_name||'')}</td><td>${esc(x.inspector_name)}</td><td>${esc(x.inspector_employee_id||x.inspector_id||'—')}</td><td>${esc(x.device_id)}</td><td><span class="badge ${x.result==='ACCEPTED'?'green':'yellow'}">${esc(x.result)}</span></td><td>${esc(x.repeat_count||0)}</td></tr>`).join('')||'<tr><td colspan="12" class="empty">No scan records match these filters.</td></tr>';if(historyIsAdmin&&filtered.length){historyRows.querySelectorAll('tr').forEach((row,index)=>{const cell=row.insertCell(0);cell.innerHTML='<input type="checkbox" class="historyRowSelect" value="'+Number(filtered[index].id)+'" aria-label="Select scan record '+Number(filtered[index].id)+'" style="width:auto">'})}historySelectAll.checked=false;const accepted=filtered.filter(x=>x.result==='ACCEPTED').length,repeats=filtered.filter(x=>x.result==='REPEAT'||x.result==='REPEAT_ALERT').length,offline=filtered.filter(x=>x.sync_source==='OFFLINE_QUEUE').length,scheduled=filtered.filter(x=>x.inspection_type==='SCHEDULED').length;historyStats.innerHTML=[[filtered.length,'Records'],[accepted,'Accepted'],[repeats,'Repeat scans'],[offline,'Offline synced'],[scheduled,'Scheduled']].map(([n,label])=>`<div class="card"><div class="lab">${label}</div><div class="num">${n}</div></div>`).join('');historyCount.textContent=`${filtered.length} records shown`;historyLastUpdated.textContent='Updated '+new Date().toLocaleTimeString()}catch(_){historyCount.textContent='Unable to load history';historyLastUpdated.textContent='Refresh failed · retrying'}finally{historyLoading=false}}
async function deleteSelectedHistoryRecords(){const ids=[...historyRows.querySelectorAll('.historyRowSelect:checked')].map(item=>Number(item.value)).filter(id=>Number.isSafeInteger(id)&&id>0);if(!historyIsAdmin||!ids.length)return alert('Select one or more records to delete.');if(!confirm('Permanently delete '+ids.length+' selected scan record(s)? Each deletion is added to Audit Logs.'))return;deleteSelectedHistory.disabled=true;try{const response=await fetch('/api/history/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids})}),result=await response.json();if(!response.ok||!result.ok)throw new Error(result.message||'History delete failed');historyCount.textContent=result.message;await loadHistory()}catch(error){alert(error.message||'Could not delete selected history')}finally{deleteSelectedHistory.disabled=false}}
historySelectAll.addEventListener('change',()=>historyRows.querySelectorAll('.historyRowSelect').forEach(item=>{item.checked=historySelectAll.checked}));
function refreshHistoryNow(){loadHistoryOptions().then(loadHistory)}
function resetHistoryFilters(){['historySearch','historyStart','historyEnd','historyPoint','historyInspector','historyInspectorId','historyDevice','historySchedule','historyMode','historySource','historyResult'].forEach(id=>historyById(id).value='');historyCompany.value='';loadHistoryOptions().then(loadHistory)}
historyCompany.addEventListener('change',()=>loadHistoryOptions().then(loadHistory));
['historySearch','historyStart','historyEnd','historyPoint','historyInspector','historyInspectorId','historyDevice','historySchedule','historyMode','historySource','historyResult'].forEach(id=>historyById(id).addEventListener('change',loadHistory));
historySearch.addEventListener('input',()=>{clearTimeout(window.historySearchTimer);window.historySearchTimer=setTimeout(loadHistory,250)});
async function startHistory(){await loadHistoryOptions();await loadHistoryAccess();await loadHistory()}startHistory();
setInterval(()=>{if(document.visibilityState==='visible'&&!document.activeElement?.matches('input,select,textarea'))loadHistory()},10000);
</script>
"""

REPORTS_BODY = r"""
<div class="panel"><h2>Report Filters & Export</h2><p class="muted">Pick a saved value from the suggestions, or type a name, code, or ID to search.</p><div class="formgrid">
<div class="field"><label class="field-label" for="reportType">Report category</label><select id="reportType"><option value="ALL">All Scans</option><option value="DAILY">Daily</option><option value="WEEKLY">Weekly</option><option value="MONTHLY">Monthly</option><option value="POINT">Point-wise</option><option value="INSPECTOR">Inspector-wise</option><option value="DEVICE">Device-wise</option><option value="REPEAT">Repeat Scans</option><option value="MISSED">Missed Points</option><option value="COMPANY">Company-wise</option></select></div>
<div id="reportCompanyBox" class="field" style="display:none"><label class="field-label" for="reportCompany">Company</label><select id="reportCompany"></select></div>
<div class="field"><label class="field-label" for="reportMode">Inspection category</label><select id="reportMode"><option value="">All categories</option><option value="MANUAL">Manual</option><option value="SCHEDULED">Scheduled</option></select></div>
<div class="field"><label class="field-label" for="reportSource">Sync source</label><select id="reportSource"><option value="">All sources</option><option value="LIVE">Live</option><option value="OFFLINE_QUEUE">Offline Queue</option></select></div>
<div class="field"><label class="field-label" for="reportStart">From date</label><input type="date" id="reportStart"></div><div class="field"><label class="field-label" for="reportEnd">To date</label><input type="date" id="reportEnd"></div>
<div class="field"><label class="field-label" for="reportPoint">Point code / name</label><input id="reportPoint" list="reportPointOptions" placeholder="Choose or type"><datalist id="reportPointOptions"></datalist></div>
<div class="field"><label class="field-label" for="reportInspector">Inspector name / username</label><input id="reportInspector" list="reportInspectorOptions" placeholder="Choose or type"><datalist id="reportInspectorOptions"></datalist></div>
<div class="field"><label class="field-label" for="reportInspectorId">Inspector ID</label><input id="reportInspectorId" list="reportInspectorIdOptions" placeholder="Employee or record ID"><datalist id="reportInspectorIdOptions"></datalist></div>
<div class="field"><label class="field-label" for="reportDevice">Device ID</label><input id="reportDevice" list="reportDeviceOptions" placeholder="Choose or type"><datalist id="reportDeviceOptions"></datalist></div>
<div class="field"><label class="field-label" for="reportSchedule">Schedule</label><input id="reportSchedule" list="reportScheduleOptions" placeholder="Choose or type"><datalist id="reportScheduleOptions"></datalist></div>
<div class="field"><label class="field-label" for="reportResult">Result</label><select id="reportResult"><option value="">All results</option><option>ACCEPTED</option><option>REPEAT</option><option>REPEAT_ALERT</option><option>TOO_FAST</option></select></div>
<div class="field full"><label class="field-label" for="reportSearch">Quick search</label><input id="reportSearch" placeholder="Name, ID, point, schedule, device…"></div></div><br><button class="btn" onclick="downloadCSV()">Export CSV</button> <button class="btn dark" onclick="printReport()">Print / Save PDF</button> <button class="btn gray" onclick="clearReportFilters()">Clear filters</button><span id="reportMessage" class="sub" role="status" aria-live="polite" style="margin-left:10px"></span></div>
<div class="panel"><h2>Available Report Types</h2><div class="kpis"><div class="mini report-card" onclick="pickReport('DAILY')"><b>Daily</b><div class="sub">Single-day scan activity</div></div><div class="mini report-card" onclick="pickReport('WEEKLY')"><b>Weekly</b><div class="sub">7-day operational summary</div></div><div class="mini report-card" onclick="pickReport('MONTHLY')"><b>Monthly</b><div class="sub">Monthly scan history</div></div><div class="mini report-card" onclick="pickReport('POINT')"><b>Point-wise</b><div class="sub">Filter by inspection point</div></div><div class="mini report-card" onclick="pickReport('INSPECTOR')"><b>Inspector-wise</b><div class="sub">Inspector activity</div></div><div class="mini report-card" onclick="pickReport('DEVICE')"><b>Device-wise</b><div class="sub">Mobile device activity</div></div><div class="mini report-card" onclick="pickReport('REPEAT')"><b>Repeat Scans</b><div class="sub">Repeated inspection events</div></div><div class="mini report-card" onclick="pickReport('MISSED')"><b>Missed Points</b><div class="sub">Points without accepted scan</div></div><div id="companyReportCard" class="mini report-card" onclick="pickReport('COMPANY')"><b>Company-wise</b><div class="sub">Super Admin company report</div></div></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function reportDatalist(id,values){const node=document.getElementById(id);node.replaceChildren(...[...new Set((values||[]).map(v=>String(v??'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b)).map(v=>{const o=document.createElement('option');o.value=v;return o}))}
async function setup(){let me=await(await fetch('/api/me')).json();if(me.role==='SUPER_ADMIN'){reportCompanyBox.style.display='flex';let cs=await(await fetch('/api/companies')).json();reportCompany.innerHTML='<option value="">All Companies</option>'+cs.filter(c=>c.status!=='DELETED').map(c=>`<option value="${c.id}">${esc(c.name)} (${esc(c.code)})</option>`).join('')}else{const opt=document.querySelector('#reportType option[value="COMPANY"]');if(opt)opt.remove();const card=document.getElementById('companyReportCard');if(card)card.remove()}const p=new URLSearchParams();if(reportCompany.value)p.set('company_id',reportCompany.value);const r=await fetch('/api/history/options?'+p.toString(),{cache:'no-store'}),x=await r.json();if(!r.ok||!x.ok)return;reportDatalist('reportPointOptions',(x.points||[]).flatMap(v=>[v.code,v.name]));reportDatalist('reportInspectorOptions',(x.inspectors||[]).flatMap(v=>[v.name,v.username]));reportDatalist('reportInspectorIdOptions',(x.inspectors||[]).map(v=>v.employee_id));reportDatalist('reportDeviceOptions',x.devices);reportDatalist('reportScheduleOptions',x.schedules)}
function localDate(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function pickReport(type){reportType.value=type;if(type==='REPEAT')reportResult.value='REPEAT';else if(reportResult.value==='REPEAT')reportResult.value='';if(type==='DAILY'){let d=localDate(new Date());reportStart.value=d;reportEnd.value=d}else if(type==='WEEKLY'){let e=new Date(),s=new Date();s.setDate(e.getDate()-6);reportStart.value=localDate(s);reportEnd.value=localDate(e)}else if(type==='MONTHLY'){let e=new Date(),s=new Date(e.getFullYear(),e.getMonth(),1);reportStart.value=localDate(s);reportEnd.value=localDate(e)}window.scrollTo({top:0,behavior:'smooth'});}
function qs(){let p=new URLSearchParams(),type=reportType.value;if(type==='REPEAT')reportResult.value='REPEAT';if(type==='POINT'&&!reportPoint.value.trim()){alert('Choose or enter a point code/name');return null}if(type==='INSPECTOR'&&!reportInspector.value.trim()&&!reportInspectorId.value.trim()){alert('Choose or enter an inspector name or ID');return null}if(type==='DEVICE'&&!reportDevice.value.trim()){alert('Choose or enter a device ID');return null}if(reportStart.value&&reportEnd.value&&reportStart.value>reportEnd.value){alert('From date must be on or before To date');return null}p.set('type',type);[['start',reportStart.value],['end',reportEnd.value],['point',reportPoint.value.trim()],['inspector',reportInspector.value.trim()],['inspector_id',reportInspectorId.value.trim()],['device',reportDevice.value.trim()],['schedule',reportSchedule.value.trim()],['q',reportSearch.value.trim()],['result',reportResult.value],['inspection_type',reportMode.value],['sync_source',reportSource.value],['company_id',reportCompany?.value||'']].forEach(([k,v])=>{if(v)p.set(k,v)});return p}
function downloadCSV(){let p=qs();if(p)location.href='/api/report.csv?'+p.toString()}
async function printReport(){let p=qs();if(!p)return;let r=await(await fetch('/api/history?'+p.toString())).json();let w=window.open('','print');if(!w)return alert('Allow popups to print the report.');w.document.write('<html><head><meta charset="utf-8"><title>AB SECURITAS Report</title></head><body><h1>AB SECURITAS — Real Time Inspector</h1><table border="1" cellspacing="0" cellpadding="7"><tr><th>Time</th><th>Company</th><th>Mode</th><th>Schedule</th><th>Sync Source</th><th>Point</th><th>Inspector</th><th>Inspector ID</th><th>Device</th><th>Result</th></tr>'+r.map(x=>`<tr><td>${esc(x.scan_time)}</td><td>${esc(x.company_name||'')}</td><td>${esc(x.inspection_type||'MANUAL')}</td><td>${esc(x.schedule_name||'')}</td><td>${esc(x.sync_source||'LIVE')}</td><td>${esc(x.point_code)} ${esc(x.point_name||'')}</td><td>${esc(x.inspector_name)}</td><td>${esc(x.inspector_employee_id||x.inspector_id||'')}</td><td>${esc(x.device_id)}</td><td>${esc(x.result)}</td></tr>`).join('')+'</table></body></html>');w.document.close();w.print()}
async function clearReportFilters(){['reportStart','reportEnd','reportPoint','reportInspector','reportInspectorId','reportDevice','reportSchedule','reportSearch','reportMode','reportSource','reportResult'].forEach(id=>document.getElementById(id).value='');reportType.value='ALL';if(reportCompany)reportCompany.value='';reportMessage.textContent='Filters cleared';setup()}
reportCompany?.addEventListener('change',setup);
setup();
</script>
"""

USERS_BODY = r"""
<div class="panel"><h2>Create User</h2><div class="formgrid"><div><label class="muted">Username</label><input id="username" style="width:100%" placeholder="Username"></div><div><label class="muted">Full Name</label><input id="full_name" style="width:100%" placeholder="Full Name"></div><div><label class="muted">Password</label><input id="password" type="password" style="width:100%" placeholder="Password"></div><div><label class="muted">Role</label><select id="role" style="width:100%" onchange="roleChanged()"><option value="COMPANY_ADMIN">COMPANY_ADMIN</option><option value="SUPER_ADMIN">SUPER_ADMIN</option></select></div><div><label class="muted">Company</label><select id="company_id" style="width:100%"><option value="">Select Company</option></select></div><div class="full"><label class="muted">User Details</label><textarea id="details" placeholder="User details / designation / notes"></textarea></div></div><br><button class="btn" onclick="addUser()">Create User</button></div>
<div class="panel"><h2>User Directory</h2><div class="tablewrap"><table><thead><tr><th>Username</th><th>Name</th><th>Details</th><th>Role</th><th>Company</th><th>Status</th><th>Actions</th></tr></thead><tbody id="userRows"></tbody></table></div></div>
<div id="userEditModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:center;justify-content:center"><div class="panel" style="width:min(760px,92vw)"><h2>Edit User</h2><div class="formgrid"><div><label class="field-label">Username</label><input id="edit_user_username"></div><div><label class="field-label">Full Name</label><input id="edit_user_name"></div><div><label class="field-label">Role</label><select id="edit_user_role" onchange="editRoleChanged()"><option value="COMPANY_ADMIN">COMPANY_ADMIN</option><option value="SUPER_ADMIN">SUPER_ADMIN</option></select></div><div><label class="field-label">Company</label><select id="edit_user_company"></select></div><div><label class="field-label">New Password (optional)</label><input id="edit_user_password" type="password" placeholder="Leave blank to keep current"></div><div class="full"><label class="field-label">User Details</label><textarea id="edit_user_details"></textarea></div></div><br><button class="btn" onclick="saveUserEdit()">Save Changes</button> <button class="btn gray" onclick="closeUserEdit()">Cancel</button><span id="userEditMsg" class="sub" style="margin-left:10px"></span></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); const userRows=document.getElementById('userRows'); let editingUserId=null;
async function setup(){let cs=await(await fetch('/api/companies')).json();company_id.innerHTML='<option value="">Select Company</option>'+cs.filter(c=>c.status==='ACTIVE').map(c=>`<option value="${c.id}">${esc(c.name)} (${esc(c.code)})</option>`).join('');load()}
function roleChanged(){company_id.disabled=role.value==='SUPER_ADMIN';if(company_id.disabled)company_id.value=''}
async function load(){let r=await(await fetch('/api/users')).json();if(!Array.isArray(r)){return alert(r.message||'Unable to load users')}userRows.innerHTML=r.map(x=>`<tr><td>${esc(x.username)}</td><td>${esc(x.full_name)}</td><td>${esc(x.details||'—')}</td><td><span class="badge blue">${esc(x.role)}</span></td><td>${esc(x.company_name||'ALL')}</td><td><span class="badge ${x.status==='ACTIVE'?'green':x.status==='DELETED'?'red':'gray'}">${esc(x.status)}</span></td><td>${x.status!=='DELETED'?`<button class="btn gray" onclick='openUserEdit(${rtiJsArg(x)})'>Edit</button> <button class="btn gray" onclick="viewUserPassword(${x.id})">View Password</button> <button class="btn gray" onclick="resetPassword(${x.id},${rtiJsArg(x.username)})">Reset Password</button> ${x.status==='ACTIVE'?`<button class="btn red" onclick="deleteUser(${x.id})">Delete</button>`:`<button class="btn gray" onclick="setStatus(${x.id},'ACTIVE')">Enable</button>`}`:'Deleted'}</td></tr>`).join('')}
async function addUser(){let d={username:username.value,full_name:full_name.value,password:password.value,role:role.value,company_id:company_id.value,details:details.value};let r=await fetch('/api/users',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});let x=await r.json();if(!r.ok||!x.ok)return alert(x.message);['username','full_name','password','details'].forEach(id=>document.getElementById(id).value='');await load()}
function openUserEdit(x){editingUserId=x.id;edit_user_username.value=x.username||'';edit_user_name.value=x.full_name||'';edit_user_role.value=x.role||'COMPANY_ADMIN';edit_user_details.value=x.details||'';edit_user_password.value='';edit_user_company.innerHTML=company_id.innerHTML;edit_user_company.value=x.company_id||'';editRoleChanged();userEditMsg.textContent='';userEditModal.style.display='flex'}
function editRoleChanged(){edit_user_company.disabled=edit_user_role.value==='SUPER_ADMIN';if(edit_user_company.disabled)edit_user_company.value=''}
function closeUserEdit(){userEditModal.style.display='none';editingUserId=null}
async function saveUserEdit(){if(!editingUserId)return;let d={username:edit_user_username.value.trim(),full_name:edit_user_name.value.trim(),role:edit_user_role.value,company_id:edit_user_company.value,details:edit_user_details.value.trim()};if(edit_user_password.value)d.password=edit_user_password.value;let r=await fetch('/api/users/'+editingUserId,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});let x=await r.json();if(!r.ok||!x.ok)return userEditMsg.textContent=x.message||'Update failed';closeUserEdit();await load();alert('User updated successfully')}
async function resetPassword(id,u){let p=prompt('New password for '+u+' (minimum 6 characters)');if(p===null)return;let r=await fetch('/api/users/'+id+'/reset-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:p})});let x=await r.json();if(!r.ok||!x.ok)return alert(x.message);alert('Password reset successfully')}
async function deleteUser(id){if(!confirm('Delete this user? The account will be marked DELETED and audit history will remain.'))return;let r=await fetch('/api/users/'+id,{method:'DELETE'});let x=await r.json();if(!r.ok||!x.ok)return alert(x.message);await load();alert('User deleted successfully')}
async function setStatus(id,status){let r=await fetch('/api/users/'+id+'/status',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});let x=await r.json();if(!r.ok||!x.ok)return alert(x.message);load()}
async function viewUserPassword(id){const pw=prompt('Enter Super Admin password to view this password:');if(pw===null)return;const rr=await fetch('/api/admin/reveal-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({admin_password:pw,target_type:'USER',target_id:id})});const x=await rr.json();if(!rr.ok||!x.ok)return alert(x.message||'Unable to reveal password');alert('Password: '+x.password)}
setup();
</script>
"""

AUDIT_BODY = r"""
<div class="panel"><h2>Audit record filters</h2><p class="muted">Choose existing values from suggestions or type a name, category, action, or ID.</p><div class="formgrid">
<div class="field"><label class="field-label" for="auditSearch">Quick search</label><input id="auditSearch" placeholder="User, company, action, details…"></div>
<div class="field"><label class="field-label" for="auditCompany">Company</label><select id="auditCompany"><option value="">All Companies</option></select></div>
<div class="field"><label class="field-label" for="auditStart">From date</label><input id="auditStart" type="date"></div><div class="field"><label class="field-label" for="auditEnd">To date</label><input id="auditEnd" type="date"></div>
<div class="field"><label class="field-label" for="auditUser">User</label><input id="auditUser" list="auditUserOptions" placeholder="Choose or type"><datalist id="auditUserOptions"></datalist></div>
<div class="field"><label class="field-label" for="auditAction">Action category</label><input id="auditAction" list="auditActionOptions" placeholder="Choose or type"><datalist id="auditActionOptions"></datalist></div>
<div class="field"><label class="field-label" for="auditEntityType">Record category</label><input id="auditEntityType" list="auditEntityTypeOptions" placeholder="Choose or type"><datalist id="auditEntityTypeOptions"></datalist></div>
<div class="field"><label class="field-label" for="auditEntityId">Entity ID</label><input id="auditEntityId" list="auditEntityIdOptions" placeholder="Choose or type"><datalist id="auditEntityIdOptions"></datalist></div>
<div class="field"><label class="field-label" for="auditRecordId">Audit record ID</label><input id="auditRecordId" type="number" min="1" placeholder="Optional log ID"></div></div>
<div class="toolbar" style="margin-top:14px"><button class="btn" onclick="loadAudit()">Search audit logs</button><button class="btn gray" onclick="resetAuditFilters()">Clear filters</button><span id="auditCount" class="sub" role="status" aria-live="polite"></span></div></div>
<div class="panel"><div class="tablewrap"><table><thead><tr><th>Log ID</th><th>Time</th><th>User</th><th>Company</th><th>Action</th><th>Category</th><th>Entity ID</th><th>Details</th></tr></thead><tbody id="auditRows"></tbody></table></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function auditDatalist(id,values){const node=document.getElementById(id);node.replaceChildren(...[...new Set((values||[]).map(v=>String(v??'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b)).map(v=>{const o=document.createElement('option');o.value=v;return o}))}
async function loadAuditOptions(){const r=await fetch('/api/audit/options',{cache:'no-store'}),x=await r.json();if(!r.ok||!x.users)return;auditDatalist('auditUserOptions',x.users);auditDatalist('auditActionOptions',x.actions);auditDatalist('auditEntityTypeOptions',x.entity_types);auditDatalist('auditEntityIdOptions',x.entity_ids);const current=auditCompany.value;auditCompany.replaceChildren(new Option('All Companies',''),...(x.companies||[]).map(c=>new Option(`${c.name} (${c.code})`,c.id)));auditCompany.value=current}
async function loadAudit(){const p=new URLSearchParams();[['start',auditStart.value],['end',auditEnd.value],['username',auditUser.value.trim()],['company_id',auditCompany.value],['action',auditAction.value.trim()],['entity_type',auditEntityType.value.trim()],['entity_id',auditEntityId.value.trim()],['record_id',auditRecordId.value.trim()],['q',auditSearch.value.trim()]].forEach(([k,v])=>{if(v)p.set(k,v)});auditCount.textContent='Loading…';const response=await fetch('/api/audit?'+p.toString(),{cache:'no-store'}),r=await response.json();if(!response.ok||!Array.isArray(r)){auditCount.textContent='Unable to load audit logs';return}auditRows.innerHTML=r.map(x=>`<tr><td>${esc(x.id)}</td><td>${esc(x.created_at)}</td><td>${esc(x.username)}</td><td>${esc(x.company_name||'ALL')}</td><td>${esc(x.action)}</td><td>${esc(x.entity_type)}</td><td>${esc(x.entity_id||'—')}</td><td>${esc(x.details)}</td></tr>`).join('')||'<tr><td colspan="8" class="empty">No audit records match these filters.</td></tr>';auditCount.textContent=`${r.length} records shown`}
function resetAuditFilters(){['auditSearch','auditStart','auditEnd','auditUser','auditAction','auditEntityType','auditEntityId','auditRecordId'].forEach(id=>document.getElementById(id).value='');auditCompany.value='';loadAudit()}
['auditStart','auditEnd','auditCompany','auditUser','auditAction','auditEntityType','auditEntityId','auditRecordId'].forEach(id=>document.getElementById(id).addEventListener('change',loadAudit));
auditSearch.addEventListener('input',()=>{clearTimeout(window.auditSearchTimer);window.auditSearchTimer=setTimeout(loadAudit,250)});
loadAuditOptions().then(loadAudit);
</script>
"""

DELETED_BODY = r"""
<div class="panel"><div class="toolbar"><div class="field"><label class="field-label" for="deletedSearch">Search Deleted Records</label><input id="deletedSearch" placeholder="Company / user / inspector / point"></div></div></div>
<div class="panel"><h2>Deleted Companies</h2><div class="tablewrap"><table><thead><tr><th>Deleted At</th><th>Company</th><th>Code</th></tr></thead><tbody id="deletedCompanies"></tbody></table></div></div>
<div class="panel"><h2>Deleted Users</h2><div class="tablewrap"><table><thead><tr><th>Deleted At</th><th>Username</th><th>Name</th><th>Company</th></tr></thead><tbody id="deletedUsers"></tbody></table></div></div>
<div class="panel"><h2>Deleted Inspectors</h2><p class="muted">Permanent deletion erases the inspector profile and credentials while preserving scan history and audit rows.</p><div class="tablewrap"><table><thead><tr><th>Deleted At</th><th>Employee ID</th><th>Name</th><th>Company</th><th>Action</th></tr></thead><tbody id="deletedInspectors"></tbody></table></div></div>
<div class="panel"><h2>Deleted Devices</h2><p class="muted">Permanent removal revokes access and keeps the Device ID blocked to prevent automatic re-registration.</p><div class="tablewrap"><table><thead><tr><th>Removed At</th><th>Device ID</th><th>Company</th><th>Action</th></tr></thead><tbody id="deletedDevices"></tbody></table></div></div>
<div class="panel"><h2>Deleted Check Points</h2><div class="tablewrap"><table><thead><tr><th>Deleted At</th><th>Code</th><th>Name</th><th>Company</th></tr></thead><tbody id="deletedPoints"></tbody></table></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
async function loadDeleted(){let r=await(await fetch('/api/deleted')).json(),q=deletedSearch.value.toLowerCase();let f=a=>a.filter(x=>JSON.stringify(x).toLowerCase().includes(q));
deletedCompanies.innerHTML=f(r.companies).map(x=>`<tr><td>${esc(x.deleted_at)}</td><td>${esc(x.name)}</td><td>${esc(x.code)}</td></tr>`).join('')||'<tr><td colspan="3" class="empty">No deleted companies.</td></tr>';
deletedUsers.innerHTML=f(r.users).map(x=>`<tr><td>${esc(x.deleted_at)}</td><td>${esc(x.username)}</td><td>${esc(x.full_name)}</td><td>${esc(x.company_name||'ALL')}</td></tr>`).join('')||'<tr><td colspan="4" class="empty">No deleted users.</td></tr>';
deletedInspectors.innerHTML=f(r.inspectors).map(x=>`<tr><td>${esc(x.deleted_at)}</td><td>${esc(x.employee_id)}</td><td>${esc(x.name)}</td><td>${esc(x.company_name||'')}</td><td>${x.permanently_deleted?'<span class="badge red">PROFILE ERASED</span>':'<button class="btn red" onclick="permanentlyRemoveInspector('+Number(x.id)+')">Permanently delete</button>'}</td></tr>`).join('')||'<tr><td colspan="5" class="empty">No deleted inspectors.</td></tr>';
deletedDevices.innerHTML=f(r.devices||[]).map(x=>`<tr><td>${esc(x.deleted_at)}</td><td>${esc(x.device_id)}</td><td>${esc(x.company_name||'')}</td><td>${x.permanently_deleted?'<span class="badge red">ID BLOCKED</span>':'<button class="btn red" onclick="permanentlyRemoveDeletedDevice('+Number(x.id)+')">Permanently delete</button>'}</td></tr>`).join('')||'<tr><td colspan="4" class="empty">No deleted devices.</td></tr>';
deletedPoints.innerHTML=f(r.points).map(x=>`<tr><td>${esc(x.deleted_at)}</td><td>${esc(x.point_code)}</td><td>${esc(x.name)}</td><td>${esc(x.company_name||'')}</td></tr>`).join('')||'<tr><td colspan="4" class="empty">No deleted check points.</td></tr>';}
deletedSearch.addEventListener('input',loadDeleted);loadDeleted();
async function permanentlyRemoveInspector(id){if(!confirm('Permanently erase this deleted inspector profile and login credentials? Scan history and audit records will remain.'))return;const response=await fetch('/api/inspectors/'+id+'/permanent',{method:'DELETE'}),result=await response.json();if(!response.ok||!result.ok)return alert(result.message||'Inspector could not be permanently removed');await loadDeleted();alert(result.message)}
async function permanentlyRemoveDeletedDevice(id){if(!confirm('Permanently block this removed device? Its ID remains reserved and scan history/audit are retained.'))return;const response=await fetch('/api/devices/'+id+'/permanent',{method:'DELETE'}),result=await response.json();if(!response.ok||!result.ok)return alert(result.message||'Device could not be permanently removed');await loadDeleted();alert(result.message)}
</script>
"""

LICENSE_BODY = r"""
<div id="clientActivate" class="panel" style="display:none"><h2>🔑 New License Key</h2><div class="notice">Enter the license key supplied by <b>AB SECURITAS · Electronic Security Division</b>. Your other application modules will unlock after successful activation.</div><div class="field"><label class="field-label" for="license_key">License Key</label><input id="license_key" placeholder="Enter new license key supplied by AB SECURITAS"></div><br><br><button class="btn" onclick="activateLicense()">Activate License</button><div id="activateMsg" class="sub" style="margin-top:10px"></div></div>
<div id="clientStatus" class="panel" style="display:none"></div>
<div id="adminGenerate" style="display:none"><div class="panel"><h2>Generate Client License</h2><div class="formgrid"><div class="field"><label class="field-label" for="lic_company">Company</label><select id="lic_company"></select></div><div class="field"><label class="field-label" for="lic_type">License Type</label><select id="lic_type"><option value="1_DAY_TRIAL">1 Day Trial</option><option value="3_MONTHS">3 Months</option><option value="6_MONTHS">6 Months</option><option value="1_YEAR">1 Year</option></select></div><div class="field full"><label class="field-label" for="lic_notes">Notes / Payment Reference</label><input id="lic_notes" placeholder="Optional"></div></div><br><button class="btn" onclick="generateLicense()">Generate License</button><div id="generated" class="notice" style="display:none;margin-top:14px"></div></div>
<div class="panel"><h2>License Directory</h2><div class="tablewrap"><table><thead><tr><th>Company</th><th>License</th><th>Type</th><th>Status</th><th>Start</th><th>Expiry</th><th>Action</th></tr></thead><tbody id="licRows"></tbody></table></div></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
async function setupLicense(){let me=await(await fetch('/api/me')).json();if(me.role==='SUPER_ADMIN'){adminGenerate.style.display='block';let cs=await(await fetch('/api/companies')).json();lic_company.innerHTML=cs.filter(c=>c.status==='ACTIVE').map(c=>`<option value="${c.id}">${esc(c.name)} (${esc(c.code)})</option>`).join('');loadLicenses()}else{clientActivate.style.display='block';loadClientLicense()}}
async function loadClientLicense(){let r=await(await fetch('/api/license')).json();let l=r[0];clientActivate.style.display='block';if(!l){clientStatus.innerHTML='<h2>🔒 License Required</h2><p>No active license is assigned to this company yet.</p>';clientStatus.style.display='block';return}if(l.status==='ACTIVE'){let exp=new Date(l.expiry_date.replace(' ','T')),days=Math.max(0,Math.ceil((exp-new Date())/86400000));clientStatus.innerHTML=`<h2>✓ Current License Active</h2><div class="kpis"><div class="mini"><b>${esc(l.license_type)}</b><div class="sub">Plan</div></div><div class="mini"><b>${esc(l.expiry_date)}</b><div class="sub">Expiry</div></div><div class="mini"><b>${days}</b><div class="sub">Days remaining</div></div></div><p class="muted">You can enter a new license key below to replace the current license after activation.</p>`}else{clientStatus.innerHTML=`<h2>🔒 License Not Active</h2><p>Status: <b>${esc(l.status)}</b></p><p>Enter a new license key above.</p>`}clientStatus.style.display='block'}
async function activateLicense(){let r=await fetch('/api/license/activate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({license_key:license_key.value})});let x=await r.json();if(!x.ok){activateMsg.textContent=x.message;activateMsg.className='danger-text';return}alert('License activated successfully.');location.href='/'}
async function copyLicenseKey(key,button){try{if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText(key);else{const input=document.createElement('textarea');input.value=key;input.setAttribute('readonly','');input.style.position='fixed';input.style.opacity='0';document.body.appendChild(input);try{input.select();if(!document.execCommand('copy'))throw new Error('Clipboard unavailable')}finally{input.remove()}}const old=button?.textContent;if(button){button.textContent='Copied';button.disabled=true;setTimeout(()=>{button.textContent=old||'Copy key';button.disabled=false},1200)}else alert('Activation key copied.')}catch(_){alert('Could not copy automatically. Select and copy the activation key manually.')}}
async function loadLicenses(){let r=await(await fetch('/api/license')).json();licRows.innerHTML=r.map(l=>`<tr><td>${esc(l.company_name)}</td><td><b>${esc(l.license_key)}</b> <button class="btn gray" type="button" onclick="copyLicenseKey('${esc(l.license_key)}',this)">Copy key</button></td><td>${esc(l.license_type)}</td><td><span class="badge ${l.status==='ACTIVE'?'green':l.status==='GENERATED'?'blue':l.status==='EXPIRED'?'yellow':'gray'}">${esc(l.status)}</span></td><td>${esc(l.start_date||'—')}</td><td>${esc(l.expiry_date||'Starts on activation')}</td><td>${l.status==='GENERATED'?`<button class="btn red" onclick="disableLicense(${l.id})">Disable</button>`:''}</td></tr>`).join('')||'<tr><td colspan="7" class="empty">No licenses yet.</td></tr>'}
async function generateLicense(){let d={company_id:lic_company.value,license_type:lic_type.value,notes:lic_notes.value};let r=await fetch('/api/license/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});let x=await r.json();if(!x.ok)return alert(x.message);generated.style.display='block';generated.innerHTML=`<b>License generated successfully</b><br><span style="font-size:20px;letter-spacing:1px">${esc(x.license_key)}</span> <button class="btn dark" type="button" onclick="copyLicenseKey('${esc(x.license_key)}',this)">Copy activation key</button><br><small>Give this key to the client. The validity period starts when the client activates it.</small>`;lic_notes.value='';loadLicenses()}
async function disableLicense(id){if(!confirm('Disable this license?'))return;let r=await fetch('/api/license/'+id+'/disable',{method:'POST'});let x=await r.json();if(!x.ok)return alert(x.message);loadLicenses()}
setupLicense();
</script>
"""
BACKUPS_BODY = r"""
<div class="notice">The live database is stored outside the replaceable application folder. Backups go to a separate folder, run automatically once a day, and are kept until you remove them yourself.</div>
<div class="panel"><h2>Backup destination</h2><p class="muted">Use a folder on a separate drive or a dedicated backup folder. Enter a full path on the Central Server PC.</p><div class="field"><label class="field-label" for="backupDirectory">Backup folder</label><input id="backupDirectory" placeholder="C:\\RTI-Backups"></div><br><div class="toolbar"><button class="btn" onclick="saveBackupDirectory()">Save Folder</button><button class="btn dark" onclick="createBackup()">Back Up Now</button></div><div id="backupMessage" class="sub" role="status" aria-live="polite"></div></div>
<div class="panel"><h2>Current data and backup status</h2><div id="databaseLocation" class="notice">Loading…</div><div class="tablewrap"><table><thead><tr><th>Backup file</th><th>Created</th><th>Size</th><th>Action</th></tr></thead><tbody id="backupRows"><tr><td colspan="4" class="empty">Loading backups…</td></tr></tbody></table></div></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const sizeText=n=>n<1024?n+' B':n<1048576?(n/1024).toFixed(1)+' KB':(n/1048576).toFixed(1)+' MB';
async function restoreBackup(name){if(!confirm('Restore '+name+'? This replaces the current company, users and inspection records. A separate safety copy is created first.'))return;backupMessage.textContent='Validating backup and saving a safety copy…';try{const r=await fetch('/api/admin/backups',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'restore',name})}),x=await r.json();backupMessage.textContent=x.message||'Restore failed';if(x.ok)await loadBackups()}catch(_){backupMessage.textContent='Restore result could not be confirmed. Check the database backup folder before retrying.'}}
async function loadBackups(){let r=await fetch('/api/admin/backups',{cache:'no-store'}),x=await r.json();if(!r.ok||!x.ok){backupMessage.textContent=x.message||'Unable to load backup status';return}backupDirectory.value=x.directory;databaseLocation.innerHTML='<b>Live database:</b> '+esc(x.database)+'<br><b>Backup policy:</b> '+esc(x.automatic_backup);backupRows.replaceChildren();for(const b of (x.backups||[])){const tr=document.createElement('tr');for(const value of [b.name,b.created_at,sizeText(b.size_bytes)]){const td=document.createElement('td');td.textContent=value;tr.appendChild(td)}const td=document.createElement('td'),button=document.createElement('button');button.className='btn dark';button.textContent='Restore';button.addEventListener('click',()=>restoreBackup(b.name));td.appendChild(button);tr.appendChild(td);backupRows.appendChild(tr)}if(!(x.backups||[]).length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=4;td.className='empty';td.textContent='No backup files found yet.';tr.appendChild(td);backupRows.appendChild(tr)}}
async function saveBackupDirectory(){backupMessage.textContent='Saving folder…';let r=await fetch('/api/admin/backups',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'save_directory',directory:backupDirectory.value})}),x=await r.json();backupMessage.textContent=x.message||'Folder could not be saved';if(x.ok){backupMessage.textContent='Backup folder saved: '+x.directory;loadBackups()}}
async function createBackup(){backupMessage.textContent='Creating a consistent database backup…';let r=await fetch('/api/admin/backups',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'backup_now'})}),x=await r.json();backupMessage.textContent=x.ok?'Backup complete: '+x.name+' ('+sizeText(x.size_bytes)+')':(x.message||'Backup failed');if(x.ok)loadBackups()}
loadBackups();
</script>
"""

SETTINGS_BODY = r"""
<div class="panel"><div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap"><h2 style="margin:0">Inspection Settings</h2><a class="btn gray" href="/" aria-label="Close settings and return to dashboard">Close</a></div><div class="formgrid" style="margin-top:18px"><div class="field"><label class="field-label" for="daily_target">Daily Target Points</label><input id="daily_target" placeholder="Daily target points" value="10"></div><div class="field"><label class="field-label" for="repeat_policy">Repeat Policy</label><input id="repeat_policy" placeholder="Repeat policy" value="Mark repeat"></div><div class="field"><label class="field-label" for="company_label">Company Dashboard Label</label><input id="company_label" placeholder="Company dashboard label" value=""></div><div class="field full"><label class="field-label" for="notes">Internal Notes</label><textarea id="notes" placeholder="Internal notes"></textarea></div><div id="scanGapPanel" class="field full" style="display:none"><label class="field-label" for="min_point_gap_seconds">QR scan grace time between new points (seconds)</label><input id="min_point_gap_seconds" type="number" min="0" max="300" value="8"><small class="muted">Super Admin only · applies to all inspectors · 0 disables the delay. Scheduled start grace is edited in Schedules &amp; Client Access.</small></div></div><br><button class="btn" onclick="save()">Save Settings</button><span id="msg" class="sub" role="status" aria-live="polite" style="margin-left:10px"></span></div>
<div class="panel"><h2>Security Notes</h2><div class="notice">Company isolation is enforced server-side using the authenticated user's company_id. Super Admin can view all companies. Passwords are stored as PBKDF2 hashes for login. A separately encrypted password copy is kept only for the Super Admin password-reveal function, which requires Super Admin re-authentication every time. Point deletion is soft deletion so historical scans remain available.</div></div>
<script>
async function load(){let [r,me]=await Promise.all([fetch('/api/settings'),fetch('/api/me')]);let d=await r.json(),u=await me.json();if(d.daily_target)daily_target.value=d.daily_target;if(d.repeat_policy)repeat_policy.value=d.repeat_policy;if(d.company_label)company_label.value=d.company_label;if(d.notes)notes.value=d.notes;if(u.role==='SUPER_ADMIN'){scanGapPanel.style.display='flex';min_point_gap_seconds.value=d.min_point_gap_seconds??8}}
async function save(){let d={daily_target:daily_target.value,repeat_policy:repeat_policy.value,company_label:company_label.value,notes:notes.value};if(scanGapPanel.style.display!=='none')d.min_point_gap_seconds=min_point_gap_seconds.value;let r=await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});let x=await r.json();msg.textContent=x.ok?'Settings saved':'Error: '+x.message}load();
</script>
"""

PASSWORD_BODY = r"""
<div class="panel"><h2>Secure your account</h2><p class="muted">Choose a unique password with at least 10 characters. You will need your current password to confirm the change.</p>
<form id="passwordForm" onsubmit="changePassword(event)"><div class="formgrid"><div class="field full"><label class="field-label" for="current_password">Current Password</label><input id="current_password" type="password" autocomplete="current-password" required></div><div class="field"><label class="field-label" for="new_password">New Password</label><input id="new_password" type="password" autocomplete="new-password" minlength="10" required></div><div class="field"><label class="field-label" for="confirm_password">Confirm New Password</label><input id="confirm_password" type="password" autocomplete="new-password" minlength="10" required></div></div><br><button class="btn" id="changePasswordButton" type="submit">Update Password</button><span id="passwordMessage" class="sub" role="status" aria-live="polite" style="margin-left:12px"></span></form></div>
<script>
async function changePassword(event){event.preventDefault();const button=document.getElementById('changePasswordButton'),message=document.getElementById('passwordMessage');button.disabled=true;message.textContent='Updating…';message.className='sub';try{const response=await fetch('/api/me/password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({current_password:current_password.value,new_password:new_password.value,confirm_password:confirm_password.value})});const result=await response.json();if(!response.ok||!result.ok){message.textContent=result.message||'Password could not be changed';message.className='danger-text';button.disabled=false;return}message.textContent='Password updated. Redirecting…';location.assign('/')}catch(_){message.textContent='Unable to reach the server. Try again.';message.className='danger-text';button.disabled=false}}
</script>
"""

migrate_legacy_database()
init_db()
from rti_v15 import register_v15
register_v15(app, {
    "conn": conn, "now_str": now_str, "get_user": get_user, "license_is_active": license_is_active,
    "shell": shell, "mobile_auth": mobile_auth, "audit": audit, "max_repeats": MAX_REPEATS,
    "minimum_point_gap": minimum_point_gap,
})
start_automatic_backup_worker()

if __name__ == "__main__":
    app.run(host=os.environ.get("RTI_WEB_HOST", "127.0.0.1"), port=int(os.environ.get("RTI_WEB_PORT", "5000")), debug=False)
