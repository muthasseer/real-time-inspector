@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
echo ==========================================
echo AB SECURITAS RTI - CLIENT PC SETUP
echo ==========================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python 3.11+ is required. Install Python and enable Add Python to PATH.
  pause
  exit /b 1
)
if not exist ClientPC\.env copy ClientPC\.env.example ClientPC\.env >nul
if not exist ClientPC\.venv\Scripts\python.exe py -3 -m venv ClientPC\.venv
if errorlevel 1 goto :failed
ClientPC\.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :failed
ClientPC\.venv\Scripts\python.exe -m pip install -r ClientPC\requirements.txt
if errorlevel 1 goto :failed
findstr /c:"RTI_LAN_API_TOKEN=CHANGE-TO-A-LONG-RANDOM-LAN-TOKEN" ClientPC\.env >nul
if not errorlevel 1 (
  for /f "delims=" %%G in ('py -3 -c "import secrets; print(secrets.token_urlsafe(32))"') do set "RTI_NEW_LAN_TOKEN=%%G"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='ClientPC\.env'; $s=Get-Content -Raw $p; $s=$s.Replace('RTI_LAN_API_TOKEN=CHANGE-TO-A-LONG-RANDOM-LAN-TOKEN', 'RTI_LAN_API_TOKEN=!RTI_NEW_LAN_TOKEN!'); Set-Content -Path $p -Value $s -NoNewline -Encoding ascii"
  if errorlevel 1 goto :failed
)
echo.
echo Setup is ready. Edit ClientPC\.env and set the Central Funnel URL,
company ID, client ID, company sync token, and this Client PC's node token.
echo Keep RTI_LAN_API_TOKEN private. Enter it in the Android LAN fallback settings.
echo Run START_CLIENT_PC.bat, then open http://127.0.0.1:5100/setup for the
echo guided Central connection, IP Check, LAN passkey, and separate backup folder setup.
pause
exit /b 0

:failed
echo Setup did not finish. Read the error above and run CLIENT_PC_SETUP.bat again.
pause
exit /b 1
