AB SECURITAS REAL TIME INSPECTOR — MASTER V23.0.0

V23: Offline Android scans show local Repeat on scan two and Repeat Alert on later repeats, while every event stays queued. Central domain reachability is shown separately from Client PC node/company token authentication. Super Admin can delete selected history with per-record audit, erase deleted inspector profiles, and permanently block deleted device IDs. Activation keys have Copy controls; Company IDs remain visible without Copy. UNINSTALL_OLD_RTI_FILES.bat preserves configuration/data before removing the confirmed app folder. Android versionCode 27. QR scanner implementation is unchanged.

V22: CameraX now crops the exact scanner viewport square before passing the image to ML Kit. QR bounds are checked directly in that cropped square, and the complete QR must fit inside it. Android and Central version 22.0.0; GitHub APK workflow prioritizes the V22 source ZIP.

V20: Camera preview and QR analysis share one viewport; a whole QR must be inside the scan square. Central Company Directory shows copyable numeric IDs. First-time installation creates a stable Client PC ID. Super Admin can rename, block/enable, and manage schedule access for registered Client PCs. Android and Client PC show company ID mismatches clearly.

ARCHITECTURE
Android -> Central HTTPS Tailscale Funnel -> mobile-only proxy -> Cloud VM API + persistent SQLite.
Android -> configured Client PC LAN API when Central Internet is unreachable.
Android and Client PC keep local SQLite records and retry synchronization when connectivity returns.
The admin dashboard is available privately over the Tailscale tailnet on port 5000.
Central and Client PC databases are outside replaceable app folders. Timestamped daily backups use a separate selected folder and are never auto-deleted.
Manual, scheduled and offline scan metadata remains visible in history and reports. Android schedule reminders and offline queue continue without the Client PC being online.

QUICK START — CLOUD VM
1. Install/sign in to Tailscale on a Debian/Ubuntu VM.
2. From the project root run: sudo bash deploy/linux/install.sh
3. Run sudo tailscale up, approve Funnel, then enable: sudo systemctl enable --now rti-funnel
4. Read the URL with sudo tailscale funnel status.
5. Open the dashboard using the VM's private Tailscale IP and port 5000.
6. Change the initial admin/admin123 password before creating company records.
7. Configure the Client PC and run CLIENT_PC_SETUP.bat, then START_CLIENT_PC.bat. Open http://127.0.0.1:5100/setup for IP Check, LAN passkey and backup folder setup.
8. Build the Android APK in GitHub Actions without a domain input. Enter the Central Funnel HTTPS URL once in the app after installation.

ANDROID AND SCHEDULES
Sign in online once to download the allowed checkpoints and recurring reminders. Android can then sign in offline using its encrypted cached credential, scan cached points, and queue events. The Super Admin creates schedules and grants schedule permission per Client PC. Central validates that permission on every schedule change.
Install APK updates over the existing app; do not uninstall if the phone still has offline records. Keep one Android signing key for every future GitHub APK build.

FREE HOSTING LIMIT
Tailscale Funnel exposes an already-running service; it does not host the server. A cloud VM is needed for Central to keep running while an office PC is off. Free VM availability and continuous runtime are not guaranteed by this package.

LANGUAGE GUIDES
MASTER_ARCHITECTURE_TAMIL_EN.md — architecture, cloud setup, LAN, offline flow, backup.
ANDROID_GITHUB_BUILD_TAMIL.md — GitHub Actions APK steps in Tamil.
