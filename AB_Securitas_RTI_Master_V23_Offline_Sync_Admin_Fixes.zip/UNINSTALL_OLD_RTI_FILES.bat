@echo off
setlocal
cd /d "%~dp0"
set "INSTALL_ROOT=%~dp0"
if not exist "START_ALL.bat" (
  echo This does not look like an AB Securitas RTI install folder.
  pause
  exit /b 1
)
if not exist "Web\app.py" (
  echo Web\app.py was not found. No files were removed.
  pause
  exit /b 1
)
if not exist "ClientPC\app.py" (
  echo ClientPC\app.py was not found. No files were removed.
  pause
  exit /b 1
)
cd /d "%TEMP%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%INSTALL_ROOT%scripts\uninstall_old_rti_files.ps1" -InstallRoot "%INSTALL_ROOT%"
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" echo Uninstall was cancelled or failed. Review the message above.
pause
exit /b %RESULT%
