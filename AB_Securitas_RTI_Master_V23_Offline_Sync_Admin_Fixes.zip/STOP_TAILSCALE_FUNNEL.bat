@echo off
setlocal
where.exe tailscale >nul 2>nul
if errorlevel 1 (
  echo Tailscale CLI was not found on PATH.
  pause
  exit /b 1
)
rem Use the same explicit HTTP target as START_TAILSCALE_FUNNEL.bat.
rem Naming the URL avoids matching the legacy numeric-port CLI syntax.
tailscale funnel --https=443 http://127.0.0.1:5200 off
if errorlevel 1 (
  echo Could not stop the mobile API Funnel on port 443.
  pause
  exit /b 1
)
echo Tailscale Funnel for the mobile API has been stopped.
pause
