# Changelog

## Master V23.0.0

- Offline Android scans now calculate and display repeat results locally: the second scan is `REPEAT`, and the third or later scan raises the existing Repeat Alert. All offline events remain queued for synchronization.
- LAN status now distinguishes PC reachability from Central node/company token authentication. Android LAN diagnostics name common address, timeout, and refused-connection failures.
- Added Super Admin bulk deletion for scan history with one audit record per deletion, atomically written with the delete.
- Added permanent inspector profile/credential erasure and permanent device access blocking through audit-preserving tombstones.
- Added activation-key copy controls and removed the Company ID copy control while keeping the numeric ID visible.
- Added a confirmed Windows uninstaller that stops services and preserves environment files, local data and backup folders before removing the selected application folder.
- Incremented Android versionCode/versionName to 27 / 23.0.0; QR scanner implementation remains unchanged.

## Master V22.0.0

- Replaced unreliable CameraX-to-preview bounds transforms with direct cropping of the analyzer frame to CameraX's shared preview viewport. ML Kit now receives only the visible scan square, and its returned QR bounds are verified against that same bitmap. This prevents visible in-square QR codes from being rejected due to mismatched coordinate spaces and prevents codes outside the square from being scanned.
- Incremented Android versionCode/versionName to 26 / 22.0.0 and prioritized the V22 QR scanner source ZIP in the GitHub APK workflow.

## Master V21.0.0

- Fixed QR rejection caused by applying the ImageProxy crop rectangle to ML Kit bounds that are reported in the full rotated input-image coordinate space. QR codes still must fit fully inside the scanner square.
- Incremented Android versionCode/versionName to 25 / 21.0.0 and prioritized the V21 source ZIP in the GitHub APK workflow.

## Master V20 startup fix

- Accept Tailscale Funnel startup when the CLI reports a non-zero result but Funnel status confirms the expected HTTPS route to the local mobile API proxy.

## Master V20.0.0

- Fixed QR scan framing by binding CameraX Preview and ImageAnalysis to one PreviewView viewport; guidance now reports when a QR is outside the square or is not an RTI checkpoint.
- Removed the white-screen QR rejection that blocked valid QR codes displayed during setup/testing. Scans still require the complete QR bounds to be inside the scan square.
- Added visible, copyable numeric Company IDs to the Central Company Directory and clearer Client PC setup guidance so the Company Code is not mistaken for the ID.
- Generated a stable unique Client PC ID during first installation, displayed it read-only in setup, and added checks for a missing or changed ID.
- Added Super Admin Client PC rename, block/enable, and schedule-permission controls with audit records; blocked Client PCs are rejected by Central and their inspection history is kept.
- Exposed the connected Company ID in Client PC health/status and Android LAN checks; the phone warns when its company and Client PC company differ.
- Incremented Android versionCode/versionName to 24 / 20.0.0 and prioritized the V20 master source ZIP in the GitHub APK workflow.

## Master V19.0.0

- Fixed the Android scanner layering so the live camera feed appears only inside the framed square, with the surrounding scanner area kept black.
- Added a separate Android Settings screen protected by the default 1234 PIN; a successful online inspector login enables changing the PIN.
- Made Android login and Settings inputs scroll above the software keyboard.
- Added Super Admin device controls to rename, block, restore, soft-remove, and limit device access to selected inspectors. Revoked device sessions are rejected while existing scan history is retained.
- Added live Client PC event refresh with immediate refresh when the monitor returns to the foreground, plus automatic no-cache History refresh.
- Exposed editable scan spacing and schedule grace periods in Super Admin settings and schedule management.
- Incremented Android versionCode/versionName to 23 / 19.0.0 and prioritized the V19 source ZIP in the GitHub APK workflow.

## Master V18.0.0

- Redesigned Android inspector login with a polished navy and blue branded background, raised login card, clearer fields, and a prominent secure-login button.
- Restricted the Android camera preview to the scan square, blacked out the surrounding area, and reject QR detections unless the full code bounds are inside the visible frame.
- Added typed autocomplete filters for date, company, point, inspector name/ID, device, schedule, inspection mode, sync source, and result in Scan History and Reports.
- Added date range, company, user, action, entity category/ID, audit record ID, and quick-search filters to Audit Logs; filter choices come from saved records.
- Added a one-click Central sync token repair command that backs up private `.env` files, aligns tokens for saved company/client IDs, and leaves inspection databases untouched.
- Incremented Android versionCode/versionName to 22 / 18.0.0.

## Master V17.0.0

- Added separate Internet, Central server, Client PC/LAN, and Central-sync health indicators in Android, with status-change notifications while the app is running.
- Moved Android connection options behind a gear-only settings control and made the Central domain editable from login and inspection home.
- Added a Client PC Central connection test that checks node credentials and company sync credentials independently, reports actionable HTTP 401/403 causes, and reduces repetitive authentication-error logging.
- Clarified that Central token mappings must match the configured Company ID / Client PC ID and that schedule permissions do not issue API credentials.
- Exposed Client PC Central reachability, authentication, last successful sync, and queued event count to the Android LAN status screen.
- Added integrity-checked restore actions for Central and Client PC databases; each restore first creates a separate rollback backup.
- Kept both databases in persistent data folders and kept backup folders outside replaceable source folders.
- Incremented Android versionCode/versionName for the V17 build.

## Master V16.0.0

- Moved Central and Client PC SQLite databases to persistent data folders outside replaceable source folders and kept legacy copies during first migration.
- Added selectable separate backup destinations, integrity-checked timestamped backups, daily backup workers, and disabled automatic backup pruning.
- Preserved manual, scheduled, offline queue, schedule name, and assigned checkpoint information through Android, Client PC, Central, and reports.
- Added offline schedule checkpoint enforcement and configurable scan gaps to the Android offline scanner.
- Added scan success dialogs with an OK action and explicit schedule/offline sync status.
- Added the local Client PC setup page for IP checks, private LAN passkey creation, Android connection setup, and backups.
- Prioritized the V16 master source ZIP in the GitHub APK workflow and fixed the Android layout XML ampersand parse error.

## Master V15.2

- Added an in-app Company Server Domain field that validates and saves the HTTPS Tailscale Funnel origin on the phone.
- Removed the Funnel URL prompt from GitHub Actions and made the build-time URL an optional default.
- Preserved existing app preferences, cached credentials, device ID, and offline inspection queue when no server domain is configured.

## Master V15.0

- Added an offline-first Android event store with encrypted cached sign-in credentials, cached checkpoints, retry sync, and device/server timestamp separation.
- Added Android recurring schedule notifications with boot restoration.
- Added Internet-first, Client PC LAN fallback, and local queue behavior for inspection records.
- Added token-protected Client PC LAN ingestion, persistent event queue, cloud retry sync, and local-only monitor access.
- Added central schedules, per-client schedule permissions, backend permission enforcement, and server due/late/missed/offline notifications.
- Added authenticated Client PC bootstrap and company/client-scoped node credentials.
- Added Linux VM deployment services, persistent SQLite storage, daily backups, and a private Tailscale admin route.
- Kept the existing dashboard, inspector and company administration, QR points, licensing, reports, Android camera scanning, and GitHub APK build workflow.
- Updated Windows setup and bilingual architecture/build documentation.
