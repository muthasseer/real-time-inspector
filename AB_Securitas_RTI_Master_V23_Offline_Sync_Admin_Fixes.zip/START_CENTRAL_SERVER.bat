@echo off
setlocal
cd /d "%~dp0"
if not exist Web\.venv\Scripts\python.exe (echo Run INSTALL_SETUP.bat first.& pause & exit /b 1)
cd Web
echo Central dashboard: http://127.0.0.1:5000
echo Dashboard is local-only. Tailscale Funnel publishes only the mobile API proxy.
.venv\Scripts\python.exe app.py
pause
