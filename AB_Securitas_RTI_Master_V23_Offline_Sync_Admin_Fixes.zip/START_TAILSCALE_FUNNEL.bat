@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo ==================================================
echo AB SECURITAS - TAILSCALE FUNNEL (MOBILE + CLIENT SYNC)
echo ==================================================
echo Start START_CENTRAL_SERVER.bat and START_MOBILE_API_PROXY.bat first.
echo Funnel publishes only the allow-listed API proxy on 127.0.0.1:5200.
echo The admin dashboard stays local; Client PC sync requires its company token.
echo On first use, open the approval link printed by Tailscale and enable Funnel.
echo.
where.exe tailscale >nul 2>nul
if errorlevel 1 (
  echo Tailscale CLI was not found on PATH.
  echo Install and sign in to Tailscale on this PC, then run this file again.
  pause
  exit /b 1
)
where.exe curl.exe >nul 2>nul
if not errorlevel 1 (
  for /f %%H in ('curl.exe --silent --show-error --output NUL --write-out "%%{http_code}" --max-time 4 http://127.0.0.1:5200/api/mobile/state') do set "RTI_PROXY_STATUS=%%H"
  if not "!RTI_PROXY_STATUS!"=="200" if not "!RTI_PROXY_STATUS!"=="401" (
    echo Mobile API proxy is not ready at 127.0.0.1:5200. Start it first.
    pause
    exit /b 1
  )
)
tailscale funnel --https=443 --bg http://127.0.0.1:5200
if errorlevel 1 (
  echo Funnel could not be enabled. Check the Tailscale sign-in, MagicDNS,
  echo HTTPS certificates, tailnet Funnel policy, and Tailscale admin approval.
  pause
  exit /b 1
)
echo.
echo Current Funnel configuration:
tailscale funnel status
echo.
echo Enter the https://...ts.net address above in the Android app's
echo Company Server Domain field. APK builds no longer need the domain.
pause
