# AB Securitas Real Time Inspector — Master V23

Offline-first checkpoint inspections for Android and Windows Client PCs. The central API can run on a cloud VM so the mobile and LAN services do not depend on the administrator's laptop being powered on.

## Architecture

~~~mermaid
flowchart LR
    A[Android inspector app] -->|Primary: HTTPS| F[Tailscale Funnel]
    A -->|Fallback: private Wi-Fi LAN| C[Client PC local API]
    A -->|No network: encrypted login + local SQLite queue| A
    F --> P[Mobile-only API proxy]
    P --> W[Central Flask API]
    W --> D[(Persistent SQLite database)]
    C -->|Authenticated retry sync| F
    S[Super Admin over tailnet] -->|Private access| W
~~~

- Tailscale Funnel publishes only the allow-listed mobile proxy on port 5200. The admin dashboard stays on the private tailnet at port 5000.
- Android tries the central HTTPS API first, then a configured Client PC LAN address, then retains events in its local database.
- Client PC stores LAN submissions and forwards them to Central with a per-node credential. Event IDs make retries idempotent.
- A cloud VM keeps Central available when an office PC is off. Funnel is a public HTTPS path to a running service; it does not host that service.
- The Linux deployment uses persistent SQLite storage and daily backups. Free VM capacity and uninterrupted availability depend on the VM provider and are not guaranteed.

## Core inspection capabilities

- Android offline sign-in after a successful online login. The cached password is encrypted with Android Keystore; the app never stores it as plain text.
- Cached checkpoint QR data and recurring schedules for offline inspection.
- Durable local inspection records with unique event IDs, retry sync, and separate device-created and server-received timestamps.
- Central and Client PC SQLite databases live outside the replaceable app folders; old database files are copied forward and retained.
- Super Admin can select a separate backup folder, create a manual backup, and keep timestamped daily backups without automatic cleanup.
- Manual, scheduled, and offline scans retain their inspection mode, schedule, and sync source in central reports and the Client PC monitor.
- Android schedules start the assigned inspection when the inspector taps the reminder, enforce the assigned checkpoints offline, and show schedule sync completion.
- Super Admin scan spacing is applied to both online and offline scans.
- Client PC local setup page creates the LAN passkey, checks local IP addresses, tests backup storage, and shows Android connection details.
- Android accepts the Central domain inside the app, so APK builds do not need to ask for a server URL.
- Internet-first sync with direct LAN fallback through the Client PC. If both links are unavailable, Android continues to queue records locally.
- Client PC local event storage and automatic central retry after connectivity returns.
- Super Admin schedule management and per-Client-PC schedule permission. The permission is checked by the Central API on every Client PC schedule write.
- Android reminders, server due/late/missed alerts, and live dashboard notifications.
- Existing companies, inspectors, QR points, scan history, reports, licensing, and GitHub Actions APK build workflow.

## V23 offline sync, history and access controls

- Offline repeat counts are calculated from the phone's saved inspection events. The second scan shows Repeat; the third and later show Repeat Alert, while every scan remains queued for sync.
- Client PC setup reports Central reachability, node-token authentication and company-sync authentication separately. Android LAN testing reports the Client PC result and Central sync state, with clearer DNS, timeout and connection-refused errors.
- Super Admin can select and delete scan history; each removed scan gets an Audit Log entry in the same database transaction.
- Deleted inspector profiles can be permanently erased, including login credentials. Deleted devices can be permanently blocked; their IDs stay reserved so they cannot re-register automatically. Scan snapshots and audit history remain intact.
- Activation keys have a Copy button. Numeric Company IDs remain visible in the Company Directory without a Copy button.
- `UNINSTALL_OLD_RTI_FILES.bat` stops RTI services, copies app configuration and data/backups to a separate local folder, then removes only the confirmed application folder.
- Android and Central version 23.0.0 / Android versionCode 27. The QR scanner implementation is unchanged from V22.

## V22 QR scan crop fix

- CameraX now crops each analysis frame to the same viewport used by the visible scanner square, rotates that cropped bitmap upright, and sends only that square to ML Kit. QR coordinates are therefore measured directly in the scan square; no preview-to-camera transform is used.
- A QR must still be fully inside the cropped square, and only `RTI-` checkpoint tokens proceed to checkpoint validation.
- Updated Android and Central version to 22.0.0. The GitHub APK workflow now selects the V22 source ZIP first.

## V20 scan, company ID, and Client PC access

- Preview and QR analysis use the same CameraX viewport. A QR must fit fully inside the square; the app explains when a detected QR is outside it or is not an RTI checkpoint.
- Valid RTI QR codes shown on a monitor or phone can be scanned for setup and testing. Checkpoint membership and server validation still apply.
- Central Company Directory shows each numeric Company ID with a Copy ID button. Client PC Setup explains where to find it and distinguishes it from Company Code.
- INSTALL_SETUP generates and saves a stable unique Client PC ID. Setup displays it read-only and offers a copy action.
- Super Admin can rename a registered Client PC, block or enable access, and grant or revoke schedule editing. Blocking takes effect on subsequent API requests and does not delete scan history.
- Android LAN status compares the logged-in company ID with Client PC's reported company ID and reports a mismatch before it is mistaken for a healthy LAN sync.

## V19 device access, scanner, and live updates

- The QR camera preview is inside the marked square; the rest of the scanning screen stays black. QR acceptance still requires the full detected code to fit inside the square.
- Android Connection Settings open on a separate screen protected by the default PIN `1234`. After a successful online inspector login, the PIN can be changed from that screen.
- Android login and settings forms move the focused field above the keyboard.
- Super Admin can change a registered Device ID, block or restore it, soft-remove it, and restrict access to selected inspectors. Blocking/removing revokes active sessions; historical scans remain saved.
- Client PC event history refreshes every three seconds and immediately when the tab becomes visible. Central History refreshes automatically while idle and provides a manual refresh action.
- Super Admin can edit the allowed QR scan interval and each schedule’s start grace period.

## V17 connection and recovery updates

- Android shows separate Internet, Central server, Client PC/LAN, Central sync, and queued-event status while the app is open. Status checks run on launch, when network state changes, and every 30 seconds; Android posts a notification when those connection states change.
- Android domain and LAN configuration are under the gear icon on the login and inspection screens.
- Client PC Setup includes a Central test that checks the node credential and company event-sync credential separately. HTTP 401 shows that the domain is reachable but an ID or token does not match. HTTP 403 reports the Central server's specific reason.
- Central and Client PC backup screens can restore a valid database backup. Restore always writes a separate safety backup of the current database first.
- Client PC sync checks retry on a short interval; authentication failures are reported clearly and logged only when the error changes.

## V18 inspector experience and search

- Android login uses a polished blue security theme and a raised login card; scanner preview is limited to the marked square and all surrounding camera area stays black.
- A QR is accepted only when its complete detected bounds fit inside the scan square.
- Scan History, Reports, and Audit Logs support date ranges and category filters. Existing company, inspector, point, device, schedule, action, and entity values appear as typeable suggestions.
- If Central sync reports token authentication errors after saving Company ID and Client PC ID, run `REPAIR_SYNC_TOKENS.bat` from the installed master folder. It stores private `.env` backups in `private-config-backups`, fixes credentials for the saved IDs, and does not modify the scan databases. Restart with `STOP_ALL.bat` and `START_ALL.bat` afterward.

Connection-change notifications require Android notification permission. The Android app must be running for its live connection checks; scheduled inspection reminders remain managed separately by Android alarms.

Offline data is not visible to Central until a device or Client PC can reach it. Offline credentials and cached schedules may be stale until the next server sync. Device timestamps are marked as device-reported; the app compares the device clock with its last trusted server time and warns about a large difference.

## Cloud VM deployment

The recommended topology is a Linux cloud VM with Tailscale installed. The included installer supports Debian and Ubuntu:

1. Install and sign in to Tailscale on the VM.
2. From the extracted project root, run:

   sudo bash deploy/linux/install.sh

3. Run sudo tailscale up, approve the device, and enable Funnel for the tailnet.
4. Enable the proxy endpoint with sudo systemctl enable --now rti-funnel.
5. Read the HTTPS address from sudo tailscale funnel status.
6. Enter that address in the Android app's Connection Settings and in each Client PC configuration; the APK build does not need the domain.
7. Open the admin dashboard from a device signed in to the same tailnet at the VM's Tailscale IP on port 5000.

Keep public firewall ingress closed for ports 5000 and 5200. Port 5000 is for private tailnet administration. Funnel forwards public API requests to the loopback-only proxy on port 5200. Database files and private environment files are stored outside the source repository.

The installer creates a generated Client PC credential template at /var/lib/ab-securitas-rti/client-1.env. Keep it private. It contains per-company and per-client credentials. Change the first-run Super Admin password before adding company data. The initial account is admin / admin123 and requires a password change.

Daily SQLite backups are stored under /var/lib/ab-securitas-rti/backups, with 14 days retained. Also copy backups to separate storage as part of the deployment's backup routine.

## Client PC LAN setup

On the Windows Client PC, run CLIENT_PC_SETUP.bat and then START_CLIENT_PC.bat. Open http://127.0.0.1:5100/setup. Enter the Central Funnel URL, company ID, and unique client ID. The Central server administrator provisions the matching private tokens; keep them only in the Central and Client PC `.env` files. Use IP Check and Create new passkey on the setup page, then enter the shown LAN address and passkey in the Android app's LAN configuration. Use the setup page to select a dedicated backup folder.

The Company ID and Client PC ID must match the Central server's private token entries exactly. On Central, `RTI_CLIENT_SYNC_TOKENS` maps each Company ID to its company sync token, and `RTI_CLIENT_NODE_TOKENS` maps each `company_id/client_id` pair to its private Client PC token. Put the corresponding values in the Client PC's private `.env` file too. The setup page only saves the domain and IDs; it cannot create those server credentials. `Schedules & Client Access` grants schedule-edit permission after the first authenticated sync. If a Central test shows HTTP 401, check the IDs and both token mappings before retrying.

Run START_CLIENT_PC.bat. The Client PC listens on port 5100 for Android LAN event submission. Its event-monitor page is restricted to the local PC. Create a Windows Defender Firewall rule that allows TCP 5100 only on the trusted Private network when Android LAN fallback is required. Do not expose the port to public networks.

After the Client PC's first central sync, it appears in the Super Admin Schedules & Client Access page. Grant schedule permission there if that PC should be allowed to create its own schedules.

## Android and GitHub Actions

Push the project contents so Android, Web, ClientPC, MobileApiProxy, scripts, deploy, and .github are at the repository root. In GitHub, open Actions, choose “Build AB Securitas Real Time Inspector APK,” and run the workflow. The inspector enters the Central Tailscale Funnel HTTPS origin in the app after installation.

The workflow compiles the Android source and uploads the debug APK. It does not deploy the Central server. Store private tokens and environment files outside GitHub. The APK contains the public Funnel origin only; mobile and LAN credentials are entered or delivered at runtime.

See MASTER_ARCHITECTURE_TAMIL_EN.md and ANDROID_GITHUB_BUILD_TAMIL.md for setup instructions.

## Windows single-PC mode

INSTALL_SETUP.bat and START_ALL.bat remain available for a small local setup or development. In that mode the Central server and Funnel run on that Windows PC. Turning that PC off makes Central unavailable; use the cloud VM deployment above when the server must continue independently.

## Data and security

- Keep Web/.env, ClientPC/.env, SQLite databases, and generated client credential files private.
- Use a different company/client node token for each Client PC.
- The LAN token protects Android submissions to the Client PC; restrict port 5100 to the trusted LAN.
- The public Funnel proxy has a method-and-route allowlist. It does not publish the admin dashboard.
- Do not commit passwords, tokens, private keys, databases, or APK signing credentials.
