@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo ==========================================
echo AB SECURITAS RTI - TAILSCALE FUNNEL SETUP
echo ==========================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python 3.11+ is required. Install from https://www.python.org/downloads/ and enable Add Python to PATH.
  if not defined RTI_INSTALL_NO_PAUSE pause
  exit /b 1
)
if not exist Web\.env copy Web\.env.example Web\.env >nul
if not exist ClientPC\.env copy ClientPC\.env.example ClientPC\.env >nul
if not exist Web\.venv\Scripts\python.exe py -3 -m venv Web\.venv
if errorlevel 1 goto :setup_failed
Web\.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :setup_failed
Web\.venv\Scripts\python.exe -m pip install -r Web\requirements.txt
if errorlevel 1 goto :setup_failed
Web\.venv\Scripts\python.exe -m pip install -r ClientPC\requirements.txt
if errorlevel 1 goto :setup_failed
rem Replace only the shipped placeholder; preserve an existing user's secret.
findstr /c:"RTI_SECRET_KEY=CHANGE-TO-A-LONG-RANDOM-SECRET" Web\.env >nul
if not errorlevel 1 (
  for /f "delims=" %%G in ('py -3 -c "import secrets; print(secrets.token_urlsafe(48))"') do set "RTI_NEW_SECRET=%%G"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='Web\.env'; $s=Get-Content -Raw $p; $s=$s.Replace('RTI_SECRET_KEY=CHANGE-TO-A-LONG-RANDOM-SECRET', 'RTI_SECRET_KEY=!RTI_NEW_SECRET!'); Set-Content -Path $p -Value $s -NoNewline -Encoding ascii"
  if errorlevel 1 (echo WARNING: Automatic secret generation failed; manually replace RTI_SECRET_KEY in Web\.env.) else echo A strong Web RTI_SECRET_KEY was generated locally.
)
Web\.venv\Scripts\python.exe scripts\configure_sync.py
if errorlevel 1 goto :setup_failed
echo.
echo Keep both .env files and local databases out of GitHub.
echo For another Client PC, copy its company's token from Web\.env into ClientPC\.env privately.
echo Read MASTER_ARCHITECTURE_TAMIL_EN.md for the VM, Tailscale, LAN, and GitHub setup.
if not defined RTI_INSTALL_NO_PAUSE pause
exit /b 0

:setup_failed
echo.
echo Setup did not finish. Check the error above and run INSTALL_SETUP.bat again.
if not defined RTI_INSTALL_NO_PAUSE pause
exit /b 1
