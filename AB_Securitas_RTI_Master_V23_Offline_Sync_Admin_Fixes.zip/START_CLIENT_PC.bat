@echo off
setlocal
cd /d "%~dp0"
if not exist ClientPC\.env (
  echo Run CLIENT_PC_SETUP.bat first.
  pause
  exit /b 1
)
cd ClientPC
echo Client PC event monitor: http://127.0.0.1:5100
echo Client PC setup, IP check, LAN passkey and backups: http://127.0.0.1:5100/setup
echo Android LAN sync API: port 5100 (token protected)
if exist .venv\Scripts\python.exe (
  .venv\Scripts\python.exe app.py
) else if exist ..\Web\.venv\Scripts\python.exe (
  ..\Web\.venv\Scripts\python.exe app.py
) else (
  py -3 app.py
)
pause
