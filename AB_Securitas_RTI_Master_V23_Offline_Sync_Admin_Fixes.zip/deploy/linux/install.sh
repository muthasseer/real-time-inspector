#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
INSTALL_DIR="/opt/ab-securitas-rti"
STATE_DIR="/var/lib/ab-securitas-rti"
APP_USER="rti"

if [[ "$EUID" -ne 0 ]]; then
  echo "Run this installer with sudo: sudo bash deploy/linux/install.sh" >&2
  exit 1
fi

if ! command -v apt-get >/dev/null 2>&1; then
  echo "This installer currently supports Debian and Ubuntu Linux hosts." >&2
  exit 1
fi
if ! command -v tailscale >/dev/null 2>&1; then
  echo "Install and sign in to Tailscale on this VM before continuing (official Linux instructions: https://tailscale.com/download/linux)." >&2
  exit 1
fi

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip rsync sqlite3

if ! id -u "$APP_USER" >/dev/null 2>&1; then
  useradd --system --home-dir "$STATE_DIR" --shell /usr/sbin/nologin "$APP_USER"
fi

install -d -o "$APP_USER" -g "$APP_USER" "$INSTALL_DIR" "$STATE_DIR" "$STATE_DIR/backups"
install -d -o "$APP_USER" -g "$APP_USER" "$INSTALL_DIR/Web" "$INSTALL_DIR/MobileApiProxy"
rsync -a --delete --exclude='.env' --exclude='*.db' --exclude='.venv' "$ROOT_DIR/Web/" "$INSTALL_DIR/Web/"
rsync -a --delete "$ROOT_DIR/MobileApiProxy/" "$INSTALL_DIR/MobileApiProxy/"

if [[ ! -f "$INSTALL_DIR/Web/.env" ]]; then
  SECRET="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
  SYNC_TOKEN="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
  NODE_TOKEN="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
  cat > "$INSTALL_DIR/Web/.env" <<EOF
RTI_SECRET_KEY=$SECRET
RTI_CLIENT_SYNC_TOKENS=1:$SYNC_TOKEN
RTI_CLIENT_NODE_TOKENS=1/CLIENT-1:$NODE_TOKEN
RTI_DATABASE_PATH=$STATE_DIR/inspector.db
RTI_WEB_HOST=0.0.0.0
RTI_WEB_PORT=5000
RTI_COOKIE_SECURE=0
RTI_MIN_POINT_GAP=8
EOF
  cat > "$STATE_DIR/client-1.env" <<EOF
RTI_CENTRAL_FUNNEL_URL=https://SET-AFTER-TAILSCALE.ts.net
RTI_CLIENT_SYNC_TOKEN=$SYNC_TOKEN
RTI_COMPANY_ID=1
RTI_CLIENT_ID=CLIENT-1
RTI_CLIENT_NODE_TOKEN=$NODE_TOKEN
RTI_POLL_SECONDS=5
RTI_CLIENT_PORT=5100
RTI_CLIENT_HOST=0.0.0.0
EOF
  chmod 600 "$INSTALL_DIR/Web/.env" "$STATE_DIR/client-1.env"
  echo "Generated private API credentials; a Client PC configuration template is in $STATE_DIR/client-1.env."
else
  echo "Keeping the existing Web/.env and its secrets."
fi

python3 -m venv "$INSTALL_DIR/.venv"
"$INSTALL_DIR/.venv/bin/pip" install --upgrade pip
"$INSTALL_DIR/.venv/bin/pip" install -r "$INSTALL_DIR/Web/requirements.txt"

install -m 0644 "$ROOT_DIR/deploy/linux/rti-web.service" /etc/systemd/system/rti-web.service
install -m 0644 "$ROOT_DIR/deploy/linux/rti-proxy.service" /etc/systemd/system/rti-proxy.service
install -m 0644 "$ROOT_DIR/deploy/linux/rti-funnel.service" /etc/systemd/system/rti-funnel.service
install -m 0644 "$ROOT_DIR/deploy/linux/rti-backup.service" /etc/systemd/system/rti-backup.service
install -m 0644 "$ROOT_DIR/deploy/linux/rti-backup.timer" /etc/systemd/system/rti-backup.timer
install -m 0755 "$ROOT_DIR/deploy/linux/backup.sh" "$INSTALL_DIR/backup.sh"

chown -R "$APP_USER:$APP_USER" "$INSTALL_DIR" "$STATE_DIR"
chmod 600 "$INSTALL_DIR/Web/.env"
systemctl daemon-reload
systemctl enable --now tailscaled rti-web rti-proxy rti-backup.timer

cat <<EOF

Central API and mobile-only proxy are installed.

Next:
  1. Sign in to Tailscale on this VM: sudo tailscale up
  2. Approve Funnel for the tailnet, then enable it:
       sudo systemctl enable --now rti-funnel
  3. Read the Funnel URL:
       sudo tailscale funnel status
  4. Set the URL in the Client PC's private .env file.
  5. Keep VM firewall rules closed for TCP 5000 and 5200. Admin access uses
     the VM's private Tailscale address on TCP 5000; Funnel exposes only the
     allow-listed mobile proxy on localhost TCP 5200.
  6. Open the dashboard over the tailnet at http://<tailscale-ip>:5000 and
     change the first-run admin password before adding a company.

The generated Client PC configuration template is at:
  $STATE_DIR/client-1.env
EOF
