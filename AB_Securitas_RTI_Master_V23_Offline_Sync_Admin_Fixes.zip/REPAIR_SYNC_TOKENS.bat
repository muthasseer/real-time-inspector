@echo off
setlocal
cd /d "%~dp0"
if not exist Web\.venv\Scripts\python.exe (
  echo RTI Python environment is missing. Run INSTALL_SETUP.bat first.
  pause
  exit /b 1
)
echo This repairs matching tokens only when this folder contains both Central Web and Client PC.
echo If Central runs from another computer or project folder, configure and restart it there too.
echo Secret values will not be printed; existing configuration is backed up first.
echo.
Web\.venv\Scripts\python.exe scripts\repair_sync_tokens.py
if errorlevel 1 (
  echo.
  echo Token repair did not finish. Existing configuration backups, if created, are in private-config-backups.
  pause
  exit /b 1
)
echo.
echo Run STOP_ALL.bat, then START_ALL.bat to restart Central and Client PC.
pause
exit /b 0
