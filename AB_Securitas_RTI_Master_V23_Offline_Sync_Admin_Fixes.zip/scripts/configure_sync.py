"""Create a company-scoped token shared by Central and the local Client PC."""

from pathlib import Path
import secrets
import sys

ROOT = Path(__file__).resolve().parent.parent
CENTRAL_ENV = ROOT / "Web" / ".env"
CLIENT_ENV = ROOT / "ClientPC" / ".env"
PLACEHOLDER = "CHANGE-TO-A-LONG-RANDOM-SYNC-TOKEN"
NODE_PLACEHOLDER = "CHANGE-TO-A-LONG-RANDOM-NODE-TOKEN"
LAN_PLACEHOLDER = "CHANGE-TO-A-LONG-RANDOM-LAN-TOKEN"


def read_values(path):
    values = {}
    lines = path.read_text(encoding="utf-8").splitlines()
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        values[key.strip()] = value.strip()
    return lines, values


def write_value(path, lines, key, value):
    prefix = key + "="
    for index, line in enumerate(lines):
        if line.strip().startswith(prefix):
            lines[index] = prefix + value
            break
    else:
        lines.append(prefix + value)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    central_lines, central_values = read_values(CENTRAL_ENV)
    client_lines, client_values = read_values(CLIENT_ENV)
    company_id = client_values.get("RTI_COMPANY_ID", "1").strip()
    if not company_id.isdigit():
        print("RTI_COMPANY_ID must be a numeric company ID in ClientPC/.env.", file=sys.stderr)
        return 1
    client_id = client_values.get("RTI_CLIENT_ID", "").strip()
    if not client_id:
        existing_nodes = {
            entry.partition(":")[0].strip()
            for entry in central_values.get("RTI_CLIENT_NODE_TOKENS", "").split(";")
            if ":" in entry
        }
        while True:
            client_id = "CLIENT-" + secrets.token_hex(4).upper()
            if f"{company_id}/{client_id}" not in existing_nodes:
                break
        write_value(CLIENT_ENV, client_lines, "RTI_CLIENT_ID", client_id)
    if not client_id.replace("-", "").replace("_", "").replace(".", "").isalnum():
        print("RTI_CLIENT_ID may contain letters, numbers, dot, underscore, and hyphen only.", file=sys.stderr)
        return 1

    tokens = {}
    for item in central_values.get("RTI_CLIENT_SYNC_TOKENS", "").split(";"):
        configured_id, separator, token = item.partition(":")
        if separator and configured_id.strip().isdigit() and token.strip():
            tokens[configured_id.strip()] = token.strip()
    token = tokens.get(company_id, "")
    if not token or token == PLACEHOLDER:
        token = secrets.token_urlsafe(48)
        tokens[company_id] = token
        merged = ";".join(f"{key}:{value}" for key, value in sorted(tokens.items(), key=lambda item: int(item[0])))
        write_value(CENTRAL_ENV, central_lines, "RTI_CLIENT_SYNC_TOKENS", merged)

    client_token = client_values.get("RTI_CLIENT_SYNC_TOKEN", "").strip()
    if not client_token or client_token == PLACEHOLDER:
        write_value(CLIENT_ENV, client_lines, "RTI_CLIENT_SYNC_TOKEN", token)
    elif client_token != token:
        print("The existing Client PC token differs from Central. Copy the matching company token from Web/.env to ClientPC/.env.")

    node_map = {}
    for item in central_values.get("RTI_CLIENT_NODE_TOKENS", "").split(";"):
        node_key, separator, node_token = item.partition(":")
        if separator and node_key.strip() and node_token.strip():
            node_map[node_key.strip()] = node_token.strip()
    node_key = f"{company_id}/{client_id}"
    node_token = node_map.get(node_key, "")
    if not node_token or node_token == NODE_PLACEHOLDER:
        node_token = secrets.token_urlsafe(48)
        node_map[node_key] = node_token
        merged_nodes = ";".join(f"{key}:{value}" for key, value in sorted(node_map.items()))
        write_value(CENTRAL_ENV, central_lines, "RTI_CLIENT_NODE_TOKENS", merged_nodes)
    client_node_token = client_values.get("RTI_CLIENT_NODE_TOKEN", "").strip()
    if not client_node_token or client_node_token == NODE_PLACEHOLDER:
        write_value(CLIENT_ENV, client_lines, "RTI_CLIENT_NODE_TOKEN", node_token)
    elif client_node_token != node_token:
        print("The Client PC node token differs from Central. Copy the matching RTI_CLIENT_NODE_TOKENS entry privately.")

    lan_token = client_values.get("RTI_LAN_API_TOKEN", "").strip()
    if not lan_token or lan_token == LAN_PLACEHOLDER:
        write_value(CLIENT_ENV, client_lines, "RTI_LAN_API_TOKEN", secrets.token_urlsafe(32))

    print(f"Company ID: {company_id}")
    print(f"Generated Client PC ID: {client_id}")
    print("Private central sync and node credentials are ready; secret values were not printed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
