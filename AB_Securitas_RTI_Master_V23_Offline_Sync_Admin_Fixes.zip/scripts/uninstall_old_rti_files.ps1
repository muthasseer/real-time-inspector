param(
    [Parameter(Mandatory=$true)]
    [string]$InstallRoot
)

$ErrorActionPreference = 'Stop'
$resolvedRoot = (Resolve-Path -LiteralPath $InstallRoot).Path.TrimEnd('\')
$driveRoot = [System.IO.Path]::GetPathRoot($resolvedRoot).TrimEnd('\')
if ($resolvedRoot -eq $driveRoot -or
    -not (Test-Path -LiteralPath (Join-Path $resolvedRoot 'START_ALL.bat')) -or
    -not (Test-Path -LiteralPath (Join-Path $resolvedRoot 'Web\app.py')) -or
    -not (Test-Path -LiteralPath (Join-Path $resolvedRoot 'ClientPC\app.py'))) {
    throw "Refusing to remove '$resolvedRoot': this is not a verified RTI application folder."
}

$backupBase = Join-Path $env:LOCALAPPDATA 'AB Securitas RTI Uninstall Backups'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupRoot = Join-Path $backupBase $stamp
if ($backupRoot.StartsWith(($resolvedRoot.TrimEnd('\') + '\'),[System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to uninstall because the preservation folder would be inside the app folder: $backupRoot"
}
Write-Host "Application folder: $resolvedRoot" -ForegroundColor Yellow
Write-Host "Preserved configuration/data copy: $backupRoot" -ForegroundColor Cyan
Write-Host 'This removes only this RTI application folder. Databases and configured backup folders outside it are copied first and left in place.'
$confirmation = Read-Host 'Type UNINSTALL to stop RTI services, preserve data, and remove this application folder'
if ($confirmation -cne 'UNINSTALL') {
    Write-Host 'Cancelled. Nothing was removed.' -ForegroundColor Yellow
    exit 2
}

$stopScript = Join-Path $resolvedRoot 'scripts\stop_all.ps1'
if (Test-Path -LiteralPath $stopScript -PathType Leaf) {
    try { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $stopScript } catch {
        Write-Host "Service stop reported an issue: $($_.Exception.Message)" -ForegroundColor Yellow
        Write-Host 'Continuing with the confirmed uninstall.' -ForegroundColor Yellow
    }
}

New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
try {
    foreach ($relative in @('Web\.env','ClientPC\.env')) {
        $source = Join-Path $resolvedRoot $relative
        if (Test-Path -LiteralPath $source -PathType Leaf) {
            $name = ($relative -replace '[\\/]', '_')
            Copy-Item -LiteralPath $source -Destination (Join-Path $backupRoot $name) -Force
        }
    }
    $privateConfig = Join-Path $resolvedRoot 'private-config-backups'
    if (Test-Path -LiteralPath $privateConfig -PathType Container) {
        Copy-Item -LiteralPath $privateConfig -Destination (Join-Path $backupRoot 'private-config-backups') -Recurse -Force
    }

    foreach ($relative in @('Web\data','Web\backups','ClientPC\data','ClientPC\backups')) {
        $source = Join-Path $resolvedRoot $relative
        if (Test-Path -LiteralPath $source -PathType Container) {
            $name = ($relative -replace '[\\/]', '_')
            Copy-Item -LiteralPath $source -Destination (Join-Path $backupRoot $name) -Recurse -Force
        }
    }

    $externalFolders = @{}
    foreach ($relativeEnv in @('Web\.env','ClientPC\.env')) {
        $envPath = Join-Path $resolvedRoot $relativeEnv
        if (-not (Test-Path -LiteralPath $envPath -PathType Leaf)) { continue }
        foreach ($line in Get-Content -LiteralPath $envPath) {
            if ($line -match '^\s*(RTI_DATA_DIR|RTI_DATABASE_PATH|RTI_BACKUP_DIR|RTI_CLIENT_DATA_DIR|RTI_CLIENT_DATABASE_PATH|RTI_CLIENT_BACKUP_DIR)\s*=\s*(.*?)\s*$') {
                $value = $Matches[2].Trim().Trim('"').Trim("'")
                if (-not $value) { continue }
                $path = [Environment]::ExpandEnvironmentVariables($value)
                if (-not [System.IO.Path]::IsPathRooted($path)) { $path = Join-Path $resolvedRoot $path }
                try { $fullPath = [System.IO.Path]::GetFullPath($path) } catch { continue }
                $prefix = $resolvedRoot.TrimEnd('\') + '\'
                if ($fullPath.StartsWith($prefix,[System.StringComparison]::OrdinalIgnoreCase)) { continue }
                if ($Matches[1] -in @('RTI_DATABASE_PATH','RTI_CLIENT_DATABASE_PATH')) {
                    if (Test-Path -LiteralPath $fullPath -PathType Leaf) { $fullPath = Split-Path -Parent $fullPath }
                }
                if (Test-Path -LiteralPath $fullPath -PathType Container) { $externalFolders[$fullPath] = $true }
            }
        }
    }
    $externalIndex = 0
    foreach ($folder in $externalFolders.Keys) {
        $backupPrefix = $backupRoot.TrimEnd('\') + '\'
        if ($folder.Equals($backupRoot,[System.StringComparison]::OrdinalIgnoreCase) -or
            $backupRoot.StartsWith(($folder.TrimEnd('\') + '\'),[System.StringComparison]::OrdinalIgnoreCase)) {
            Write-Host "Skipped external data path because it contains the uninstall copy: $folder" -ForegroundColor Yellow
            continue
        }
        $externalIndex++
        $destination = Join-Path $backupRoot ("external-data-{0:D2}" -f $externalIndex)
        Copy-Item -LiteralPath $folder -Destination $destination -Recurse -Force
    }
    foreach ($defaultData in @(
        (Join-Path $env:LOCALAPPDATA 'AB Securitas\Real Time Inspector\data'),
        (Join-Path $env:LOCALAPPDATA 'AB Securitas\Client PC\data')
    )) {
        $prefix = $resolvedRoot.TrimEnd('\') + '\'
        if ((Test-Path -LiteralPath $defaultData -PathType Container) -and
            -not $defaultData.StartsWith($prefix,[System.StringComparison]::OrdinalIgnoreCase) -and
            -not $backupRoot.StartsWith(($defaultData.TrimEnd('\') + '\'),[System.StringComparison]::OrdinalIgnoreCase)) {
            $externalIndex++
            Copy-Item -LiteralPath $defaultData -Destination (Join-Path $backupRoot ("default-data-{0:D2}" -f $externalIndex)) -Recurse -Force
        }
    }
    if (-not (Get-ChildItem -LiteralPath $backupRoot -Force | Select-Object -First 1)) {
        Set-Content -LiteralPath (Join-Path $backupRoot 'NO_LOCAL_DATA.txt') -Value 'No local .env, database, or backup files were found in this installation folder. External app data, if configured, was left in place.'
    }
} catch {
    Write-Host "Preservation copy failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'The application folder was not removed.' -ForegroundColor Yellow
    exit 1
}

Set-Location -LiteralPath $env:TEMP
try {
    Remove-Item -LiteralPath $resolvedRoot -Recurse -Force
    Write-Host 'RTI application files removed.' -ForegroundColor Green
    Write-Host "Preserved configuration/data copy: $backupRoot" -ForegroundColor Cyan
    Write-Host 'Configured data and backup directories outside the app folder were copied and left in place.'
} catch {
    Write-Host "Could not fully remove the app folder: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Preserved data is still available at: $backupRoot" -ForegroundColor Yellow
    exit 1
}
