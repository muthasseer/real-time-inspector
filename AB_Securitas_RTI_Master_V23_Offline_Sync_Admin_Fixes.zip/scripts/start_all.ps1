$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$runtimeDirectory = Join-Path $env:LOCALAPPDATA 'AB Securitas RTI'
$runtimeFile = Join-Path $runtimeDirectory 'runtime.json'
$script:startedProcesses = @()
if (Test-Path -LiteralPath $runtimeFile) {
    try {
        $previousState = Get-Content -LiteralPath $runtimeFile -Raw | ConvertFrom-Json
        foreach ($item in @($previousState.processes)) {
            if ($item -and (Get-Process -Id ([int]$item.pid) -ErrorAction SilentlyContinue)) {
                $script:startedProcesses += @{ name = [string]$item.name; pid = [int]$item.pid; batchPath = [string]$item.batchPath }
            }
        }
    } catch {
        $script:startedProcesses = @()
    }
}

function Save-RuntimeState {
    New-Item -ItemType Directory -Path $runtimeDirectory -Force | Out-Null
    $state = @{ processes = @($script:startedProcesses | Where-Object { $_.pid }) }
    $json = ConvertTo-Json -InputObject $state -Depth 4
    [System.IO.File]::WriteAllText($runtimeFile, $json, [System.Text.UTF8Encoding]::new($false))
}

function Read-EnvFile([string]$Path) {
    $values = @{}
    foreach ($line in Get-Content -LiteralPath $Path -ErrorAction Stop) {
        if ($line -match '^\s*([^#=\s]+)\s*=\s*(.*?)\s*$') {
            $values[$Matches[1]] = $Matches[2].Trim('"').Trim("'")
        }
    }
    return $values
}

function Set-EnvValue([string]$Path, [string]$Name, [string]$Value) {
    $lines = [System.Collections.Generic.List[string]]::new()
    $found = $false
    foreach ($line in Get-Content -LiteralPath $Path -ErrorAction Stop) {
        if ($line -match ('^\s*' + [regex]::Escape($Name) + '\s*=')) {
            $lines.Add($Name + '=' + $Value)
            $found = $true
        } else {
            $lines.Add($line)
        }
    }
    if (-not $found) { $lines.Add($Name + '=' + $Value) }
    [System.IO.File]::WriteAllLines($Path, $lines, [System.Text.UTF8Encoding]::new($false))
}

function Test-LocalPort([int]$Port) {
    $client = [System.Net.Sockets.TcpClient]::new()
    try {
        $result = $client.BeginConnect('127.0.0.1', $Port, $null, $null)
        if (-not $result.AsyncWaitHandle.WaitOne(900)) { return $false }
        $client.EndConnect($result)
        return $true
    } catch {
        return $false
    } finally {
        $client.Close()
    }
}

function Get-HttpStatus([string]$Url) {
    try {
        $response = Invoke-WebRequest -Uri $Url -TimeoutSec 4 -UseBasicParsing
        return [int]$response.StatusCode
    } catch {
        if ($_.Exception.Response -and $_.Exception.Response.StatusCode) {
            return [int]$_.Exception.Response.StatusCode
        }
        return 0
    }
}

function Wait-ForHttp([string]$Url, [int[]]$Accepted, [int]$Seconds, [string]$Name) {
    for ($attempt = 1; $attempt -le $Seconds; $attempt++) {
        $status = Get-HttpStatus $Url
        if ($Accepted -contains $status) { return $status }
        Start-Sleep -Seconds 1
    }
    throw "$Name did not become ready at $Url within $Seconds seconds (last HTTP status: $status)."
}

function Start-ServiceWindow([string]$Name, [string]$BatchFile) {
    $path = Join-Path $root $BatchFile
    $arguments = '/d /k ""{0}""' -f $path
    $process = Start-Process -FilePath $env:ComSpec -ArgumentList $arguments -WorkingDirectory $root -WindowStyle Minimized -PassThru
    $script:startedProcesses += @{ name = $Name; pid = $process.Id; batchPath = $path }
    Save-RuntimeState
    Write-Host "Started $Name (PID $($process.Id))." -ForegroundColor Green
}

function Ensure-Service([string]$Name, [int]$Port, [string]$HealthUrl, [int[]]$Accepted, [string]$BatchFile) {
    if (Test-LocalPort $Port) {
        $status = Get-HttpStatus $HealthUrl
        if ($Accepted -notcontains $status) {
            throw "Port $Port is already occupied, but $Name did not pass its health check (HTTP $status). Close that app and run START_ALL.bat again."
        }
        Write-Host "$Name is already running and passed its health check." -ForegroundColor Green
        return
    }
    Start-ServiceWindow $Name $BatchFile
    [void](Wait-ForHttp $HealthUrl $Accepted 45 $Name)
    Write-Host "$Name health check passed." -ForegroundColor Green
}

function Get-TailscaleExecutable {
    $command = Get-Command tailscale.exe -CommandType Application -ErrorAction SilentlyContinue
    if (-not $command) { $command = Get-Command tailscale -CommandType Application -ErrorAction SilentlyContinue }
    if ($command) { return $command.Source }
    $knownPath = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
    if (Test-Path -LiteralPath $knownPath) { return $knownPath }
    throw 'Tailscale CLI was not found. Install Tailscale, sign in on this PC, and run START_ALL.bat again.'
}

function Invoke-Tailscale([string[]]$Arguments) {
    $output = @(& $script:tailscaleExe @Arguments 2>&1 | ForEach-Object { [string]$_ })
    $exitCode = $LASTEXITCODE
    return @{ output = $output; exitCode = $exitCode; text = ($output -join "`n") }
}

function Invoke-TailscaleFunnel {
    $stdoutPath = Join-Path $env:TEMP ('rti-funnel-' + [guid]::NewGuid().ToString('N') + '.out')
    $stderrPath = Join-Path $env:TEMP ('rti-funnel-' + [guid]::NewGuid().ToString('N') + '.err')
    $arguments = 'funnel --https=443 --bg http://127.0.0.1:5200'
    $process = $null
    $stdoutIndex = 0
    $stderrIndex = 0
    $approval = ''
    $shown = [System.Collections.Generic.List[string]]::new()

    try {
        Write-Host 'Starting Tailscale Funnel. If this device needs approval, the approval page will open and the link will appear here.' -ForegroundColor Cyan
        $process = Start-Process -FilePath $script:tailscaleExe -ArgumentList $arguments -WorkingDirectory $root -NoNewWindow -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath

        while (-not $process.HasExited) {
            foreach ($path in @($stdoutPath, $stderrPath)) {
                if (-not (Test-Path -LiteralPath $path)) { continue }
                $lines = @(Get-Content -LiteralPath $path -ErrorAction SilentlyContinue)
                if ($path -eq $stdoutPath) {
                    while ($stdoutIndex -lt $lines.Count) {
                        $line = [string]$lines[$stdoutIndex]
                        $stdoutIndex++
                        $shown.Add($line)
                        if ($line.Trim()) { Write-Host $line }
                    }
                } else {
                    while ($stderrIndex -lt $lines.Count) {
                        $line = [string]$lines[$stderrIndex]
                        $stderrIndex++
                        $shown.Add($line)
                        if ($line.Trim()) { Write-Host $line -ForegroundColor Yellow }
                    }
                }
            }

            if (-not $approval) {
                $textSoFar = $shown -join "`n"
                $approvalMatch = [regex]::Match($textSoFar, 'https://login\.tailscale\.com/f/funnel\?[^\s"''<>]+')
                if ($approvalMatch.Success) {
                    $approval = $approvalMatch.Value.TrimEnd('.', ',', ')', ']')
                    Write-Host 'Tailscale Funnel needs one-time approval. Sign in as a tailnet admin and approve this device:' -ForegroundColor Yellow
                    Write-Host $approval -ForegroundColor Cyan
                    Start-Process $approval
                    Write-Host 'This window will continue after Tailscale confirms the approval.' -ForegroundColor Yellow
                }
            }
            Start-Sleep -Milliseconds 300
            $process.Refresh()
        }

        foreach ($path in @($stdoutPath, $stderrPath)) {
            if (-not (Test-Path -LiteralPath $path)) { continue }
            $lines = @(Get-Content -LiteralPath $path -ErrorAction SilentlyContinue)
            if ($path -eq $stdoutPath) {
                while ($stdoutIndex -lt $lines.Count) { $line = [string]$lines[$stdoutIndex]; $stdoutIndex++; $shown.Add($line); if ($line.Trim()) { Write-Host $line } }
            } else {
                while ($stderrIndex -lt $lines.Count) { $line = [string]$lines[$stderrIndex]; $stderrIndex++; $shown.Add($line); if ($line.Trim()) { Write-Host $line -ForegroundColor Yellow } }
            }
        }
        return @{ output = @($shown); exitCode = $process.ExitCode; text = ($shown -join "`n"); approval = $approval }
    } finally {
        if ($process -and -not $process.HasExited) {
            try { Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue } catch { }
        }
        Remove-Item -LiteralPath $stdoutPath, $stderrPath -Force -ErrorAction SilentlyContinue
    }
}

function Enable-ProjectFunnel {
    $result = Invoke-TailscaleFunnel
    if ($result.exitCode -ne 0 -or $result.text -match '(?i)Funnel is not enabled') {
        $approval = [regex]::Match($result.text, 'https://login\.tailscale\.com/f/funnel\?[^\s]+').Value.TrimEnd('.', ',', ')')
        if ($approval) {
            if (-not $result.approval) { Start-Process $approval }
            Write-Host 'Approve Funnel in the browser, then return to this window.' -ForegroundColor Yellow
            [void](Read-Host 'Press Enter after the approval page confirms success')
            $result = Invoke-TailscaleFunnel
        }
    }
    if ($result.exitCode -ne 0) {
        # Tailscale may report a non-zero result after it has already enabled
        # the requested background Funnel. Trust the status only when it
        # confirms the public route is pointed at this app's mobile proxy.
        $status = Invoke-Tailscale @('funnel', 'status')
        $routeReady = $status.exitCode -eq 0 -and
            $status.text -match '(?is)https://[A-Za-z0-9.-]+\.ts\.net.*proxy\s+http://127\.0\.0\.1:5200'
        if ($routeReady) {
            Write-Host 'Tailscale Funnel is active and routing to the mobile API proxy.' -ForegroundColor Green
            return
        }
        throw "Tailscale Funnel did not start:`n$($result.text)`nCheck the tailnet approval and Funnel policy, then run START_ALL.bat again."
    }
}

try {
    Write-Host 'AB Securitas RTI - checking local services and Tailscale...' -ForegroundColor Cyan

    $centralEnvPath = Join-Path $root 'Web\.env'
    $clientEnvPath = Join-Path $root 'ClientPC\.env'
    if (-not (Test-Path $centralEnvPath) -or -not (Test-Path $clientEnvPath)) {
        throw 'Private app settings are missing. START_ALL.bat should run INSTALL_SETUP.bat first; if it did not, run INSTALL_SETUP.bat once.'
    }
    $centralEnv = Read-EnvFile $centralEnvPath
    $clientEnv = Read-EnvFile $clientEnvPath
    $companyId = [string]$clientEnv['RTI_COMPANY_ID']
    $clientId = [string]$clientEnv['RTI_CLIENT_ID']
    $clientToken = [string]$clientEnv['RTI_CLIENT_SYNC_TOKEN']
    $nodeToken = [string]$clientEnv['RTI_CLIENT_NODE_TOKEN']
    if ($companyId -notmatch '^\d+$' -or $clientId -notmatch '^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$' -or -not $clientToken -or $clientToken -eq 'CHANGE-TO-A-LONG-RANDOM-SYNC-TOKEN') {
        throw 'Client PC Company ID, generated Client PC ID, or sync token is missing. Run INSTALL_SETUP.bat and check ClientPC/.env.'
    }
    $centralToken = ''
    foreach ($entry in ([string]$centralEnv['RTI_CLIENT_SYNC_TOKENS']).Split(';')) {
        $separator = $entry.IndexOf(':')
        if ($separator -gt 0 -and $entry.Substring(0, $separator).Trim() -eq $companyId) {
            $centralToken = $entry.Substring($separator + 1).Trim()
        }
    }
    if (-not $centralToken -or $centralToken -ne $clientToken) {
        throw "Client PC sync token does not match company $companyId in Web/.env. Run INSTALL_SETUP.bat or copy the matching company token privately."
    }
    $centralNodeToken = ''
    foreach ($entry in ([string]$centralEnv['RTI_CLIENT_NODE_TOKENS']).Split(';')) {
        $separator = $entry.IndexOf(':')
        if ($separator -gt 0 -and $entry.Substring(0, $separator).Trim() -eq "$companyId/$clientId") {
            $centralNodeToken = $entry.Substring($separator + 1).Trim()
        }
    }
    if (-not $nodeToken -or $nodeToken -eq 'CHANGE-TO-A-LONG-RANDOM-NODE-TOKEN' -or $centralNodeToken -ne $nodeToken) {
        throw "Client PC node token does not match $companyId/$clientId in Web/.env. Run INSTALL_SETUP.bat or copy the matching node token privately."
    }
    Write-Host "Configuration check passed for company $companyId, Client PC $clientId; secret values were not displayed." -ForegroundColor Green

    $script:tailscaleExe = Get-TailscaleExecutable
    $tailscaleStatus = Invoke-Tailscale @('status', '--json')
    if ($tailscaleStatus.exitCode -ne 0) {
        throw "Tailscale is not connected. Open Tailscale, sign in, then run START_ALL.bat again.`n$($tailscaleStatus.text)"
    }
    try { $tailscaleState = $tailscaleStatus.text | ConvertFrom-Json } catch { throw 'Could not read Tailscale status. Update Tailscale and try again.' }
    if ($tailscaleState.BackendState -ne 'Running') {
        throw "Tailscale is not connected (status: $($tailscaleState.BackendState)). Connect it and run START_ALL.bat again."
    }
    Write-Host 'Tailscale connection check passed.' -ForegroundColor Green

    Ensure-Service 'Central server' 5000 'http://127.0.0.1:5000/' @(200, 301, 302, 401) 'START_CENTRAL_SERVER.bat'
    Ensure-Service 'Mobile API proxy' 5200 'http://127.0.0.1:5200/api/mobile/state' @(200, 401) 'START_MOBILE_API_PROXY.bat'

    Enable-ProjectFunnel
    $funnelStatus = Invoke-Tailscale @('funnel', 'status')
    if ($funnelStatus.exitCode -ne 0) { throw "Could not read Tailscale Funnel status:`n$($funnelStatus.text)" }
    $hostnameMatch = [regex]::Match($funnelStatus.text, 'https://(?<host>[A-Za-z0-9][A-Za-z0-9.-]*\.ts\.net)(?::443)?')
    if (-not $hostnameMatch.Success) { throw "Funnel did not report an HTTPS *.ts.net URL:`n$($funnelStatus.text)" }
    $funnelUrl = 'https://' + $hostnameMatch.Groups['host'].Value
    Set-EnvValue $clientEnvPath 'RTI_CENTRAL_FUNNEL_URL' $funnelUrl
    Write-Host "Funnel is live at $funnelUrl" -ForegroundColor Green

    Ensure-Service 'Client PC event monitor' 5100 'http://127.0.0.1:5100/' @(200) 'START_CLIENT_PC.bat'
    Write-Host ''
    Write-Host 'All local services passed their checks.' -ForegroundColor Green
    Write-Host 'Dashboard:     http://127.0.0.1:5000'
    Write-Host 'Client monitor: http://127.0.0.1:5100'
    Write-Host "Mobile API:     $funnelUrl"
    Start-Process 'http://127.0.0.1:5000'
    Start-Process 'http://127.0.0.1:5100'
    Save-RuntimeState
    [void](Read-Host 'Services remain running. Press Enter to close this status window')
    exit 0
} catch {
    Save-RuntimeState
    Write-Host ''
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
