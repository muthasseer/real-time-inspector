$ErrorActionPreference = 'Continue'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$runtimeFile = Join-Path (Join-Path $env:LOCALAPPDATA 'AB Securitas RTI') 'runtime.json'
$tailscaleExe = ''
$tailscale = Get-Command tailscale.exe -CommandType Application -ErrorAction SilentlyContinue
if (-not $tailscale) { $tailscale = Get-Command tailscale -CommandType Application -ErrorAction SilentlyContinue }
if ($tailscale) { $tailscaleExe = $tailscale.Source }
if (-not $tailscaleExe) {
    $knownPath = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
    if (Test-Path -LiteralPath $knownPath) { $tailscaleExe = $knownPath }
}

if ($tailscaleExe) {
    $output = @(& $tailscaleExe funnel --https=443 http://127.0.0.1:5200 off 2>&1 | ForEach-Object { [string]$_ })
    if ($LASTEXITCODE -eq 0) {
        Write-Host 'Tailscale Funnel stopped.' -ForegroundColor Green
    } else {
        Write-Host 'Funnel stop returned a message (it may already be off):'
        $output | ForEach-Object { if ($_.Trim()) { Write-Host $_ } }
    }
} else {
    Write-Host 'Tailscale CLI not found; skipping Funnel stop.' -ForegroundColor Yellow
}

if (Test-Path -LiteralPath $runtimeFile) {
    try {
        $state = Get-Content -LiteralPath $runtimeFile -Raw | ConvertFrom-Json
        foreach ($item in @($state.processes)) {
            $processId = [int]$item.pid
            if ($processId -gt 0 -and $item.batchPath) {
                $processInfo = Get-CimInstance Win32_Process -Filter "ProcessId=$processId" -ErrorAction SilentlyContinue
                $sameLauncher = $processInfo -and $processInfo.Name -ieq 'cmd.exe' -and
                    $processInfo.CommandLine -and
                    $processInfo.CommandLine.IndexOf([string]$item.batchPath, [System.StringComparison]::OrdinalIgnoreCase) -ge 0
                if ($sameLauncher) {
                    & taskkill.exe /PID $processId /T /F | Out-Null
                    Write-Host "Stopped $($item.name)."
                } else {
                    Write-Host "Skipped PID $processId because it no longer matches the recorded launcher." -ForegroundColor Yellow
                }
            }
        }
        Remove-Item -LiteralPath $runtimeFile -Force -ErrorAction SilentlyContinue
    } catch {
        Write-Host "Could not read the saved service list: $($_.Exception.Message)" -ForegroundColor Yellow
    }
} else {
    Write-Host 'No services started by START_ALL.bat were recorded.' -ForegroundColor Yellow
}

Write-Host 'One-click stop complete.' -ForegroundColor Cyan
