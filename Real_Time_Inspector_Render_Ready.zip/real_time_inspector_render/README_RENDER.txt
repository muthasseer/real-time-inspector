REAL TIME INSPECTOR - Render deployment package

Render settings:
Service Type: Web Service
Runtime: Python 3
Build Command: pip install -r requirements.txt
Start Command: gunicorn server.app:app
Plan: Free (for testing only)

After deployment, Render provides an HTTPS public URL such as:
https://real-time-inspector-xxxx.onrender.com

API endpoint:
POST https://YOUR-URL.onrender.com/api/scan

Example JSON:
{"point_id":"P01","inspector_id":"INSPECTOR-01","device_id":"PHONE-01"}

Important: this prototype uses SQLite. Render Free web services have ephemeral local storage, so database data is not suitable for permanent production storage. For production, move the database to PostgreSQL.
