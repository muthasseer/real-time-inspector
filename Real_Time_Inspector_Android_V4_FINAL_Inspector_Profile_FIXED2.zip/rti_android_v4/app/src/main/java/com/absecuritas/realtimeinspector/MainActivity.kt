package com.absecuritas.realtimeinspector

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var lastScan: TextView
    private lateinit var statusText: TextView
    private lateinit var scanHint: TextView
    private lateinit var inspectorInfo: TextView
    private lateinit var profileText: TextView
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val processing = AtomicBoolean(false)
    private var camera: Camera? = null
    private var inspectorName = ""
    private var inspectorId = ""

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else showStatus("CAMERA PERMISSION REQUIRED", false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        lastScan = findViewById(R.id.lastScan)
        statusText = findViewById(R.id.statusText)
        scanHint = findViewById(R.id.scanHint)
        inspectorInfo = findViewById(R.id.inspectorInfo)
        profileText = findViewById(R.id.profileText)
        findViewById<Button>(R.id.changeInspector).setOnClickListener { showInspectorDialog() }

        val prefs = getSharedPreferences("inspector_profile", MODE_PRIVATE)
        inspectorName = prefs.getString("name", "") ?: ""
        inspectorId = prefs.getString("id", "") ?: ""
        if (inspectorName.isBlank() || inspectorId.isBlank()) showInspectorDialog() else updateInspectorUi()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun showInspectorDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(45, 5, 45, 0)
        }
        val name = EditText(this).apply { hint = "Inspector Name"; setText(inspectorName) }
        val id = EditText(this).apply { hint = "Inspector ID"; setText(inspectorId) }
        box.addView(name); box.addView(id)
        AlertDialog.Builder(this)
            .setTitle("Inspector Profile")
            .setMessage("Enter the inspector details used for every QR scan.")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("SAVE") { _, _ ->
                val n = name.text.toString().trim()
                val i = id.text.toString().trim()
                if (n.isBlank() || i.isBlank()) {
                    Toast.makeText(this, "Inspector Name and ID are required", Toast.LENGTH_LONG).show()
                    showInspectorDialog()
                } else {
                    inspectorName = n; inspectorId = i
                    getSharedPreferences("inspector_profile", MODE_PRIVATE).edit()
                        .putString("name", n).putString("id", i).apply()
                    updateInspectorUi()
                }
            }.show()
    }

    private fun updateInspectorUi() {
        inspectorInfo.text = "Inspector: $inspectorName  •  ID: $inspectorId"
        profileText.text = "$inspectorName\nInspector ID: $inspectorId"
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val provider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
            val options = BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            val scanner = BarcodeScanning.getClient(options)
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                val mediaImage = imageProxy.image
                if (mediaImage == null || processing.get()) { imageProxy.close(); return@setAnalyzer }
                val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                scanner.process(image)
                    .addOnSuccessListener { barcodes -> barcodes.firstOrNull()?.rawValue?.trim()?.takeIf { it.isNotBlank() }?.let { handleQr(it) } }
                    .addOnFailureListener { }
                    .addOnCompleteListener { imageProxy.close() }
            }
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            showStatus("READY — SCAN QR", true)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun handleQr(rawValue: String) {
        if (!rawValue.startsWith("RTI-", true) || !processing.compareAndSet(false, true)) return
        mainHandler.post { scanHint.text = "Sending inspection..."; statusText.text = "CONNECTING TO SERVER..." }
        cameraExecutor.execute {
            try {
                val payload = JSONObject().apply {
                    put("qr_token", rawValue)
                    put("inspector_name", inspectorName)
                    put("inspector_employee_id", inspectorId)
                    put("device_id", AppConfig.DEVICE_ID)
                    if (inspectorId.all { it.isDigit() } && inspectorId.isNotBlank()) put("inspector_id", inspectorId.toInt())
                }
                val connection = (URL(AppConfig.SERVER_BASE_URL + AppConfig.SCAN_ENDPOINT).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 8000; readTimeout = 8000; doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8"); setRequestProperty("Accept", "application/json")
                }
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                connection.disconnect()
                mainHandler.post { handleServerResponse(code, body) }
            } catch (_: Exception) {
                mainHandler.post { showStatus("NETWORK ERROR — CHECK 4G/INTERNET", false); scanHint.text = "Move to the next QR"; processing.set(false) }
            }
        }
    }

    private fun handleServerResponse(httpCode: Int, body: String) {
        val json = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
        val result = json.optString("result", json.optString("status", ""))
        val pointName = json.optString("point_name", "Inspection Point")
        lastScan.text = "$pointName — ${now()}"
        when {
            httpCode in 200..299 && result.equals("ACCEPTED", true) -> showStatus("✓ ACCEPTED", true)
            httpCode in 200..299 && result.equals("REPEAT", true) -> showStatus("REPEAT — ALREADY SCANNED TODAY", false)
            httpCode in 200..299 -> showStatus("✓ SCAN SENT", true)
            else -> showStatus("SERVER ERROR ($httpCode)", false)
        }
        scanHint.text = "Ready for next inspection point"
        mainHandler.postDelayed({ processing.set(false) }, 2200)
    }

    private fun showStatus(message: String, success: Boolean) {
        statusText.text = message
        statusText.setTextColor(ContextCompat.getColor(this, if (success) R.color.green else R.color.red))
    }

    private fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }
}
