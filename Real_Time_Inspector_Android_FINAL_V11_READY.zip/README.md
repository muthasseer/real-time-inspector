# AB Securitas Real Time Inspector — Android V6 Final

Flow: Inspector User ID + Password + assigned Device ID → Company authentication → Start Inspection → Camera ON → QR scan → Accepted/Repeat → Scanned/Pending locations.

Device IDs are generated and managed by the Super Admin in the web application. A device can be assigned to multiple inspectors. Inspector credentials are created by Super Admin; mobile login uses those Inspector credentials.

Server: https://muthasseer.pythonanywhere.com
