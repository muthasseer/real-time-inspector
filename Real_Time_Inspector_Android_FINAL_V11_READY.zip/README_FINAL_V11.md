AB Securitas Real Time Inspector Android — FINAL V11

Flow
1. App starts and automatically generates a non-editable Device ID from Android Settings.Secure.ANDROID_ID.
2. Inspector enters User ID and Password only.
3. Login sends the immutable Device ID to the cloud server.
4. If the inspector has no assigned device, the server binds this Device ID automatically.
5. If the Device ID already belongs to the same company, another inspector can use the same phone.
6. Start Inspection must be pressed before the camera starts.
7. QR scan sends the QR token + immutable Device ID + authenticated mobile token.
8. Server validates company, license, device and inspector, then records ACCEPTED or REPEAT.
9. App displays scanned and pending locations.

Build
- GitHub Actions workflow: .github/workflows/build-apk.yml
- Java 17
- Gradle 9.4.1
- Android Gradle Plugin 9.2.0
- APK artifact: Real-Time-Inspector-APK-V11
