"""Safely refresh the matching Central and Client PC sync tokens for saved IDs."""

from datetime import datetime
from pathlib import Path
import shutil
import sys

import configure_sync


ROOT = Path(__file__).resolve().parent.parent
CLIENT_ENV = ROOT / "ClientPC" / ".env"
PRIVATE_BACKUPS = ROOT / "private-config-backups"


def main() -> int:
    if not configure_sync.CENTRAL_ENV.is_file() or not CLIENT_ENV.is_file():
        print("Missing Web/.env or ClientPC/.env. Run this from the installed RTI master folder.", file=sys.stderr)
        return 1
    try:
        _lines, values = configure_sync.read_values(CLIENT_ENV)
    except OSError as exc:
        print(f"Could not read ClientPC/.env: {exc}", file=sys.stderr)
        return 1
    company_id = values.get("RTI_COMPANY_ID", "").strip()
    client_id = values.get("RTI_CLIENT_ID", "").strip()
    if not company_id.isdigit() or not client_id:
        print("Save the numeric Company ID and Client PC ID on Client PC Setup first.", file=sys.stderr)
        return 1

    stamp = datetime.now().strftime("%Y%m%dT%H%M%S.%f")
    try:
        PRIVATE_BACKUPS.mkdir(parents=True, exist_ok=True)
        shutil.copy2(configure_sync.CENTRAL_ENV, PRIVATE_BACKUPS / f"Web.env.{stamp}.bak")
        shutil.copy2(CLIENT_ENV, PRIVATE_BACKUPS / f"ClientPC.env.{stamp}.bak")

        lines, _ = configure_sync.read_values(CLIENT_ENV)
        configure_sync.write_value(CLIENT_ENV, lines, "RTI_CLIENT_SYNC_TOKEN", configure_sync.PLACEHOLDER)
        configure_sync.write_value(CLIENT_ENV, lines, "RTI_CLIENT_NODE_TOKEN", configure_sync.NODE_PLACEHOLDER)
        result = configure_sync.main()
        if result != 0:
            print("Token setup did not complete. The previous .env files are backed up in private-config-backups.", file=sys.stderr)
            return result
    except (OSError, ValueError) as exc:
        print(f"Token setup failed: {exc}. Check private-config-backups for the original configuration.", file=sys.stderr)
        return 1

    print(f"Credentials refreshed for Company {company_id}, Client PC {client_id}. Database and scan records were not changed.")
    print("Restart Central and Client PC services, then use Test Central connection. Secret values were not displayed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
