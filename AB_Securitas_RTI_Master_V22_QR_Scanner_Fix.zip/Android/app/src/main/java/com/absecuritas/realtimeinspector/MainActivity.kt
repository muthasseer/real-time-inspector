package com.absecuritas.realtimeinspector

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Size
import android.util.Base64
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.activity.result.contract.ActivityResultContracts
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var loginPanel: LinearLayout
    private lateinit var startPanel: LinearLayout
    private lateinit var inspectionPanel: View
    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var scanHint: TextView
    private lateinit var lastScan: TextView
    private lateinit var companyText: TextView
    private lateinit var inspectorText: TextView
    private lateinit var deviceText: TextView
    private lateinit var locationSummary: TextView
    private lateinit var locationSummary2: TextView
    private lateinit var inspectorText2: TextView
    private lateinit var userIdInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var deviceIdText: TextView
    private lateinit var locationDetails: TextView
    private lateinit var networkStatus: TextView
    private lateinit var inspectionNetworkStatus: TextView
    private lateinit var scheduleSummary: TextView

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val localStore by lazy { LocalStore(this) }
    private val mainHandler = Handler(Looper.getMainLooper())
    private val connectionStatusInFlight = AtomicBoolean(false)
    private var lastConnectionNotificationKey = ""
    private val connectionStatusPoll = object : Runnable {
        override fun run() {
            refreshConnectionStatus()
            mainHandler.postDelayed(this, 30_000)
        }
    }
    private val processing = AtomicBoolean(false)
    private var camera: Camera? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var mobileToken = ""
    private var companyName = ""
    private var userName = ""
    private var userId = ""
    private var deviceId = ""
    private var inspectionStarted = false
    private var inspectionSessionToken = ""
    private var inspectionSessionId = 0
    private var inspectorRecordId = 0
    private var companyId = 0
    private var offlineSessionKey = ""
    private var offlineMode = false
    private var inspectionType = "MANUAL"
    private var activeScheduleId = 0
    private var activeScheduleName = ""
    private var activeCheckpointIds = JSONArray()
    private var pendingScheduleStartId = 0
    private var pendingScheduleStartName = ""
    private var trustedServerEpoch = 0L
    private var trustedDeviceEpoch = 0L
    private var alertShowing = false
    private var lastScannerHintAt = 0L
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        // Storage permission is only needed on Android 9 and below; gallery saving is skipped if it is denied.
        if (result[Manifest.permission.CAMERA] == true || hasCameraPermission()) startCamera() else showStatus("CAMERA PERMISSION REQUIRED", false)
    }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val settingsLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK) return@registerForActivityResult
        val previousUrl = AppConfig.SERVER_BASE_URL
        AppConfig.load(this)
        result.data?.let { data ->
            val lanUrl = data.getStringExtra(SettingsActivity.EXTRA_LAN_URL).orEmpty()
            val lanToken = data.getStringExtra(SettingsActivity.EXTRA_LAN_TOKEN).orEmpty()
            getSharedPreferences("rti_mobile", MODE_PRIVATE).edit()
                .putString("lan_server_url", lanUrl)
                .putString("lan_api_token", encrypt(lanToken))
                .apply()
        }
        refreshConnectionStatus()
        if (previousUrl != AppConfig.SERVER_BASE_URL) Thread { reconnectWithCachedCredential() }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        bindViews()
        installKeyboardAwareScroll(findViewById(R.id.loginScroll))
        AppConfig.load(this)
        val prefs = getSharedPreferences("rti_mobile", MODE_PRIVATE)
        findViewById<Button>(R.id.domainConfigToggle).apply {
            text = "⚙"
            contentDescription = "Open password-protected settings"
            setOnClickListener { requestSettingsAccess() }
        }
        findViewById<Button>(R.id.connectionSettingsToggle).apply {
            contentDescription = "Open password-protected settings"
            setOnClickListener { requestSettingsAccess() }
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        ensureStatusNotificationChannel()
        ReminderScheduler.restore(this)
        registerNetworkRecovery()
        deviceId = getSharedPreferences("rti_mobile", MODE_PRIVATE).getString("device_id", "") ?: ""
        if (deviceId.isBlank()) {
            val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "DEVICE"
            val normalized = androidId.replace("[^A-Za-z0-9]".toRegex(), "").uppercase(Locale.US).takeLast(16)
            deviceId = "DEV-" + normalized
            getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().putString("device_id", deviceId).apply()
        }
        deviceIdText.text = deviceId
        captureScheduledIntent(intent)
        restoreSession()
    }

    private fun bindViews() {
        loginPanel = findViewById(R.id.loginPanel)
        startPanel = findViewById(R.id.startPanel)
        inspectionPanel = findViewById(R.id.inspectionPanel)
        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        scanHint = findViewById(R.id.scanHint)
        lastScan = findViewById(R.id.lastScan)
        companyText = findViewById(R.id.companyText)
        inspectorText = findViewById(R.id.inspectorText)
        deviceText = findViewById(R.id.deviceText)
        locationSummary = findViewById(R.id.locationSummary)
        locationSummary2 = findViewById(R.id.locationSummary2)
        inspectorText2 = findViewById(R.id.inspectorText2)
        userIdInput = findViewById(R.id.userIdInput)
        passwordInput = findViewById(R.id.passwordInput)
        deviceIdText = findViewById(R.id.deviceIdText)
        locationDetails = findViewById(R.id.locationDetails)
        networkStatus = findViewById(R.id.networkStatus)
        inspectionNetworkStatus = findViewById(R.id.inspectionNetworkStatus)
        scheduleSummary = findViewById(R.id.scheduleSummary)
        findViewById<Button>(R.id.loginButton).setOnClickListener { login() }
        findViewById<Button>(R.id.startInspectionButton).setOnClickListener { startInspection() }
        findViewById<Button>(R.id.stopInspectionButton).setOnClickListener { stopInspection() }
        findViewById<Button>(R.id.switchInspectorButton).setOnClickListener { switchInspector() }
        userIdInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) { passwordInput.requestFocus(); true } else false
        }
        passwordInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { login(); true } else false
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureScheduledIntent(intent)
    }

    private fun captureScheduledIntent(intent: android.content.Intent?) {
        if (intent?.getBooleanExtra("start_scheduled_inspection", false) != true) return
        pendingScheduleStartId = intent.getIntExtra("schedule_id", 0)
        pendingScheduleStartName = intent.getStringExtra("schedule_name").orEmpty()
        if (pendingScheduleStartId > 0 && (mobileToken.isNotBlank() || offlineMode)) {
            val id=pendingScheduleStartId; val name=pendingScheduleStartName
            pendingScheduleStartId=0; pendingScheduleStartName=""
            startInspection("SCHEDULED", id, name)
        }
    }

    private fun requestSettingsAccess() {
        val pin = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Settings password"
            filters = arrayOf(android.text.InputFilter.LengthFilter(8))
            setPadding(36, 24, 36, 24)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Unlock Settings")
            .setMessage("Enter the settings password to continue.")
            .setView(pin)
            .setPositiveButton("Unlock", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (!SettingsPin.verify(this, pin.text.toString())) {
                    pin.error = "Incorrect password"
                    pin.selectAll()
                    return@setOnClickListener
                }
                val prefs = getSharedPreferences("rti_mobile", MODE_PRIVATE)
                val intent = Intent(this, SettingsActivity::class.java).apply {
                    putExtra(SettingsActivity.EXTRA_CENTRAL_URL, AppConfig.SERVER_BASE_URL)
                    putExtra(SettingsActivity.EXTRA_LAN_URL, prefs.getString("lan_server_url", "").orEmpty())
                    putExtra(SettingsActivity.EXTRA_LAN_TOKEN, decrypt(prefs.getString("lan_api_token", "").orEmpty()))
                    putExtra(SettingsActivity.EXTRA_CAN_CHANGE_PIN, mobileToken.isNotBlank() && !offlineMode)
                }
                dialog.dismiss()
                settingsLauncher.launch(intent)
            }
        }
        dialog.show()
    }

    /** Keep focused connection fields visible while Android resizes the screen for its keyboard. */
    private fun installKeyboardAwareScroll(scroll: ScrollView) {
        val baseBottom = scroll.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { view, insets ->
            val imeBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val systemBottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            view.setPadding(view.paddingLeft, view.paddingTop, view.paddingRight, baseBottom + maxOf(imeBottom, systemBottom))
            insets
        }
        ViewCompat.requestApplyInsets(scroll)

        fun bindFocus(view: View) {
            if (view is EditText) {
                view.setOnFocusChangeListener { focused, hasFocus ->
                    if (hasFocus) scroll.postDelayed({
                        val rect = Rect(0, 0, focused.width, focused.height)
                        scroll.offsetDescendantRectToMyCoords(focused, rect)
                        val bottom = scroll.height - scroll.paddingBottom
                        if (rect.bottom > bottom) scroll.smoothScrollBy(0, rect.bottom - bottom + 24)
                    }, 220)
                }
            } else if (view is ViewGroup) {
                for (index in 0 until view.childCount) bindFocus(view.getChildAt(index))
            }
        }
        bindFocus(scroll)
    }

    private fun restoreSession() {
        val prefs = getSharedPreferences("rti_mobile", MODE_PRIVATE)
        if (AppConfig.SERVER_BASE_URL.isBlank()) {
            // Keep any cached token/profile and offline queue intact; let the user configure the URL.
            mobileToken = ""
            showLogin()
            return
        }
        mobileToken = prefs.getString("token", "") ?: ""
        if (mobileToken.isBlank()) {
            showLogin()
            return
        }
        Thread {
            try {
                val code = stateRequest()
                if (code.first in 200..299) {
                    val json = JSONObject(code.second)
                    applySession(json)
                    inspectionSessionToken = json.optString("inspection_session_token", "")
                    inspectionSessionId = json.optInt("inspection_session_id", 0)
                    val active = json.optBoolean("inspection_active", false)
                    if (active) {
                        offlineSessionKey=inspectionSessionToken
                        inspectionType=json.optString("inspection_type","MANUAL")
                        activeScheduleId=json.optInt("schedule_id",0)
                        activeScheduleName=json.optString("schedule_name","")
                        activeCheckpointIds=json.optJSONArray("checkpoint_ids") ?: JSONArray()
                    }
                    mainHandler.post {
                        if (active && inspectionSessionToken.isNotBlank()) { showInspection(); ensureCamera() } else showStart()
                        startPendingScheduledInspection()
                    }
                } else if (isNetworkUnavailableStatus(code.first)) {
                    mainHandler.post {
                        if (restoreCachedProfile()) {
                            mobileToken = ""
                            getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().remove("token").apply()
                            offlineMode = true
                            showStart(); startPendingScheduledInspection()
                        } else showLogin()
                    }
                } else mainHandler.post { showLogin() }
            } catch (_: Exception) {
                mainHandler.post {
                    if (restoreCachedProfile()) {
                        mobileToken = ""
                        getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().remove("token").apply()
                        offlineMode = true
                        networkStatus.text = "OFFLINE · Cached checkpoints and secure login ready"
                        showStart()
                        startPendingScheduledInspection()
                    } else showLogin()
                }
            }
        }.start()
    }

    private fun login() {
        val uid = userIdInput.text.toString().trim()
        val pw = passwordInput.text.toString()
        val did = deviceId
        if (uid.isBlank() || pw.isBlank() || did.isBlank()) {
            Toast.makeText(this, "User ID and Password are required", Toast.LENGTH_LONG).show()
            return
        }
        val normalizedServerUrl = AppConfig.normalizeServerUrl(AppConfig.SERVER_BASE_URL)
        if (normalizedServerUrl == null) {
            showLoginStatus("Company server is not configured. Open Settings ⚙ and enter the company domain.", false)
            return
        }
        AppConfig.saveServerBaseUrl(this, normalizedServerUrl)
        hideKeyboard()
        showLoginStatus("CONNECTING TO COMPANY...", true)
        Thread {
            try {
                val payload = JSONObject().apply { put("device_id", did); put("user_id", uid); put("password", pw) }
                val result = postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/login", payload, null)
                if (result.first in 200..299) {
                    val json = JSONObject(result.second)
                    mobileToken = json.optString("mobile_token")
                    companyName = json.optString("company_name")
                    userName = json.optString("user_name")
                    userId = json.optString("inspector_id", uid)
                    deviceId = json.optString("device_id", did)
                    getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().putString("token", mobileToken).putString("device_id", deviceId).apply()
                    cacheCredential(uid, pw, json)
                    offlineMode = false
                    inspectorRecordId = json.optInt("inspector_record_id", inspectorRecordId)
                    companyId = json.optInt("company_id", companyId)
                    mainHandler.post { showStart(); startPendingScheduledInspection() }
                } else {
                    val msg = try { JSONObject(result.second).optString("message", "Login failed") } catch (_: Exception) { "Login failed" }
                    if (isNetworkUnavailableStatus(result.first)) {
                        mainHandler.post {
                            if (offlineLogin(uid, pw)) {
                                mobileToken = ""
                                getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().remove("token").apply()
                                offlineMode = true
                                showLoginStatus("OFFLINE LOGIN · Using your last trusted checkpoint download", true)
                                networkStatus.text = if (clockDriftWarning()) "CLOCK WARNING · Device time differs from trusted server time; offline record times are device-reported"
                                    else "OFFLINE · Records will sync when Internet or LAN returns"
                                showStart(); startPendingScheduledInspection()
                            } else showLoginStatus(msg, false)
                        }
                    } else mainHandler.post { showLoginStatus(msg, false) }
                }
            } catch (_: Exception) {
                mainHandler.post {
                    if (offlineLogin(uid, pw)) {
                        mobileToken = ""
                        getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().remove("token").apply()
                        offlineMode = true
                        showLoginStatus("OFFLINE LOGIN · Using your last trusted checkpoint download", true)
                        networkStatus.text = if (clockDriftWarning()) "CLOCK WARNING · Device time differs from trusted server time; offline record times are device-reported"
                            else "OFFLINE · Records will sync when Internet or LAN returns"
                        showStart(); startPendingScheduledInspection()
                    } else showLoginStatus(
                        "Cannot reach the company server. Check Funnel URL ${AppConfig.SERVER_BASE_URL} and make sure the server PC is online, then retry.",
                        false
                    )
                }
            }
        }.start()
    }

    private fun showLogin() {
        loginPanel.visibility = View.VISIBLE
        startPanel.visibility = View.GONE
        inspectionPanel.visibility = View.GONE
    }

    private fun isNetworkUnavailableStatus(code: Int): Boolean = code in setOf(408, 500, 502, 503, 504)

    private fun showStart() {
        inspectionStarted = false
        inspectionPanel.visibility = View.GONE
        loginPanel.visibility = View.GONE
        startPanel.visibility = View.VISIBLE
        companyText.text = companyName.ifBlank { "Company" }
        inspectorText.text = "Inspector / User: $userName  •  ID: $userId"
        deviceText.text = "Device ID: $deviceId"
        findViewById<TextView>(R.id.startStatus).text =
            if (offlineMode) "Offline mode is ready. Inspections are saved on this device and will sync later."
            else "Ready. Press Start Inspection when you reach the inspection area."
        refreshLocations()
    }

    private fun startPendingScheduledInspection() {
        if (pendingScheduleStartId <= 0) return
        val id=pendingScheduleStartId; val name=pendingScheduleStartName
        pendingScheduleStartId=0; pendingScheduleStartName=""
        startInspection("SCHEDULED",id,name)
    }

    private fun startInspection(type: String = "MANUAL", scheduleId: Int = 0, scheduleName: String = "") {
        if (mobileToken.isBlank()) {
            startOfflineInspection(type, scheduleId, scheduleName)
            return
        }
        findViewById<Button>(R.id.startInspectionButton).isEnabled = false
        Thread {
            try {
                val startPayload=JSONObject().put("inspection_type",type).apply { if(scheduleId>0) put("schedule_id",scheduleId) }
                val result = postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/start-inspection", startPayload, mobileToken)
                if (result.first in 200..299) {
                    val json = JSONObject(result.second)
                    inspectionSessionToken = json.optString("inspection_session_token")
                    inspectionSessionId = json.optInt("inspection_session_id", 0)
                    offlineSessionKey = inspectionSessionToken
                    inspectionType = json.optString("inspection_type",type)
                    activeScheduleId = json.optInt("schedule_id",scheduleId)
                    activeScheduleName = json.optString("schedule_name",scheduleName)
                    activeCheckpointIds = json.optJSONArray("checkpoint_ids") ?: JSONArray()
                    inspectionStarted = true
                    offlineMode = false
                    mainHandler.post {
                        findViewById<Button>(R.id.startInspectionButton).isEnabled = true
                        networkStatus.text = "ONLINE · Internet is the primary sync route"
                        showInspection()
                        ensureCamera()
                        refreshLocations()
                    }
                } else {
                    val msg = try { JSONObject(result.second).optString("message", "Unable to start inspection") } catch (_: Exception) { "Unable to start inspection" }
                    mainHandler.post {
                        findViewById<Button>(R.id.startInspectionButton).isEnabled = true
                        if (isNetworkUnavailableStatus(result.first)) {
                            mobileToken = ""
                            getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().remove("token").apply()
                            startOfflineInspection(type,scheduleId,scheduleName)
                        } else Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    }
                }
            } catch (_: Exception) {
                mainHandler.post {
                    findViewById<Button>(R.id.startInspectionButton).isEnabled = true
                    startOfflineInspection(type,scheduleId,scheduleName)
                }
            }
        }.start()
    }

    private fun startOfflineInspection(type: String = "MANUAL", scheduleId: Int = 0, scheduleName: String = "") {
        offlineSessionKey = "OFF-" + UUID.randomUUID().toString()
        inspectionSessionToken = ""
        inspectionSessionId = 0
        inspectionType = type
        activeScheduleId = scheduleId
        activeScheduleName = scheduleName
        activeCheckpointIds = JSONArray()
        if (type == "SCHEDULED" && scheduleId > 0) {
            val schedules=try { JSONArray(getSharedPreferences("rti_mobile", MODE_PRIVATE).getString("cached_schedules", "[]")) } catch (_:Exception) { JSONArray() }
            for(index in 0 until schedules.length()) {
                val item=schedules.optJSONObject(index) ?: continue
                if(item.optInt("id") == scheduleId) {
                    activeScheduleName=item.optString("name",scheduleName)
                    activeCheckpointIds=item.optJSONArray("checkpoint_ids") ?: JSONArray()
                    break
                }
            }
        }
        inspectionStarted = true
        offlineMode = true
        networkStatus.text = "OFFLINE SESSION · Local queue active"
        showInspection()
        ensureCamera()
    }

    private fun showInspection() {
        inspectionStarted = true
        loginPanel.visibility = View.GONE
        startPanel.visibility = View.GONE
        inspectionPanel.visibility = View.VISIBLE
        previewView.visibility = View.VISIBLE
        inspectorText2.text = "Inspector: $userName  •  ID: $userId\nDevice: $deviceId"
        scanHint.text = if(inspectionType=="SCHEDULED") "Scheduled inspection: $activeScheduleName" else "Align the QR code inside the scan box"
        showStatus("READY — SCAN QR", true)
        refreshLocations()
    }

    private fun switchInspector() {
        stopCamera()
        val token = mobileToken
        mobileToken = ""
        inspectionStarted = false
        inspectionSessionToken = ""
        inspectionSessionId = 0
        getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().remove("token").apply()
        if (token.isNotBlank()) Thread { try { postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/logout", JSONObject(), token) } catch (_: Exception) {} }.start()
        showLogin()
    }

    private fun stopInspection(manual: Boolean = true) {
        val token = mobileToken
        val session = inspectionSessionToken
        inspectionStarted = false
        inspectionSessionToken = ""
        inspectionSessionId = 0
        offlineSessionKey = ""
        inspectionType = "MANUAL"
        activeScheduleId = 0
        activeScheduleName = ""
        activeCheckpointIds = JSONArray()
        stopCamera()
        previewView.visibility = View.GONE
        inspectionPanel.visibility = View.GONE
        if (manual && token.isNotBlank() && session.isNotBlank()) {
            Thread {
                try {
                    val r = postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/end-inspection", JSONObject().apply { put("inspection_session_token", session) }, token)
                    if (r.first in 200..299) mainHandler.post { showUploadedPopup("✓ Inspection Ended", "Inspection data uploaded successfully.") }
                    else mainHandler.post { Toast.makeText(this, "Could not confirm upload. Check internet.", Toast.LENGTH_LONG).show() }
                } catch (_: Exception) { mainHandler.post { Toast.makeText(this, "Could not confirm upload. Check internet.", Toast.LENGTH_LONG).show() } }
            }.start()
        }
        showStart()
    }

    private fun refreshLocations() {
        if (mobileToken.isBlank()) {
            renderCachedLocations()
            return
        }
        Thread {
            try {
                val r = stateRequest()
                if (r.first !in 200..299) {
                    if (r.first == 401) mainHandler.post { sessionExpired() }
                    else mainHandler.post {
                        if (isNetworkUnavailableStatus(r.first)) {
                            mobileToken = ""
                            getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().remove("token").apply()
                            offlineMode = true
                            networkStatus.text = "OFFLINE · Saved records are queued for Internet or LAN"
                        }
                        renderCachedLocations()
                    }
                    return@Thread
                }
                val json = JSONObject(r.second)
                applySession(json)
                val active = json.optBoolean("inspection_active", false)
                val token = json.optString("inspection_session_token", "")
                val sid = json.optInt("inspection_session_id", 0)
                if (active && token.isNotBlank()) {
                    inspectionSessionToken = token; inspectionSessionId = sid; offlineSessionKey=token
                    inspectionType=json.optString("inspection_type","MANUAL")
                    activeScheduleId=json.optInt("schedule_id",0)
                    activeScheduleName=json.optString("schedule_name","")
                    activeCheckpointIds=json.optJSONArray("checkpoint_ids") ?: JSONArray()
                }
                val scanned = json.optInt("scanned_points", 0)
                val pending = json.optInt("pending_points", 0)
                val total = json.optInt("total_points", 0)
                val summary = "TOTAL POINTS: $total    •    SCANNED: $scanned    •    PENDING: $pending"
                val arr = json.optJSONArray("locations")
                val scannedNames = StringBuilder(); val pendingNames = StringBuilder()
                if (arr != null) for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    val label = item.optString("point_code") + " - " + item.optString("name")
                    if (item.optInt("scanned") == 1) { if (scannedNames.isNotEmpty()) scannedNames.append("\n"); scannedNames.append("✓ ").append(label) }
                    else { if (pendingNames.isNotEmpty()) pendingNames.append("\n"); pendingNames.append("• ").append(label) }
                }
                val details = StringBuilder()
                if (pendingNames.isNotEmpty()) details.append("PENDING\n").append(pendingNames)
                if (scannedNames.isNotEmpty()) {
                    if (details.isNotEmpty()) details.append("\n\n")
                    details.append("SCANNED\n").append(scannedNames)
                }
                val detailsText = details.toString()
                mainHandler.post {
                    locationSummary.text = summary
                    locationSummary2.text = summary
                    locationDetails.text = detailsText
                    val prefs=getSharedPreferences("rti_mobile", MODE_PRIVATE)
                    val scheduleNotice=prefs.getBoolean("schedule_sync_complete_pending",false)
                    if(scheduleNotice) prefs.edit().putBoolean("schedule_sync_complete_pending",false).apply()
                    networkStatus.text = if(scheduleNotice) "ONLINE · Schedule updated · Sync complete" else "ONLINE · Internet is the primary sync route"
                    renderScheduleSummary(json.optJSONArray("schedules") ?: JSONArray(),scheduleNotice)
                    if (inspectionStarted && json.optBoolean("inspection_complete", false)) completeInspection()
                }
                syncPendingEvents()
            } catch (_: Exception) {
                mainHandler.post {
                    offlineMode = true
                    networkStatus.text = "OFFLINE · Saved records are queued for Internet or LAN"
                    renderCachedLocations()
                }
            }
        }.start()
    }

    private fun applySession(json: JSONObject) {
        companyName = json.optString("company_name", companyName)
        userName = json.optString("inspector_name", json.optString("user_name", userName))
        userId = json.optString("inspector_id", json.optString("user_id", userId))
        inspectorRecordId = json.optInt("inspector_record_id", inspectorRecordId)
        companyId = json.optInt("company_id", companyId)
    }

    private fun cacheCredential(username: String, password: String, json: JSONObject) {
        val prefs = getSharedPreferences("rti_mobile", MODE_PRIVATE)
        prefs.edit()
            .putString("cached_login_user", username)
            .putString("cached_login_password", encrypt(password))
            .putString("cached_company_name", json.optString("company_name", companyName))
            .putString("cached_user_name", json.optString("user_name", userName))
            .putString("cached_user_id", json.optString("inspector_id", userId))
            .putInt("cached_company_id", json.optInt("company_id", companyId))
            .putInt("cached_inspector_record_id", json.optInt("inspector_record_id", inspectorRecordId))
            .putString("cached_device_id", json.optString("device_id", deviceId))
            .apply()
    }

    private fun offlineLogin(username: String, password: String): Boolean {
        val prefs = getSharedPreferences("rti_mobile", MODE_PRIVATE)
        val cachedUser = prefs.getString("cached_login_user", "").orEmpty()
        val cachedPassword = decrypt(prefs.getString("cached_login_password", "").orEmpty())
        if (!cachedUser.equals(username, ignoreCase = true) || cachedPassword.isBlank() || cachedPassword != password) return false
        return restoreCachedProfile()
    }

    private fun restoreCachedProfile(): Boolean {
        val prefs = getSharedPreferences("rti_mobile", MODE_PRIVATE)
        if (prefs.getString("cached_state", null).isNullOrBlank() ||
            prefs.getString("cached_login_user", null).isNullOrBlank() ||
            prefs.getString("cached_login_password", null).isNullOrBlank()) return false
        companyName = prefs.getString("cached_company_name", "Company").orEmpty()
        userName = prefs.getString("cached_user_name", "Inspector").orEmpty()
        userId = prefs.getString("cached_user_id", "").orEmpty()
        companyId = prefs.getInt("cached_company_id", 0)
        inspectorRecordId = prefs.getInt("cached_inspector_record_id", 0)
        deviceId = prefs.getString("cached_device_id", deviceId).orEmpty()
        val drift = clockDriftWarning()
        networkStatus.text = if (drift) "CLOCK WARNING · Device time differs from the last trusted server time" else "OFFLINE · Cached checkpoints and secure login ready"
        return companyId > 0 && inspectorRecordId > 0 && localStore.readableDatabase.rawQuery("SELECT 1 FROM checkpoints LIMIT 1", null).use { it.moveToFirst() }
    }

    private fun cacheServerTime(value: String) {
        val epoch = try {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                isLenient = false
                timeZone = TimeZone.getTimeZone("UTC")
            }.parse(value)?.time ?: return
        } catch (_: Exception) { return }
        getSharedPreferences("rti_mobile", MODE_PRIVATE).edit()
            .putLong("trusted_server_epoch", epoch)
            .putLong("trusted_device_epoch", System.currentTimeMillis())
            .putLong("trusted_elapsed_realtime", SystemClock.elapsedRealtime())
            .apply()
        trustedServerEpoch = epoch
        trustedDeviceEpoch = System.currentTimeMillis()
    }

    private fun clockDriftWarning(): Boolean {
        val prefs = getSharedPreferences("rti_mobile", MODE_PRIVATE)
        val server = prefs.getLong("trusted_server_epoch", 0L)
        val device = prefs.getLong("trusted_device_epoch", 0L)
        val elapsed = prefs.getLong("trusted_elapsed_realtime", 0L)
        if (server <= 0L || device <= 0L) return false
        val elapsedNow = SystemClock.elapsedRealtime()
        val expected = if (elapsedNow >= elapsed) server + (elapsedNow - elapsed) else server + (System.currentTimeMillis() - device)
        return kotlin.math.abs(System.currentTimeMillis() - expected) > 5 * 60 * 1000
    }

    private fun encrypt(plainText: String): String {
        if (plainText.isEmpty()) return ""
        return try {
            val alias = "ab_securitas_rti_cache"
            val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val key = if (store.containsAlias(alias)) {
                store.getKey(alias, null) as SecretKey
            } else {
                KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").run {
                    init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setRandomizedEncryptionRequired(true)
                        .build())
                    generateKey()
                }
            }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
        } catch (_: Exception) {
            ""
        }
    }

    private fun decrypt(value: String): String {
        if (value.isBlank()) return ""
        return try {
            val raw = Base64.decode(value, Base64.NO_WRAP)
            val iv = raw.copyOfRange(0, 12)
            val encrypted = raw.copyOfRange(12, raw.size)
            val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val key = store.getKey("ab_securitas_rti_cache", null) as SecretKey
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, javax.crypto.spec.GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }

    private fun cacheScheduleSummary(schedules: JSONArray) {
        getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().putString("cached_schedules", schedules.toString()).apply()
    }

    private fun renderScheduleSummary(schedules: JSONArray, syncComplete: Boolean = false) {
        if (schedules.length() == 0) {
            scheduleSummary.text = "No inspection reminders are currently assigned." + if(syncComplete) "\n✓ Schedule update sync complete" else ""
            return
        }
        val text = StringBuilder("UPCOMING INSPECTIONS\n")
        for (index in 0 until minOf(3, schedules.length())) {
            val schedule = schedules.optJSONObject(index) ?: continue
            val days = schedule.optJSONArray("days")?.let { array ->
                (0 until array.length()).joinToString(", ") { array.optString(it) }
            }.orEmpty()
            text.append("• ").append(schedule.optString("schedule_time")).append(" · ")
                .append(schedule.optString("name")).append(if (days.isNotBlank()) " ($days)" else "").append('\n')
        }
        if(syncComplete) text.append("\n✓ Schedule updated · Sync complete")
        scheduleSummary.text = text.toString().trim()
    }

    private fun reconnectWithCachedCredential() {
        val prefs = getSharedPreferences("rti_mobile", MODE_PRIVATE)
        val username = prefs.getString("cached_login_user", "").orEmpty()
        val password = decrypt(prefs.getString("cached_login_password", "").orEmpty())
        if (username.isBlank() || password.isBlank()) return
        try {
            val result = postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/login",
                JSONObject().put("device_id", deviceId).put("user_id", username).put("password", password), null)
            if (result.first !in 200..299) return
            val json = JSONObject(result.second)
            mobileToken = json.optString("mobile_token")
            inspectorRecordId = json.optInt("inspector_record_id", inspectorRecordId)
            companyId = json.optInt("company_id", companyId)
            userName = json.optString("user_name", userName)
            userId = json.optString("inspector_id", userId)
            companyName = json.optString("company_name", companyName)
            getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().putString("token", mobileToken).apply()
            cacheCredential(username, password, json)
            stateRequest()
            syncPendingEvents()
            offlineMode = false
            mainHandler.post { networkStatus.text = "ONLINE · Offline records are synchronizing"; startPendingScheduledInspection() }
            refreshLocations()
        } catch (_: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        if (!::networkStatus.isInitialized) return
        if (mobileToken.isBlank()) Thread { reconnectWithCachedCredential() }.start()
        else refreshLocations()
        mainHandler.removeCallbacks(connectionStatusPoll)
        refreshConnectionStatus()
        mainHandler.postDelayed(connectionStatusPoll, 30_000)
    }

    override fun onPause() {
        mainHandler.removeCallbacks(connectionStatusPoll)
        super.onPause()
    }

    private fun registerNetworkRecovery() {
        val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                refreshConnectionStatus()
                mainHandler.postDelayed({
                    Thread {
                        if (mobileToken.isBlank()) reconnectWithCachedCredential()
                        else refreshLocations()
                    }.start()
                }, 1500)
            }

            override fun onLost(network: Network) {
                refreshConnectionStatus()
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: android.net.NetworkCapabilities) {
                refreshConnectionStatus()
            }
        }
        networkCallback = callback
        try {
            val request = NetworkRequest.Builder().addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
            if (Build.VERSION.SDK_INT >= 24) manager.registerDefaultNetworkCallback(callback)
            else manager.registerNetworkCallback(request, callback)
        } catch (_: Exception) {
        }
    }

    private fun hasValidatedInternet(): Boolean {
        return try {
            val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val active = manager.activeNetwork ?: return false
            val capabilities = manager.getNetworkCapabilities(active) ?: return false
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Exception) {
            false
        }
    }

    private fun refreshConnectionStatus() {
        if (!::networkStatus.isInitialized || !connectionStatusInFlight.compareAndSet(false, true)) return
        val internetOnline = hasValidatedInternet()
        val centralUrl = AppConfig.SERVER_BASE_URL
        val centralToken = mobileToken
        val prefs = getSharedPreferences("rti_mobile", MODE_PRIVATE)
        val lanUrl = prefs.getString("lan_server_url", "").orEmpty().trimEnd('/')
        val lanToken = decrypt(prefs.getString("lan_api_token", "").orEmpty())
        val pending = runCatching { localStore.pendingEvents().length() }.getOrDefault(0)
        Thread {
            var centralState = "NOT CONFIGURED"
            var lanState = "NOT CONFIGURED"
            var centralSyncState = "NOT REPORTED"
            var centralAuthHint = ""
            var queueCount = pending
            if (centralUrl.isNotBlank()) {
                try {
                    val response = getJson(centralUrl + "/api/mobile/state", centralToken)
                    centralState = when {
                        response.first in 200..299 -> "ONLINE"
                        response.first == 401 && centralToken.isBlank() -> "REACHABLE · LOGIN REQUIRED"
                        response.first == 401 -> "REACHABLE · LOGIN EXPIRED"
                        response.first == 403 -> "REACHABLE · ACCESS DENIED"
                        response.first == 502 || response.first == 503 || response.first == 504 -> "UNAVAILABLE · HTTP ${response.first}"
                        else -> "SERVER ERROR · HTTP ${response.first}"
                    }
                } catch (_: Exception) {
                    centralState = "UNREACHABLE"
                }
            }
            if (lanUrl.isNotBlank() && lanToken.isNotBlank()) {
                try {
                    val response = getJson(lanUrl + "/api/mobile/health", lanToken)
                    val data = runCatching { JSONObject(response.second) }.getOrDefault(JSONObject())
                    val clientCompanyId = data.optInt("company_id", 0)
                    val companyMismatch = companyId > 0 && clientCompanyId > 0 && companyId != clientCompanyId
                    lanState = when {
                        response.first in 200..299 && data.optBoolean("ok") && companyMismatch -> "COMPANY ID MISMATCH · PC $clientCompanyId / APP $companyId"
                        response.first in 200..299 && data.optBoolean("ok") -> "ONLINE · ${data.optString("client_id", "Client PC")}"
                        response.first == 401 -> "AUTH FAILED · CHECK PASSKEY"
                        else -> "UNAVAILABLE · HTTP ${response.first}"
                    }
                    if (response.first in 200..299) {
                        queueCount += data.optInt("pending_events", 0)
                        centralSyncState = when {
                            companyMismatch -> "LAN COMPANY ID MISMATCH"
                            data.optBoolean("central_authenticated") -> "SYNC OK"
                            data.optBoolean("central_reachable") && data.optString("central_last_error").contains("401") -> "AUTH FAILED · HTTP 401"
                            data.optBoolean("central_reachable") -> "CENTRAL REACHED · CHECK CLIENT TOKENS/PERMISSION"
                            data.optString("central_last_error").isNotBlank() -> "WAITING · ${data.optString("central_last_error")}"
                            else -> "WAITING FOR FIRST CENTRAL SYNC"
                        }
                        if (data.optString("central_last_error").isNotBlank()) centralAuthHint = data.optString("central_last_error")
                    }
                } catch (_: Exception) {
                    lanState = "UNREACHABLE · CHECK WI-FI/IP/FIREWALL"
                }
            }
            val internetState = if (internetOnline) "ONLINE" else "OFFLINE"
            val fullStatus = "INTERNET: $internetState\nCENTRAL SERVER: $centralState\nCLIENT PC / LAN: $lanState · CENTRAL SYNC: $centralSyncState · QUEUED: $queueCount"
            val scanStatus = "INTERNET: $internetState · CENTRAL: $centralState\nCLIENT PC / LAN: $lanState · SYNC: $centralSyncState · QUEUED: $queueCount"
            val notificationKey = "$internetState|$centralState|$lanState|$centralSyncState"
            mainHandler.post {
                networkStatus.text = fullStatus
                inspectionNetworkStatus.text = scanStatus
                notifyConnectionStatusChange(notificationKey, fullStatus)
                networkStatus.contentDescription = fullStatus
                if (centralAuthHint.isNotBlank() && centralAuthHint.contains("HTTP 401")) {
                    networkStatus.contentDescription = "$fullStatus. Central rejected credentials. Check Company ID, Client PC ID, and matching private tokens in Central and Client PC configuration."
                }
                connectionStatusInFlight.set(false)
            }
        }.start()
    }

    private fun ensureStatusNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel("rti_connection_status", "RTI connection status", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notifyConnectionStatusChange(key: String, message: String) {
        val previous = lastConnectionNotificationKey
        lastConnectionNotificationKey = key
        if (previous.isBlank() || previous == key) return
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = NotificationCompat.Builder(this, "rti_connection_status")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("AB Securitas · Connection status changed")
            .setContentText(message.replace('\n', ' '))
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .build()
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(7301, notification)
    }

    private fun stateRequest(): Pair<Int, String> {
        val response = getJson(AppConfig.SERVER_BASE_URL + "/api/mobile/state", mobileToken)
        if (response.first in 200..299) {
            val json = JSONObject(response.second)
            json.optJSONArray("locations")?.let { localStore.cacheCheckpoints(it) }
            val prefs=getSharedPreferences("rti_mobile", MODE_PRIVATE)
            json.optJSONArray("schedules")?.let { schedules ->
                val previous=prefs.getString("cached_schedules","").orEmpty()
                val updated=previous.isNotBlank() && runCatching { JSONArray(previous).toString()!=schedules.toString() }.getOrDefault(true)
                ReminderScheduler.update(this,schedules)
                cacheScheduleSummary(schedules)
                if(updated) prefs.edit().putBoolean("schedule_sync_complete_pending",true).apply()
            }
            prefs.edit().putInt("scan_gap_seconds",json.optInt("scan_gap_seconds",8).coerceIn(0,300)).apply()
            cacheServerTime(json.optString("server_time_utc"))
            getSharedPreferences("rti_mobile", MODE_PRIVATE).edit()
                .putString("cached_state", json.toString())
                .putString("cached_company_name", json.optString("company_name", companyName))
                .putString("cached_user_name", json.optString("inspector_name", userName))
                .putString("cached_user_id", json.optString("inspector_id", userId))
                .putInt("cached_company_id", json.optInt("company_id", companyId))
                .putInt("cached_inspector_record_id", json.optInt("inspector_record_id", inspectorRecordId))
                .putString("cached_device_id", json.optString("device_id", deviceId))
                .apply()
        }
        return response
    }

    private fun hasCameraPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun needsLegacyStoragePermission() = Build.VERSION.SDK_INT < 29 &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED

    private fun ensureCamera() {
        val needed = ArrayList<String>()
        if (!hasCameraPermission()) needed.add(Manifest.permission.CAMERA)
        if (needsLegacyStoragePermission()) needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (needed.isEmpty()) startCamera() else cameraPermission.launch(needed.toTypedArray())
    }

    private fun stopCamera() {
        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        camera = null
    }

    /** Barcode bounds are checked against the actual square bitmap sent to ML Kit. */
    private fun detectedBarcodeBounds(barcode: Barcode): Rect? {
        barcode.boundingBox?.let { return Rect(it) }
        return null
    }

    /** Convert the exact CameraX viewport crop to the upright square ML Kit will scan. */
    private fun createScanBitmap(imageProxy: androidx.camera.core.ImageProxy, rotation: Int): Bitmap {
        val full = imageProxy.toBitmap()
        val crop = Rect(imageProxy.cropRect)
        if (!crop.intersect(0, 0, full.width, full.height) || crop.width() <= 0 || crop.height() <= 0) {
            full.recycle()
            throw IllegalStateException("Camera viewport crop is empty")
        }
        val cropped = try {
            Bitmap.createBitmap(full, crop.left, crop.top, crop.width(), crop.height())
        } catch (error: Exception) {
            full.recycle()
            throw error
        }
        // Bitmap.createBitmap may return the source itself for a full-frame crop.
        if (cropped !== full) full.recycle()
        if (rotation == 0) return cropped
        return try {
            upright(cropped, rotation)
        } finally {
            cropped.recycle()
        }
    }

    /** A QR is accepted only when all its detected bounds fit inside the cropped square bitmap. */
    private fun isBarcodeInsideScanWindow(bitmap: Bitmap, box: Rect?): Boolean {
        if (box == null || bitmap.width <= 0 || bitmap.height <= 0) return false
        return box.left >= 0 && box.top >= 0 && box.right <= bitmap.width && box.bottom <= bitmap.height
    }

    private fun showScannerGuidance(message: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastScannerHintAt < 1200) return
        lastScannerHintAt = now
        mainHandler.post {
            if (inspectionStarted && !processing.get()) {
                scanHint.text = message
                showStatus("QR DETECTED · CHECK SCAN BOX", false)
            }
        }
    }

    private fun sessionExpired() {
        mobileToken = ""
        inspectionStarted = false
        inspectionSessionToken = ""
        inspectionSessionId = 0
        stopCamera()
        getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().remove("token").apply()
        showLogin()
        showLoginStatus("Session expired. Please login again.", false)
    }

    private fun startCamera() {
        if (!inspectionStarted) return
        mainHandler.post { previewView.visibility = View.VISIBLE }
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val provider = cameraProviderFuture.get()
            cameraProvider = provider
            val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
            val options = BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            val scanner = BarcodeScanning.getClient(options)
            val resolution = ResolutionSelector.Builder()
                .setResolutionStrategy(ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                .build()
            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(resolution)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                val mediaImage = imageProxy.image
                if (mediaImage == null || processing.get() || !inspectionStarted) { imageProxy.close(); return@setAnalyzer }
                val rotation = imageProxy.imageInfo.rotationDegrees
                val scanBitmap = try { createScanBitmap(imageProxy, rotation) } catch (_: Exception) {
                    imageProxy.close()
                    return@setAnalyzer
                }
                val image = InputImage.fromBitmap(scanBitmap, 0)
                scanner.process(image)
                    .addOnSuccessListener(cameraExecutor) { barcodes ->
                        val qrCodes = barcodes.filter { it.format == Barcode.FORMAT_QR_CODE }
                        val inside = qrCodes.filter { isBarcodeInsideScanWindow(scanBitmap, detectedBarcodeBounds(it)) }
                        val barcode = inside.firstOrNull { it.rawValue?.trim()?.startsWith("RTI-", true) == true }
                        val raw = barcode?.rawValue?.trim().orEmpty()
                        if (barcode != null && processing.compareAndSet(false, true)) {
                            try {
                                // Keep a separate evidence image; ML Kit's input is recycled below.
                                val frame = scanBitmap.copy(Bitmap.Config.ARGB_8888, false)
                                handleQr(raw, frame)
                            } catch (_: Exception) { processing.set(false) }
                        } else if (qrCodes.isNotEmpty()) {
                            showScannerGuidance(if (inside.isEmpty()) "MOVE THE FULL QR INSIDE THE SQUARE" else "QR FOUND · NOT AN AB SECURITAS CHECKPOINT")
                        }
                    }
                    .addOnFailureListener(cameraExecutor) { showScannerGuidance("SCAN ERROR · HOLD QR STEADY AND TRY AGAIN") }
                    .addOnCompleteListener(cameraExecutor) {
                        scanBitmap.recycle()
                        imageProxy.close()
                    }
            }
            fun bindWithPreviewViewport(attempt: Int = 0) {
                if (!inspectionStarted) return
                val viewport = previewView.viewPort
                if (viewport == null) {
                    if (attempt < 10) previewView.postDelayed({ bindWithPreviewViewport(attempt + 1) }, 100)
                    else showStatus("CAMERA VIEW NOT READY · REOPEN INSPECTION", false)
                    return
                }
                try {
                    val group = UseCaseGroup.Builder().setViewPort(viewport).addUseCase(preview).addUseCase(analysis).build()
                    provider.unbindAll()
                    camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, group)
                    showStatus("READY — SCAN QR", true)
                } catch (_: Exception) {
                    showStatus("CAMERA COULD NOT START · CHECK PERMISSION", false)
                }
            }
            previewView.post { bindWithPreviewViewport() }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun handleQr(rawValue: String, frame: Bitmap?) {
        val point = localStore.checkpoint(rawValue)
        val pointId = localStore.checkpointId(rawValue)
        if (point == null || pointId == null) {
            mainHandler.post {
                showStatus("QR NOT IN YOUR CHECKPOINT LIST", false)
                scanHint.text = "Reconnect to refresh the assigned checkpoint list"
                processing.set(false)
            }
            return
        }
        if (inspectionType == "SCHEDULED" && activeCheckpointIds.length() > 0 &&
            (0 until activeCheckpointIds.length()).none { activeCheckpointIds.optInt(it) == pointId }) {
            mainHandler.post {
                showStatus("QR NOT ASSIGNED TO THIS SCHEDULE", false)
                scanHint.text = "Scan a checkpoint assigned to $activeScheduleName"
                processing.set(false)
            }
            return
        }
        val sessionKey = offlineSessionKey.ifBlank { inspectionSessionToken }
        if (sessionKey.isBlank()) {
            mainHandler.post { showStatus("START INSPECTION BEFORE SCANNING", false); processing.set(false) }
            return
        }
        val gapSeconds = getSharedPreferences("rti_mobile", MODE_PRIVATE).getInt("scan_gap_seconds", 8).coerceIn(0, 300)
        if (gapSeconds > 0 && !localStore.sessionHasPoint(sessionKey, rawValue)) {
            val lastAt = localStore.latestSessionEventTime(sessionKey)
            if (!lastAt.isNullOrBlank()) {
                val elapsed = try {
                    val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { isLenient = false }
                    (System.currentTimeMillis() - (format.parse(lastAt)?.time ?: System.currentTimeMillis())) / 1000L
                } catch (_: Exception) { -1L }
                if (elapsed < gapSeconds) {
                    mainHandler.post {
                        val remaining = (gapSeconds - elapsed.coerceAtLeast(0)).toInt()
                        showStatus("WAIT $remaining SECONDS BEFORE NEXT POINT", false)
                        scanHint.text = "Minimum gap between new checkpoints: $gapSeconds seconds"
                        beep(ToneGenerator.TONE_SUP_ERROR, 350)
                        processing.set(false)
                    }
                    return
                }
            }
        }
        val payload = JSONObject().apply {
            put("event_id", UUID.randomUUID().toString())
            put("offline_session_key", sessionKey)
            put("qr_token", rawValue)
            put("point_code", point?.first ?: "")
            put("point_name", point?.second ?: "")
            put("inspector_record_id", inspectorRecordId)
            put("inspector_name", userName)
            put("device_id", deviceId)
            put("client_created_at", now())
            put("company_id", companyId)
            put("inspection_type", inspectionType)
            put("schedule_id", activeScheduleId)
            put("schedule_name", activeScheduleName)
            put("checkpoint_ids", JSONArray().also { ids ->
                for (index in 0 until activeCheckpointIds.length()) ids.put(activeCheckpointIds.optInt(index))
            })
            put("offline_queue", mobileToken.isBlank() || offlineMode)
        }
        localStore.saveEvent(payload)
        mainHandler.post {
            scanHint.text = "Saving inspection record..."
            statusText.text = if (mobileToken.isBlank()) "OFFLINE · QUEUED" else "SYNCING..."
        }
        Thread {
            var delivered = false
            var allowLanFallback = mobileToken.isBlank()
            if (mobileToken.isNotBlank()) {
                try {
                    val batch = JSONObject().put("events", JSONArray().put(payload))
                    val response = postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/sync", batch, mobileToken)
                    allowLanFallback = response.first in listOf(500, 502, 503, 504)
                    delivered = handleBatchResponse(response.first, response.second, payload, frame, false)
                } catch (_: Exception) {
                    allowLanFallback = true
                }
            }
            if (!delivered && allowLanFallback) {
                try {
                    localStore.markOffline(payload.optString("event_id"))
                    val lanUrl = getSharedPreferences("rti_mobile", MODE_PRIVATE).getString("lan_server_url", "").orEmpty().trimEnd('/')
                    val lanToken = decrypt(getSharedPreferences("rti_mobile", MODE_PRIVATE).getString("lan_api_token", "").orEmpty())
                    if (lanUrl.isNotBlank() && lanToken.isNotBlank()) {
                        val requestBody = JSONObject().put("company_id", companyId).put("events", JSONArray().put(payload))
                        val response = postJson(lanUrl + "/api/mobile/events", requestBody, lanToken)
                        delivered = handleBatchResponse(response.first, response.second, payload, frame, true)
                    }
                } catch (_: Exception) {
                    delivered = false
                }
            }
            if (!delivered) {
                localStore.markOffline(payload.optString("event_id"))
                mainHandler.post {
                    offlineMode = true
                    networkStatus.text = "OFFLINE · This scan is stored on the device"
                    showStatus("SAVED OFFLINE · WILL SYNC LATER", true)
                    scanHint.text = "Record is safely queued on this device"
                    renderCachedLocations(autoComplete = false)
                    val complete = isLocalInspectionComplete()
                    showScanSuccessPopup(if (complete) "✓ Inspection Completed Offline" else "✓ Scan Saved Offline",
                        if (complete) "All assigned checkpoints are safely stored on this phone and will sync when a connection returns."
                        else "This scan is safely stored on this phone. It will sync when Internet or the Client PC connection returns.", complete)
                }
            }
        }.start()
    }

    private fun handleBatchResponse(code: Int, body: String, payload: JSONObject, frame: Bitmap?, viaLan: Boolean): Boolean {
        val json = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
        if (code !in 200..299 || !json.optBoolean("ok", false)) {
            if (code == 401 && !viaLan) mainHandler.post { sessionExpired() }
            val rejected = json.optJSONArray("rejected")
            if (rejected != null && rejected.length() > 0) {
                val message = rejected.optJSONObject(0)?.optString("message", "Record rejected by server") ?: "Record rejected by server"
                mainHandler.post { showStatus(message, false); processing.set(false) }
                return false
            }
            return false
        }
        val accepted = json.optJSONArray("accepted") ?: JSONArray()
        val eventId = payload.optString("event_id")
        var result = ""
        var wasDuplicate = false
        var serverInspectionComplete = false
        for (index in 0 until accepted.length()) {
            val item = accepted.optJSONObject(index) ?: continue
            if (item.optString("event_id") == eventId) {
                localStore.markAccepted(listOf(eventId))
                result = item.optString("result", "ACCEPTED")
                wasDuplicate = item.optBoolean("duplicate", false)
                serverInspectionComplete = item.optBoolean("inspection_complete", false)
                break
            }
        }
        if (result.isBlank()) return false
        val label = payload.optString("point_name").ifBlank { payload.optString("point_code", "Inspection Point") }
        if (frame != null) saveToGallery(frame, result, "$label | $result")
        mainHandler.post {
            offlineMode = viaLan
            networkStatus.text = if (viaLan) "LAN FALLBACK · Client PC has queued this record for central sync" else "ONLINE · Record accepted by central server"
            lastScan.text = label + " — " + now()
            when (result) {
                "ACCEPTED" -> showStatus(if (wasDuplicate) "✓ ALREADY SYNCED" else "✓ ACCEPTED", true)
                "REPEAT" -> showStatus("REPEAT SCAN", false)
                else -> showStatus(result.replace('_', ' '), false)
            }
            scanHint.text = if (viaLan) "Saved through the local Client PC" else "Align the QR code inside the scan box"
            renderCachedLocations(autoComplete = false)
            if (result == "REPEAT_ALERT") repeatAlert("Repeat scan limit reached for this checkpoint.")
            else if (result == "ACCEPTED" || result == "REPEAT") {
                val complete = serverInspectionComplete || isLocalInspectionComplete()
                showScanSuccessPopup(if (complete) "✓ Inspection Completed" else if (result == "ACCEPTED") "✓ Scan Saved" else "Repeat Scan",
                    if (complete && viaLan) "All assigned checkpoints are saved on the Client PC and will sync to Central."
                    else if (complete) "All assigned checkpoints are saved to the inspection history."
                    else if (viaLan) "This scan is safely queued on the Client PC and will sync to Central."
                    else "This scan was saved to the inspection history.", complete)
            } else mainHandler.postDelayed({ processing.set(false) }, 900)
        }
        return true
    }

    private fun syncPendingEvents() {
        val events = localStore.pendingEvents()
        if (events.length() == 0) return
        var useLan = mobileToken.isBlank()
        if (mobileToken.isNotBlank()) {
            try {
                val response = postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/sync", JSONObject().put("events", events), mobileToken)
                if (response.first in 200..299) {
                    val result = JSONObject(response.second)
                    val accepted = result.optJSONArray("accepted") ?: JSONArray()
                    val rejected = result.optJSONArray("rejected") ?: JSONArray()
                    val ids = mutableListOf<String>()
                    for (index in 0 until accepted.length()) {
                        accepted.optJSONObject(index)?.optString("event_id")?.takeIf { it.isNotBlank() }?.let { ids.add(it) }
                    }
                    localStore.markAccepted(ids)
                    val remaining = localStore.pendingEvents().length()
                    if (ids.isNotEmpty() || rejected.length() > 0) mainHandler.post {
                        val rejectionMessage = rejected.optJSONObject(0)?.optString("message", "Check rejected record")
                        networkStatus.text = when {
                            remaining == 0 && rejected.length() == 0 -> "ONLINE · Sync complete · ${ids.size} offline record(s) synchronized"
                            rejected.length() > 0 -> "ONLINE · ${ids.size} synchronized · $remaining still queued · ${rejected.length()} rejected: $rejectionMessage"
                            else -> "ONLINE · ${ids.size} synchronized · $remaining still queued"
                        }
                        renderCachedLocations()
                    }
                    return
                }
                useLan = response.first in listOf(500, 502, 503, 504)
            } catch (_: Exception) {
                useLan = true
            }
        }
        if (!useLan) return
        try {
            val prefs = getSharedPreferences("rti_mobile", MODE_PRIVATE)
            val lanUrl = prefs.getString("lan_server_url", "").orEmpty().trimEnd('/')
            val lanToken = decrypt(prefs.getString("lan_api_token", "").orEmpty())
            if (lanUrl.isBlank() || lanToken.isBlank()) return
            val body = JSONObject().put("company_id", companyId).put("events", events)
            val response = postJson(lanUrl + "/api/mobile/events", body, lanToken)
            if (response.first !in 200..299) return
            val accepted = JSONObject(response.second).optJSONArray("accepted") ?: JSONArray()
            val ids = mutableListOf<String>()
            for (index in 0 until accepted.length()) {
                accepted.optJSONObject(index)?.optString("event_id")?.takeIf { it.isNotBlank() }?.let { ids.add(it) }
            }
            localStore.markAccepted(ids)
            if (ids.isNotEmpty()) mainHandler.post {
                val remaining = localStore.pendingEvents().length()
                networkStatus.text = if (remaining == 0)
                    "LAN FALLBACK · Sync complete · ${ids.size} record(s) queued on Client PC"
                else "LAN FALLBACK · ${ids.size} handed to Client PC · $remaining still queued"
                renderCachedLocations()
            }
        } catch (_: Exception) {
        }
    }

    private fun renderCachedLocations(autoComplete: Boolean = true) {
        val cached = getSharedPreferences("rti_mobile", MODE_PRIVATE).getString("cached_state", null) ?: return
        try {
            val state = JSONObject(cached)
            val checkpoints = localStore.readableDatabase.rawQuery("SELECT point_id,point_code,name,qr_token FROM checkpoints ORDER BY point_id", null).use { cursor ->
                val list = mutableListOf<Triple<String, String, String>>()
                while (cursor.moveToNext()) {
                    val id = cursor.getInt(0)
                    if (inspectionType != "SCHEDULED" || activeCheckpointIds.length() == 0 ||
                        (0 until activeCheckpointIds.length()).any { activeCheckpointIds.optInt(it) == id }) {
                        list.add(Triple(cursor.getString(1), cursor.getString(2), cursor.getString(3)))
                    }
                }
                list
            }
            val localEvents = localStore.sessionEvents(offlineSessionKey)
            val scannedTokens = mutableSetOf<String>()
            localEvents.forEach { event ->
                checkpoints.firstOrNull { it.first == event.first && it.second == event.second }?.third?.let { scannedTokens.add(it) }
            }
            val total = checkpoints.size.takeIf { it > 0 } ?: state.optInt("total_points")
            val scanned = scannedTokens.size
            val pending = maxOf(0, total - scanned)
            val summary = "TOTAL POINTS: $total    •    SCANNED: $scanned    •    PENDING: $pending"
            val details = StringBuilder()
            checkpoints.filter { it.third !in scannedTokens }.forEach { details.append("• ").append(it.first).append(" - ").append(it.second).append('\n') }
            if (scannedTokens.isNotEmpty()) {
                if (details.isNotEmpty()) details.append('\n')
                checkpoints.filter { it.third in scannedTokens }.forEach { details.append("✓ ").append(it.first).append(" - ").append(it.second).append('\n') }
            }
            mainHandler.post {
                locationSummary.text = summary
                locationSummary2.text = summary
                locationDetails.text = details.toString().trim()
                if (autoComplete && inspectionStarted && total > 0 && scanned >= total) completeInspection()
                renderScheduleSummary(state.optJSONArray("schedules") ?: JSONArray())
            }
        } catch (_: Exception) {
        }
    }

    private fun upright(src: Bitmap, rotation: Int): Bitmap {
        if (rotation == 0) return src
        val m = Matrix().apply { postRotate(rotation.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun saveToGallery(src: Bitmap, tag: String, label: String) {
        val inspector = "$userName ($userId)"; val device = deviceId; val stamp = now()
        Thread {
            try {
                val bmp = src.copy(Bitmap.Config.ARGB_8888, true)
                val canvas = Canvas(bmp)
                val size = (bmp.width * 0.035f).coerceAtLeast(18f)
                val bg = Paint().apply { color = Color.argb(170, 0, 0, 0) }
                val tp = Paint().apply { color = Color.WHITE; textSize = size; isAntiAlias = true; isFakeBoldText = true }
                canvas.drawRect(0f, bmp.height - size * 3.2f, bmp.width.toFloat(), bmp.height.toFloat(), bg)
                canvas.drawText(label, size * 0.5f, bmp.height - size * 1.9f, tp)
                canvas.drawText("$inspector | $device | $stamp", size * 0.5f, bmp.height - size * 0.6f, tp)
                val name = "RTI_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + "_" + tag + ".jpg"
                writeJpeg(bmp, name)
                bmp.recycle()
            } catch (_: Exception) {}
        }.start()
    }

    private fun writeJpeg(bmp: Bitmap, name: String) {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AB Securitas")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
        } else {
            if (needsLegacyStoragePermission()) return
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "AB Securitas")
            dir.mkdirs()
            val f = File(dir, name)
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            MediaScannerConnection.scanFile(this, arrayOf(f.absolutePath), arrayOf("image/jpeg"), null)
        }
    }

    private fun handleServerResponse(httpCode: Int, body: String, frame: Bitmap?) {
        val json = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
        val result = json.optString("result", "")
        val pointName = json.optString("point_name", "Inspection Point")
        lastScan.text = "$pointName — ${now()}"
        if (frame != null && httpCode in 200..299 && (result.equals("ACCEPTED", true) || result.equals("REPEAT", true) || result.equals("REPEAT_ALERT", true))) {
            saveToGallery(frame, result.uppercase(Locale.US), "$pointName | $result")
        }
        when {
            httpCode in 200..299 && result.equals("ACCEPTED", true) -> showStatus("✓ ACCEPTED", true)
            httpCode in 200..299 && result.equals("REPEAT", true) -> showStatus("REPEAT ${json.optInt("repeat_count", 0)} / 1", false)
            httpCode in 200..299 && result.equals("REPEAT_ALERT", true) -> {
                showStatus("⚠ REPEAT ALERT", false)
                repeatAlert(json.optString("message", "This point has already been repeated once."))
            }
            httpCode == 401 -> { sessionExpired(); processing.set(false); return }
            httpCode == 429 -> { showStatus("TOO FAST — SCAN THE REAL QR AT THE POINT", false); beep(ToneGenerator.TONE_SUP_ERROR, 400) }
            else -> showStatus(json.optString("message", "SERVER ERROR ($httpCode)"), false)
        }
        scanHint.text = "Align the QR code inside the scan box"
        refreshLocations()
        if (json.optBoolean("inspection_complete", false)) {
            mainHandler.postDelayed({ completeInspection() }, 500)
        } else if (!alertShowing) {
            mainHandler.postDelayed({ processing.set(false) }, 1000)
        }
    }

    private fun repeatAlert(message: String) {
        if (alertShowing) return
        alertShowing = true
        try { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 700) } catch (_: Exception) {}
        AlertDialog.Builder(this)
            .setTitle("Repeat Alert")
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss(); alertShowing = false; processing.set(false) }
            .show()
    }

    private fun beep(tone: Int, ms: Int) {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 100).startTone(tone, ms) } catch (_: Exception) {}
    }

    private fun showUploadedPopup(title: String, message: String) {
        if (isFinishing) return
        beep(ToneGenerator.TONE_CDMA_CONFIRM, 800)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun showScanSuccessPopup(title: String, message: String, inspectionComplete: Boolean = false) {
        if (isFinishing || alertShowing) {
            mainHandler.postDelayed({ processing.set(false) }, 900)
            return
        }
        alertShowing = true
        beep(ToneGenerator.TONE_CDMA_CONFIRM, 350)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .setOnDismissListener {
                alertShowing = false
                processing.set(false)
                if (inspectionComplete) completeInspection(showPopup = false)
            }
            .show()
    }

    private fun isLocalInspectionComplete(): Boolean {
        return try {
            val checkpoints = localStore.readableDatabase.rawQuery("SELECT point_id,point_code,name FROM checkpoints ORDER BY point_id", null).use { cursor ->
                val list = mutableListOf<Pair<String, String>>()
                while (cursor.moveToNext()) {
                    val pointId = cursor.getInt(0)
                    if (inspectionType != "SCHEDULED" || activeCheckpointIds.length() == 0 ||
                        (0 until activeCheckpointIds.length()).any { activeCheckpointIds.optInt(it) == pointId }) {
                        list.add(Pair(cursor.getString(1), cursor.getString(2)))
                    }
                }
                list
            }
            if (checkpoints.isEmpty()) return false
            val scanned = localStore.sessionEvents(offlineSessionKey).toSet()
            checkpoints.count { scanned.contains(it) } >= checkpoints.size
        } catch (_: Exception) { false }
    }

    private fun completeInspection(showPopup: Boolean = true) {
        if (!inspectionStarted) return
        inspectionStarted = false
        stopCamera()
        val session = inspectionSessionToken
        inspectionSessionToken = ""
        inspectionSessionId = 0
        offlineSessionKey = ""
        inspectionType = "MANUAL"
        activeScheduleId = 0
        activeScheduleName = ""
        activeCheckpointIds = JSONArray()
        previewView.visibility = View.GONE
        inspectionPanel.visibility = View.GONE
        showStart()
        processing.set(false)
        val pendingCount = localStore.pendingEvents().length()
        if (showPopup) showUploadedPopup("✓ Inspection Completed", if (pendingCount > 0)
            "All checkpoints are complete. $pendingCount record(s) remain saved locally until they can sync."
            else "All checkpoints are complete and synchronized.")
        if (session.isNotBlank() && mobileToken.isNotBlank()) {
            val token = mobileToken
            Thread { try { postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/end-inspection", JSONObject().apply { put("inspection_session_token", session) }, token) } catch (_: Exception) {} }.start()
        }
    }

    private fun postJson(url: String, payload: JSONObject, token: String?): Pair<Int, String> {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 10000; readTimeout = 10000; doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8"); setRequestProperty("Accept", "application/json")
            if (!token.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $token")
        }
        c.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        return Pair(code, body)
    }

    private fun getJson(url: String, token: String): Pair<Int, String> {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 10000; readTimeout = 10000
            setRequestProperty("Accept", "application/json"); setRequestProperty("Authorization", "Bearer $token")
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        return Pair(code, body)
    }

    private fun showLoginStatus(message: String, success: Boolean) {
        findViewById<TextView>(R.id.loginStatus).text = message
        findViewById<TextView>(R.id.loginStatus).setTextColor(ContextCompat.getColor(this, if (success) R.color.navy else R.color.red))
    }

    private fun hideKeyboard() {
        val focused = currentFocus ?: return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(focused.windowToken, 0)
        focused.clearFocus()
    }

    private fun showStatus(message: String, success: Boolean) {
        statusText.text = message
        statusText.setTextColor(ContextCompat.getColor(this, if (success) R.color.green else R.color.red))
    }

    private fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    override fun onDestroy() {
        mainHandler.removeCallbacks(connectionStatusPoll)
        try {
            val manager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            networkCallback?.let { manager.unregisterNetworkCallback(it) }
        } catch (_: Exception) {
        }
        stopCamera(); super.onDestroy(); cameraExecutor.shutdown()
    }
}
