package com.absecuritas.realtimeinspector

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Rect
import android.net.Uri
import android.text.InputFilter
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class SettingsActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_CENTRAL_URL = "central_url"
        const val EXTRA_LAN_URL = "lan_url"
        const val EXTRA_LAN_TOKEN = "lan_token"
        const val EXTRA_CAN_CHANGE_PIN = "can_change_pin"
    }

    private lateinit var centralUrl: EditText
    private lateinit var lanUrl: EditText
    private lateinit var lanToken: EditText
    private lateinit var message: TextView
    private lateinit var lanStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        installKeyboardAwareScroll(findViewById(R.id.settingsScroll))

        centralUrl = findViewById(R.id.settingsCentralUrl)
        lanUrl = findViewById(R.id.settingsLanUrl)
        lanToken = findViewById(R.id.settingsLanToken)
        message = findViewById(R.id.settingsMessage)
        lanStatus = findViewById(R.id.settingsLanStatus)
        centralUrl.setText(intent.getStringExtra(EXTRA_CENTRAL_URL).orEmpty())
        lanUrl.setText(intent.getStringExtra(EXTRA_LAN_URL).orEmpty())
        lanToken.setText(intent.getStringExtra(EXTRA_LAN_TOKEN).orEmpty())

        val canChangePin = intent.getBooleanExtra(EXTRA_CAN_CHANGE_PIN, false)
        findViewById<View>(R.id.settingsPinPanel).visibility = if (canChangePin) View.VISIBLE else View.GONE
        listOf(R.id.settingsCurrentPin, R.id.settingsNewPin, R.id.settingsConfirmPin).forEach { id ->
            findViewById<EditText>(id).filters = arrayOf(InputFilter.LengthFilter(8))
        }
        findViewById<Button>(R.id.settingsTestLan).setOnClickListener { testLan() }
        findViewById<Button>(R.id.settingsSave).setOnClickListener { save() }
        findViewById<Button>(R.id.settingsClose).setOnClickListener { finish() }
        findViewById<Button>(R.id.settingsChangePin).setOnClickListener {
            if (canChangePin) changePin()
        }
    }

    private fun save() {
        val normalizedCentral = AppConfig.normalizeServerUrl(centralUrl.text.toString())
        if (normalizedCentral == null) {
            centralUrl.error = "Enter a valid HTTPS Tailscale domain"
            centralUrl.requestFocus()
            return
        }
        val normalizedLan = normalizeLanOrigin(lanUrl.text.toString())
        if (normalizedLan == null) {
            lanUrl.error = "Enter a LAN origin such as http://192.168.1.10:5100"
            lanUrl.requestFocus()
            return
        }
        val token = lanToken.text.toString().trim()
        if (normalizedLan.isNotBlank() && token.isBlank()) {
            lanToken.error = "Enter the passkey from Client PC Setup"
            lanToken.requestFocus()
            return
        }
        try {
            AppConfig.saveServerBaseUrl(this, normalizedCentral)
        } catch (_: IllegalArgumentException) {
            message.text = "The Central domain could not be saved."
            return
        }
        hideKeyboard()
        setResult(RESULT_OK, Intent().apply {
            putExtra(EXTRA_LAN_URL, normalizedLan)
            putExtra(EXTRA_LAN_TOKEN, token)
        })
        Toast.makeText(this, "Settings saved securely on this device", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun normalizeLanOrigin(raw: String): String? {
        val value = raw.trim().trimEnd('/')
        if (value.isBlank()) return ""
        return try {
            val uri = Uri.parse(value)
            if ((uri.scheme != "http" && uri.scheme != "https") || uri.host.isNullOrBlank() ||
                uri.userInfo != null || uri.query != null || uri.fragment != null ||
                (uri.path?.isNotEmpty() == true && uri.path != "/")) null
            else value
        } catch (_: Exception) {
            null
        }
    }

    private fun testLan() {
        val base = normalizeLanOrigin(lanUrl.text.toString())
        val token = lanToken.text.toString().trim()
        if (base.isNullOrBlank() || token.isBlank()) {
            lanStatus.text = "Enter the Client PC address and passkey first."
            return
        }
        findViewById<Button>(R.id.settingsTestLan).isEnabled = false
        lanStatus.text = "Testing the Client PC connection…"
        Thread {
            val status = try {
                val connection = URL("$base/api/mobile/health").openConnection() as HttpURLConnection
                try {
                    connection.requestMethod = "GET"
                    connection.connectTimeout = 5000
                    connection.readTimeout = 5000
                    connection.setRequestProperty("Authorization", "Bearer $token")
                    connection.setRequestProperty("Cache-Control", "no-cache")
                    val code = connection.responseCode
                    val text = (if (code in 200..299) connection.inputStream else connection.errorStream)
                        ?.bufferedReader()?.use { it.readText() }.orEmpty()
                    val data = runCatching { JSONObject(text) }.getOrNull()
                    if (code in 200..299 && data?.optBoolean("ok") == true) {
                        val appCompanyId = getSharedPreferences("rti_mobile", MODE_PRIVATE).getInt("cached_company_id", 0)
                        val pcCompanyId = data.optInt("company_id", 0)
                        if (appCompanyId > 0 && pcCompanyId > 0 && appCompanyId != pcCompanyId) {
                            "Company ID mismatch · App $appCompanyId / Client PC $pcCompanyId. Correct the ID in Client PC Setup."
                        } else {
                            "Connected · Company $pcCompanyId · ${data.optString("client_id", "Client PC")} is ready"
                        }
                    } else data?.optString("message")?.takeIf { it.isNotBlank() } ?: "Connection failed (HTTP $code)"
                } finally {
                    connection.disconnect()
                }
            } catch (_: Exception) {
                "Cannot reach Client PC. Check same Wi-Fi, address, firewall and passkey."
            }
            runOnUiThread {
                lanStatus.text = status
                findViewById<Button>(R.id.settingsTestLan).isEnabled = true
            }
        }.start()
    }

    private fun changePin() {
        val current = findViewById<EditText>(R.id.settingsCurrentPin).text.toString()
        val next = findViewById<EditText>(R.id.settingsNewPin).text.toString()
        val confirm = findViewById<EditText>(R.id.settingsConfirmPin).text.toString()
        val status = findViewById<TextView>(R.id.settingsPinStatus)
        if (!SettingsPin.verify(this, current)) {
            status.text = "Current settings password is incorrect."
            return
        }
        if (!next.matches(Regex("\\d{4,8}"))) {
            status.text = "Choose a password containing 4–8 digits."
            return
        }
        if (next != confirm) {
            status.text = "The new password and confirmation do not match."
            return
        }
        SettingsPin.update(this, next)
        findViewById<EditText>(R.id.settingsCurrentPin).text.clear()
        findViewById<EditText>(R.id.settingsNewPin).text.clear()
        findViewById<EditText>(R.id.settingsConfirmPin).text.clear()
        status.text = "Settings password updated. Use it next time you open Settings."
        hideKeyboard()
    }

    private fun hideKeyboard() {
        val manager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        manager.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
    }

    private fun installKeyboardAwareScroll(scroll: ScrollView) {
        val baseBottom = scroll.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { view, insets ->
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            view.setPadding(view.paddingLeft, view.paddingTop, view.paddingRight, baseBottom + maxOf(ime, bars))
            insets
        }
        ViewCompat.requestApplyInsets(scroll)
        fun bind(view: View) {
            if (view is EditText) {
                view.setOnFocusChangeListener { focused, hasFocus ->
                    if (hasFocus) scroll.postDelayed({
                        val rect = Rect(0, 0, focused.width, focused.height)
                        scroll.offsetDescendantRectToMyCoords(focused, rect)
                        val bottom = scroll.height - scroll.paddingBottom
                        if (rect.bottom > bottom) scroll.smoothScrollBy(0, rect.bottom - bottom + 24)
                    }, 220)
                }
            } else if (view is ViewGroup) {
                for (index in 0 until view.childCount) bind(view.getChildAt(index))
            }
        }
        bind(scroll)
    }
}
