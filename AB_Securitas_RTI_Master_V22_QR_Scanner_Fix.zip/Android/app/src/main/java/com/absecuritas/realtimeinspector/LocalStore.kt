package com.absecuritas.realtimeinspector

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

class LocalStore(context: Context) : SQLiteOpenHelper(context, "rti_offline.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE checkpoints(
                point_id INTEGER PRIMARY KEY, point_code TEXT NOT NULL, name TEXT NOT NULL,
                location TEXT NOT NULL DEFAULT '', qr_token TEXT NOT NULL UNIQUE
            )"""
        )
        db.execSQL(
            """CREATE TABLE inspection_events(
                event_id TEXT PRIMARY KEY, session_key TEXT NOT NULL, qr_token TEXT NOT NULL,
                point_code TEXT NOT NULL, point_name TEXT NOT NULL, payload TEXT NOT NULL,
                created_at TEXT NOT NULL, pending INTEGER NOT NULL DEFAULT 1
            )"""
        )
        db.execSQL("CREATE INDEX idx_rti_local_session ON inspection_events(session_key,created_at)")
        db.execSQL("CREATE INDEX idx_rti_local_pending ON inspection_events(pending,created_at)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    @Synchronized
    fun cacheCheckpoints(locations: JSONArray) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("checkpoints", null, null)
            for (index in 0 until locations.length()) {
                val item = locations.optJSONObject(index) ?: continue
                val token = item.optString("qr_token")
                if (token.isBlank()) continue
                val row = ContentValues().apply {
                    put("point_id", item.optInt("id"))
                    put("point_code", item.optString("point_code"))
                    put("name", item.optString("name"))
                    put("location", item.optString("location"))
                    put("qr_token", token)
                }
                writableDatabase.insertWithOnConflict("checkpoints", null, row, SQLiteDatabase.CONFLICT_REPLACE)
            }
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    fun hasCheckpoint(qrToken: String): Boolean {
        readableDatabase.rawQuery("SELECT 1 FROM checkpoints WHERE qr_token=?", arrayOf(qrToken)).use { return it.moveToFirst() }
    }

    fun checkpoint(qrToken: String): Pair<String, String>? {
        readableDatabase.rawQuery("SELECT point_code,name FROM checkpoints WHERE qr_token=?", arrayOf(qrToken)).use {
            if (!it.moveToFirst()) return null
            return Pair(it.getString(0), it.getString(1))
        }
    }

    fun checkpointId(qrToken: String): Int? {
        readableDatabase.rawQuery("SELECT point_id FROM checkpoints WHERE qr_token=?", arrayOf(qrToken)).use {
            if (!it.moveToFirst()) return null
            return it.getInt(0)
        }
    }

    @Synchronized
    fun saveEvent(payload: JSONObject) {
        val row = ContentValues().apply {
            put("event_id", payload.optString("event_id"))
            put("session_key", payload.optString("offline_session_key"))
            put("qr_token", payload.optString("qr_token"))
            put("point_code", payload.optString("point_code"))
            put("point_name", payload.optString("point_name"))
            put("payload", payload.toString())
            put("created_at", payload.optString("client_created_at"))
            put("pending", 1)
        }
        writableDatabase.insertWithOnConflict("inspection_events", null, row, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun pendingEvents(limit: Int = 100): JSONArray {
        val result = JSONArray()
        readableDatabase.rawQuery(
            "SELECT payload FROM inspection_events WHERE pending=1 ORDER BY created_at LIMIT ?",
            arrayOf(limit.toString())
        ).use { cursor ->
            while (cursor.moveToNext()) result.put(JSONObject(cursor.getString(0)))
        }
        return result
    }

    @Synchronized
    fun markAccepted(eventIds: Collection<String>) {
        if (eventIds.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            eventIds.forEach { id -> db.execSQL("UPDATE inspection_events SET pending=0 WHERE event_id=?", arrayOf(id)) }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    @Synchronized
    fun markOffline(eventId: String) {
        val db=writableDatabase
        val savedPayload = db.rawQuery("SELECT payload FROM inspection_events WHERE event_id=?",arrayOf(eventId)).use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: return
        val payload=runCatching { JSONObject(savedPayload) }.getOrElse { JSONObject() }
        payload.put("offline_queue",true)
        val values=ContentValues().apply { put("payload",payload.toString()) }
        db.update("inspection_events",values,"event_id=?",arrayOf(eventId))
    }

    fun sessionEvents(sessionKey: String): List<Pair<String, String>> {
        val rows = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery(
            "SELECT point_code,point_name FROM inspection_events WHERE session_key=? ORDER BY created_at",
            arrayOf(sessionKey)
        ).use { cursor ->
            while (cursor.moveToNext()) rows.add(Pair(cursor.getString(0), cursor.getString(1)))
        }
        return rows
    }

    fun sessionHasPoint(sessionKey: String, qrToken: String): Boolean {
        readableDatabase.rawQuery(
            "SELECT 1 FROM inspection_events WHERE session_key=? AND qr_token=?",
            arrayOf(sessionKey, qrToken)
        ).use { return it.moveToFirst() }
    }

    fun latestSessionEventTime(sessionKey: String): String? {
        readableDatabase.rawQuery(
            "SELECT created_at FROM inspection_events WHERE session_key=? ORDER BY created_at DESC LIMIT 1",
            arrayOf(sessionKey)
        ).use { cursor -> return if (cursor.moveToFirst()) cursor.getString(0) else null }
    }
}
