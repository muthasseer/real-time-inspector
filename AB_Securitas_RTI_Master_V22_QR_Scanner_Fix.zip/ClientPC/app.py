"""Local company-scoped event monitor synced from Central over Tailscale Funnel."""
from datetime import datetime, timedelta
import hmac
import ipaddress
import json
import os
import re
import secrets
import sqlite3
import socket
import threading
import time
import uuid
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template_string, request, abort
load_dotenv(Path(__file__).with_name(".env"))
BASE_DIR = Path(__file__).resolve().parent
COMPANY_ID = os.getenv("RTI_COMPANY_ID", "1").strip()
CLIENT_ID = os.getenv("RTI_CLIENT_ID", "").strip()
def default_data_directory():
    configured = os.getenv("RTI_CLIENT_DATA_DIR", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    if os.name == "nt":
        root = Path(os.getenv("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
        return (root / "AB Securitas" / "Client PC" / "data").resolve()
    root = Path(os.getenv("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
    return (root / "ab-securitas-client-pc" / "data").resolve()
DATA_DIR = default_data_directory()
DB_PATH = Path(os.getenv("RTI_CLIENT_DATABASE_PATH") or DATA_DIR / "client_events.db").expanduser().resolve()
BACKUP_DIR = Path(os.getenv("RTI_CLIENT_BACKUP_DIR") or DATA_DIR / "backups").expanduser().resolve()
POLL_SECONDS = max(3, int(os.getenv("RTI_POLL_SECONDS", "5")))
CENTRAL_FUNNEL_URL = os.getenv("RTI_CENTRAL_FUNNEL_URL", "").strip().rstrip("/")
SYNC_TOKEN = os.getenv("RTI_CLIENT_SYNC_TOKEN", "").strip()
NODE_TOKEN = os.getenv("RTI_CLIENT_NODE_TOKEN", "").strip()
LAN_TOKEN = os.getenv("RTI_LAN_API_TOKEN", "").strip()
CLIENT_HOST = os.getenv("RTI_CLIENT_HOST", "0.0.0.0").strip()
app = Flask(__name__)
@app.before_request
def local_monitor_only():
    if request.path == "/api/mobile/events" and request.method == "POST":
        return None
    if request.path == "/api/mobile/health" and request.method == "GET":
        return None
    if request.remote_addr not in ("127.0.0.1", "::1"):
        abort(403)
def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("""CREATE TABLE IF NOT EXISTS events(
        event_id TEXT PRIMARY KEY,
        company_id TEXT,
        point_code TEXT,
        point_name TEXT,
        inspector_name TEXT,
        device_id TEXT,
        scan_time TEXT,
        result TEXT,
        received_at TEXT,
        payload TEXT
    )""")
    connection.execute("""CREATE TABLE IF NOT EXISTS sync_state(
        state_key TEXT PRIMARY KEY,
        state_value TEXT NOT NULL
    )""")
    connection.execute("CREATE INDEX IF NOT EXISTS idx_events_company_received ON events(company_id, received_at DESC)")
    connection.execute("""CREATE TABLE IF NOT EXISTS pending_events(
        event_id TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'PENDING', last_error TEXT NOT NULL DEFAULT ''
    )""")
    connection.execute("""CREATE TABLE IF NOT EXISTS cached_points(
        qr_token TEXT PRIMARY KEY, point_code TEXT NOT NULL, point_name TEXT NOT NULL,
        location TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL
    )""")
    connection.execute("""CREATE TABLE IF NOT EXISTS client_cache(
        cache_key TEXT PRIMARY KEY, cache_value TEXT NOT NULL
    )""")
    connection.execute("""CREATE TABLE IF NOT EXISTS schedules(
        schedule_id TEXT PRIMARY KEY, central_id INTEGER, name TEXT NOT NULL,
        schedule_time TEXT NOT NULL, days TEXT NOT NULL, grace_minutes INTEGER NOT NULL,
        checkpoint_ids TEXT NOT NULL DEFAULT '[]', enabled INTEGER NOT NULL DEFAULT 1,
        client_id TEXT, updated_at TEXT NOT NULL
    )""")
    connection.execute("""CREATE TABLE IF NOT EXISTS pending_schedule_actions(
        action_id TEXT PRIMARY KEY, action TEXT NOT NULL, payload TEXT NOT NULL,
        created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING', last_error TEXT NOT NULL DEFAULT ''
    )""")
    connection.commit()
    return connection
def copy_sqlite_database(source_path, destination_path):
    destination_path = Path(destination_path)
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination_path.with_name(destination_path.name + ".tmp")
    source = sqlite3.connect(str(source_path), timeout=30)
    target = sqlite3.connect(str(temporary), timeout=30)
    try:
        source.backup(target, pages=256, sleep=0.05)
        if target.execute("PRAGMA quick_check").fetchone()[0] != "ok":
            raise sqlite3.DatabaseError("SQLite backup integrity check failed")
        target.commit()
    except Exception:
        target.close()
        source.close()
        temporary.unlink(missing_ok=True)
        raise
    target.close()
    source.close()
    temporary.replace(destination_path)
    return destination_path
def path_is_within(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False
def migrate_legacy_database():
    legacy = (BASE_DIR / "client_events.db").resolve()
    if legacy == DB_PATH or DB_PATH.exists() or not legacy.is_file():
        return
    stamp = datetime.now().strftime("%Y%m%dT%H%M%S.%f")
    copy_sqlite_database(legacy, BACKUP_DIR / f"client_before_data_folder_migration_{stamp}.db")
    copy_sqlite_database(legacy, DB_PATH)
    print("Migrated Client PC database to persistent storage; original and backup kept:", DB_PATH)
def configured_backup_directory():
    connection = db()
    try:
        row = connection.execute("SELECT cache_value FROM client_cache WHERE cache_key='backup_directory'").fetchone()
        if row and row["cache_value"].strip():
            return Path(row["cache_value"]).expanduser().resolve()
    finally:
        connection.close()
    return BACKUP_DIR
def create_database_backup(directory=None):
    folder = Path(directory).expanduser().resolve() if directory else configured_backup_directory()
    if folder == DB_PATH.parent.resolve() or path_is_within(folder, Path(BASE_DIR).parent):
        raise ValueError("Choose a backup folder outside the live database and project folders")
    folder.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%dT%H%M%S.%f")
    return copy_sqlite_database(DB_PATH, folder / f"client_{stamp}.db")
def restore_database_backup(name):
    """Restore a listed Client PC backup after creating a rollback copy."""
    folder = configured_backup_directory()
    if not re.fullmatch(r"client_[A-Za-z0-9_.-]+\.db", str(name or "")):
        raise ValueError("Choose a valid Client PC backup file")
    source_path = (folder / name).resolve()
    if source_path.parent != folder or not source_path.is_file() or source_path.resolve() == DB_PATH:
        raise ValueError("The selected backup is not available in the configured backup folder")
    source = sqlite3.connect(f"file:{source_path.as_posix()}?mode=ro", uri=True, timeout=30)
    try:
        if source.execute("PRAGMA quick_check").fetchone()[0] != "ok":
            raise sqlite3.DatabaseError("The selected backup failed its integrity check")
        tables = {row[0] for row in source.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {"events", "pending_events", "sync_state"}.issubset(tables):
            raise sqlite3.DatabaseError("The selected file is not a complete Client PC database backup")
        rollback = create_database_backup(folder)
        target = sqlite3.connect(DB_PATH, timeout=30)
        try:
            source.backup(target, pages=256, sleep=0.05)
            if target.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise sqlite3.DatabaseError("Restored Client PC database failed its integrity check")
            target.commit()
        finally:
            target.close()
    finally:
        source.close()
    return rollback
_automatic_backup_next_check = 0.0
def automatic_backup_if_due():
    global _automatic_backup_next_check
    current_tick = time.monotonic()
    if current_tick < _automatic_backup_next_check:
        return None
    _automatic_backup_next_check = current_tick + 3600
    folder = configured_backup_directory()
    today = datetime.now().date()
    if folder.is_dir():
        for item in folder.glob("client_*.db"):
            try:
                if datetime.fromtimestamp(item.stat().st_mtime).date() == today:
                    return None
            except OSError:
                continue
    return create_database_backup(folder)
def _central_events_url(after_id):
    if not CENTRAL_FUNNEL_URL or not SYNC_TOKEN or not COMPANY_ID.isdigit():
        return None
    try:
        parsed = urlsplit(CENTRAL_FUNNEL_URL)
        if (parsed.scheme != "https" or not parsed.hostname or
                not parsed.hostname.lower().endswith(".ts.net") or parsed.port is not None or
                parsed.username or parsed.password or parsed.path not in ("", "/") or
                parsed.query or parsed.fragment):
            return None
    except ValueError:
        return None
    query = urlencode({"company_id": COMPANY_ID, "after_id": after_id, "limit": 100})
    return CENTRAL_FUNNEL_URL + "/api/client/events?" + query
def _last_scan_id(connection):
    row = connection.execute("SELECT state_value FROM sync_state WHERE state_key=?", ("last_scan_id:" + COMPANY_ID,)).fetchone()
    try:
        return max(0, int(row["state_value"])) if row else 0
    except (TypeError, ValueError):
        return 0
def _central_url(path):
    if not CENTRAL_FUNNEL_URL or not NODE_TOKEN or not COMPANY_ID.isdigit():
        return None
    try:
        parsed = urlsplit(CENTRAL_FUNNEL_URL)
        if (parsed.scheme != "https" or not parsed.hostname or
                not parsed.hostname.lower().endswith(".ts.net") or parsed.port is not None or
                parsed.username or parsed.password or parsed.path not in ("", "/") or
                parsed.query or parsed.fragment):
            return None
    except ValueError:
        return None
    return CENTRAL_FUNNEL_URL + path
def _node_headers():
    return {
        "Accept": "application/json",
        "Authorization": "Bearer " + NODE_TOKEN,
        "X-RTI-Client-ID": CLIENT_ID,
        "Cache-Control": "no-cache",
    }
def _record_connection_status(**values):
    """Store a compact, secret-free Central reachability/authentication status."""
    connection = db()
    try:
        row = connection.execute("SELECT cache_value FROM client_cache WHERE cache_key='central_connection_status'").fetchone()
        try:
            state = json.loads(row["cache_value"]) if row else {}
        except (TypeError, json.JSONDecodeError):
            state = {}
        state.update(values)
        state["checked_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        connection.execute("INSERT OR REPLACE INTO client_cache(cache_key,cache_value) VALUES('central_connection_status',?)",
                           (json.dumps(state, ensure_ascii=False),))
        connection.commit()
        return state
    finally:
        connection.close()
def _central_error_hint(status, response_body="", endpoint="node"):
    message = ""
    try:
        payload = json.loads(response_body or "{}")
        message = str(payload.get("message", "")) if isinstance(payload, dict) else ""
    except json.JSONDecodeError:
        pass
    if status == 401:
        if endpoint == "sync":
            return "Central is reachable, but the company sync token was rejected (HTTP 401). Check Company ID and make RTI_CLIENT_SYNC_TOKEN match that company's RTI_CLIENT_SYNC_TOKENS entry in Central Web/.env."
        return "Central is reachable, but the Client PC node token was rejected (HTTP 401). Check Company ID, Client PC ID, and the matching RTI_CLIENT_NODE_TOKENS entry in Central Web/.env."
    if status == 403:
        if "Client sync is not configured" in message:
            return "Central is reachable, but no company sync token is registered for this Company ID (HTTP 403). Add the company token to Central Web/.env."
        if "Company is not active" in message or "Client PC is disabled" in message:
            return f"Central rejected access (HTTP 403): {message}. Check the company and Client PC status in Central."
        if "permission" in message.lower():
            return f"Central denied this operation (HTTP 403): {message}."
        return "Central denied this request (HTTP 403). Check that the company sync token is configured for this Company ID."
    if status:
        return f"Central returned HTTP {status}" + (f": {message[:240]}" if message else ".")
    return "Central connection is unavailable. Check Internet, Tailscale Funnel, and the saved domain."
def _test_central_connections():
    """Check the node token and company event-sync token independently."""
    results = {"central_reachable": False, "node_auth": "NOT_CHECKED", "sync_auth": "NOT_CHECKED",
               "node_message": "", "sync_message": ""}
    bootstrap_url = _central_url("/api/client/bootstrap?" + urlencode({"company_id": COMPANY_ID, "client_id": CLIENT_ID}))
    events_url = _central_events_url(0)
    for label, url, headers in (
        ("node", bootstrap_url, _node_headers()),
        ("sync", events_url, {"Accept": "application/json", "Authorization": "Bearer " + SYNC_TOKEN, "Cache-Control": "no-cache"}),
    ):
        if not url:
            results[label + "_auth"] = "NOT_CONFIGURED"
            results[label + "_message"] = "Set a valid Central domain, company ID, Client PC ID, and token in the private .env configuration."
            continue
        try:
            request = Request(url, headers=headers)
            with urlopen(request, timeout=12) as response:
                response.read(1024)
                status = response.status
            results["central_reachable"] = True
            results[label + "_auth"] = "OK" if 200 <= status < 300 else "FAILED"
            results[label + "_message"] = "Authenticated" if 200 <= status < 300 else _central_error_hint(status, endpoint=label)
        except HTTPError as exc:
            body = exc.read(4096).decode("utf-8", "replace")
            results["central_reachable"] = True
            results[label + "_auth"] = "FAILED"
            results[label + "_message"] = _central_error_hint(exc.code, body, endpoint=label)
        except (URLError, TimeoutError, OSError, ValueError) as exc:
            results[label + "_auth"] = "UNAVAILABLE"
            results[label + "_message"] = _central_error_hint(0) + " (" + type(exc).__name__ + ")"
    results["central_authenticated"] = results["node_auth"] == "OK" and results["sync_auth"] == "OK"
    return results
def _sync_bootstrap():
    url = _central_url("/api/client/bootstrap?" + urlencode({"company_id": COMPANY_ID, "client_id": CLIENT_ID}))
    if not url:
        return
    request = Request(url, headers=_node_headers())
    with urlopen(request, timeout=15) as response:
        payload = json.loads(response.read(2 * 1024 * 1024 + 1).decode("utf-8"))
    if not isinstance(payload, dict) or not payload.get("ok"):
        raise ValueError("Central returned an invalid Client PC bootstrap response")
    connection = db()
    try:
        previous_row = connection.execute("SELECT cache_value FROM client_cache WHERE cache_key='bootstrap'").fetchone()
        previous = json.loads(previous_row["cache_value"]) if previous_row else {}
        old_schedules = json.dumps(previous.get("schedules", []), sort_keys=True, separators=(",", ":"))
        new_schedules = json.dumps(payload.get("schedules", []), sort_keys=True, separators=(",", ":"))
        schedule_changed = old_schedules != new_schedules and bool(payload.get("schedules") or previous.get("schedules"))
        sync_stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        connection.execute("INSERT OR REPLACE INTO client_cache(cache_key,cache_value) VALUES('bootstrap',?)",
                           (json.dumps(payload, ensure_ascii=False),))
        connection.execute("INSERT OR REPLACE INTO client_cache(cache_key,cache_value) VALUES('central_last_success',?)", (sync_stamp,))
        if schedule_changed:
            connection.execute("INSERT OR REPLACE INTO client_cache(cache_key,cache_value) VALUES('schedule_sync_status',?)",
                               (json.dumps({"complete": True, "updated_at": sync_stamp}),))
        connection.execute("DELETE FROM cached_points")
        for point in payload.get("points", []):
            if not isinstance(point, dict) or not point.get("qr_token"):
                continue
            connection.execute(
                "INSERT OR REPLACE INTO cached_points(qr_token,point_code,point_name,location,updated_at) VALUES(?,?,?,?,?)",
                (str(point["qr_token"]), str(point.get("point_code", "")), str(point.get("name", "")),
                 str(point.get("location", "")), datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            )
        connection.execute("DELETE FROM schedules WHERE central_id IS NOT NULL")
        for item in payload.get("schedules", []):
            if not isinstance(item, dict):
                continue
            schedule_id = str(item.get("id", ""))
            if not schedule_id:
                continue
            connection.execute(
                """INSERT OR REPLACE INTO schedules(schedule_id,central_id,name,schedule_time,days,grace_minutes,
                   checkpoint_ids,enabled,client_id,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (schedule_id, int(item.get("id", 0)), str(item.get("name", "")),
                 str(item.get("schedule_time", "")), ",".join(item.get("days", [])),
                 int(item.get("grace_minutes", 15)), json.dumps(item.get("checkpoint_ids", [])),
                 int(bool(item.get("enabled", True))), str(item.get("client_id") or ""),
                 datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            )
        connection.commit()
    finally:
        connection.close()
def _sync_pending_schedule_actions():
    url = _central_url("/api/client/schedules")
    if not url:
        return
    connection = db()
    try:
        rows = connection.execute(
            "SELECT action_id,action,payload FROM pending_schedule_actions WHERE status='PENDING' ORDER BY created_at LIMIT 25"
        ).fetchall()
    finally:
        connection.close()
    for row in rows:
        payload = json.loads(row["payload"])
        body = json.dumps(payload).encode("utf-8")
        request = Request(url, data=body, headers={**_node_headers(), "Content-Type": "application/json"}, method="POST")
        try:
            with urlopen(request, timeout=15) as response:
                result = json.loads(response.read(256 * 1024 + 1).decode("utf-8"))
            if not result.get("ok"):
                raise ValueError(str(result.get("message", "Central rejected the schedule")))
            central_id = int(result["id"])
            local_id = str(row["action_id"])
            connection = db()
            try:
                connection.execute("UPDATE schedules SET schedule_id=?,central_id=?,updated_at=? WHERE schedule_id=?",
                                   (str(central_id), central_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), local_id))
                connection.execute("DELETE FROM pending_schedule_actions WHERE action_id=?", (local_id,))
                connection.commit()
            finally:
                connection.close()
        except HTTPError as exc:
            reason = "Schedule permission denied by Central" if exc.code == 403 else f"Central HTTP {exc.code}"
            connection = db()
            try:
                connection.execute("UPDATE pending_schedule_actions SET last_error=? WHERE action_id=?", (reason, row["action_id"]))
                connection.commit()
            finally:
                connection.close()
        except (URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError) as exc:
            print("[CLIENT-SCHEDULE] Sync deferred:", type(exc).__name__)
            return
def _upload_pending_events():
    url = _central_url("/api/client/events?" + urlencode({"company_id": COMPANY_ID, "client_id": CLIENT_ID}))
    if not url:
        return 0
    connection = db()
    try:
        rows = connection.execute(
            "SELECT event_id,payload FROM pending_events WHERE status='PENDING' ORDER BY created_at LIMIT 100"
        ).fetchall()
    finally:
        connection.close()
    if not rows:
        return 0
    events = [json.loads(row["payload"]) for row in rows]
    body = json.dumps({"company_id": int(COMPANY_ID), "client_id": CLIENT_ID, "events": events}).encode("utf-8")
    request = Request(url, data=body, headers={**_node_headers(), "Content-Type": "application/json"}, method="POST")
    with urlopen(request, timeout=20) as response:
        result = json.loads(response.read(2 * 1024 * 1024 + 1).decode("utf-8"))
    if not isinstance(result, dict) or not result.get("ok"):
        raise ValueError("Central did not accept the Client PC event batch")
    accepted = {str(item.get("event_id")) for item in result.get("accepted", []) if isinstance(item, dict)}
    rejected = {str(item.get("event_id")): str(item.get("message", "Rejected by Central")) for item in result.get("rejected", []) if isinstance(item, dict)}
    connection = db()
    try:
        for row in rows:
            event_id = row["event_id"]
            if event_id in accepted:
                connection.execute("DELETE FROM pending_events WHERE event_id=?", (event_id,))
            elif event_id in rejected:
                connection.execute("UPDATE pending_events SET status='REJECTED',last_error=? WHERE event_id=?",
                                   (rejected[event_id][:500], event_id))
        connection.commit()
    finally:
        connection.close()
    return len(accepted)
def worker():
    connection = db()
    try:
        configured = _central_events_url(0) is not None
    finally:
        connection.close()
    if not configured:
        print("[CLIENT-SYNC] Configure the Central Funnel URL and company-scoped sync credentials in ClientPC/.env.")
    while True:
        phase = "node"
        retry_after = POLL_SECONDS
        try:
            try:
                automatic_backup_if_due()
            except (OSError, sqlite3.Error, ValueError) as backup_error:
                print("[CLIENT-BACKUP] Backup is deferred:", type(backup_error).__name__)
            phase = "node"
            _sync_bootstrap()
            _sync_pending_schedule_actions()
            uploaded = _upload_pending_events()
            if uploaded:
                print("[CLIENT-SYNC] Offline Android records synchronized:", uploaded)
            connection = db()
            try:
                after_id = _last_scan_id(connection)
            finally:
                connection.close()
            url = _central_events_url(after_id)
            if url is None:
                time.sleep(15)
                continue
            request = Request(url, headers={
                "Accept": "application/json",
                "Authorization": "Bearer " + SYNC_TOKEN,
                "Cache-Control": "no-cache",
            })
            phase = "sync"
            with urlopen(request, timeout=15) as response:
                result = json.loads(response.read(1024 * 1024 + 1).decode("utf-8"))
            if not isinstance(result, dict) or not result.get("ok") or not isinstance(result.get("events"), list):
                raise ValueError("Central returned an invalid event sync response")
            events = result["events"]
            connection = db()
            try:
                received_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                cursor_id = after_id
                for event in events:
                    if not isinstance(event, dict) or str(event.get("company_id", "")) != COMPANY_ID:
                        continue
                    row_id = int(event.get("cursor_id", 0))
                    event_id = str(event.get("event_id", ""))
                    if row_id <= 0 or not event_id:
                        continue
                    cursor_id = max(cursor_id, row_id)
                    connection.execute(
                        """INSERT OR IGNORE INTO events
                        (event_id,company_id,point_code,point_name,inspector_name,device_id,scan_time,result,received_at,payload)
                        VALUES(?,?,?,?,?,?,?,?,?,?)""",
                        (event_id, COMPANY_ID, str(event.get("point_code", "")),
                         str(event.get("point_name", "")), str(event.get("inspector_name", "")),
                         str(event.get("device_id", "")), str(event.get("scan_time", "")),
                         str(event.get("result", "")), received_at, json.dumps(event, ensure_ascii=False)),
                    )
                if cursor_id > after_id:
                    connection.execute("INSERT OR REPLACE INTO sync_state(state_key,state_value) VALUES(?,?)", ("last_scan_id:" + COMPANY_ID, str(cursor_id)))
                connection.commit()
            finally:
                connection.close()
            if events:
                print("[CLIENT-SYNC] Central events received:", len(events))
            stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            _record_connection_status(central_reachable=True, node_auth="OK", sync_auth="OK",
                                      last_success=stamp, last_error="", last_logged_error="", last_http_status=0)
        except HTTPError as exc:
            body = exc.read(4096).decode("utf-8", "replace")
            hint = _central_error_hint(exc.code, body, endpoint=phase)
            auth_key = "sync_auth" if phase == "sync" else "node_auth"
            auth_value = "FAILED" if exc.code == 401 else "OK" if exc.code < 400 else "PERMISSION_ERROR"
            current = _record_connection_status(central_reachable=True, **{auth_key: auth_value},
                                                last_error=hint, last_http_status=exc.code)
            retry_after = max(POLL_SECONDS, 30 if exc.code in (401, 403) else POLL_SECONDS)
            if current.get("last_logged_error") != hint:
                print("[CLIENT-SYNC]", hint)
                _record_connection_status(last_logged_error=hint)
        except (URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError) as exc:
            reason = getattr(exc, "reason", None)
            detail = str(reason if reason is not None else exc).strip()
            hint = "Central connection unavailable: " + (detail[:240] or type(exc).__name__)
            current = _record_connection_status(central_reachable=False, last_error=hint, last_http_status=0)
            if current.get("last_logged_error") != hint:
                print("[CLIENT-SYNC]", hint)
                _record_connection_status(last_logged_error=hint)
        except Exception as exc:
            hint = "Client sync error: " + type(exc).__name__
            current = _record_connection_status(last_error=hint)
            if current.get("last_logged_error") != hint:
                print("[CLIENT-SYNC]", hint)
                _record_connection_status(last_logged_error=hint)
        time.sleep(retry_after)
def _event_query(connection, limit=300):
    if COMPANY_ID:
        return connection.execute(
            """SELECT event_id,company_id,point_code,point_name,inspector_name,device_id,scan_time,result,received_at,payload
               FROM events WHERE company_id=? ORDER BY scan_time DESC,received_at DESC LIMIT ?""",
            (COMPANY_ID, limit),
        ).fetchall()
    return connection.execute(
        """SELECT event_id,company_id,point_code,point_name,inspector_name,device_id,scan_time,result,received_at,payload
           FROM events ORDER BY scan_time DESC,received_at DESC LIMIT ?""",
        (limit,),
    ).fetchall()
def _event_count(connection):
    if COMPANY_ID:
        events = connection.execute("SELECT COUNT(*) n FROM events WHERE company_id=?", (COMPANY_ID,)).fetchone()["n"]
        queued = connection.execute("SELECT COUNT(*) n FROM pending_events WHERE status IN ('PENDING','REJECTED')").fetchone()["n"]
        return events + queued
    events = connection.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
    queued = connection.execute("SELECT COUNT(*) n FROM pending_events WHERE status IN ('PENDING','REJECTED')").fetchone()["n"]
    return events + queued
def _combined_event_rows(connection, limit=300):
    rows = []
    for db_row in _event_query(connection, limit):
        entry = dict(db_row)
        payload = entry.pop("payload", "")
        try:
            item = json.loads(payload)
        except (TypeError, json.JSONDecodeError):
            item = {}
        entry.update({"inspection_type": item.get("inspection_type", "MANUAL"),
                      "schedule_name": item.get("schedule_name", ""),
                      "sync_source": item.get("sync_source", "LIVE")})
        rows.append(entry)
    pending = connection.execute("SELECT event_id,payload,created_at,status,last_error FROM pending_events ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    for row in pending:
        try:
            item = json.loads(row["payload"])
        except (TypeError, json.JSONDecodeError):
            item = {}
        rows.append({
            "event_id": row["event_id"], "company_id": COMPANY_ID,
            "point_code": item.get("point_code", ""), "point_name": item.get("point_name", ""),
            "inspector_name": item.get("inspector_name", ""), "device_id": item.get("device_id", ""),
            "scan_time": item.get("client_created_at", row["created_at"]),
            "result": item.get("local_result", "PENDING" if row["status"] == "PENDING" else "REJECTED"),
            "received_at": "Pending Central" if row["status"] == "PENDING" else row["last_error"] or "Rejected",
            "inspection_type": item.get("inspection_type", "MANUAL"),
            "schedule_name": item.get("schedule_name", ""),
            "sync_source": "OFFLINE_QUEUE" if item.get("offline_queue") else "WAITING_FOR_CENTRAL",
        })
    rows.sort(key=lambda item: str(item.get("scan_time", "")), reverse=True)
    return rows[:limit]
@app.get("/")
def home():
    connection = db()
    try:
        rows = _combined_event_rows(connection)
        total = _event_count(connection)
    finally:
        connection.close()
    return render_template_string(PAGE, rows=rows, total=total, company_id=COMPANY_ID or "All companies")
@app.get("/api/events")
def events():
    connection = db()
    try:
        response = jsonify(_combined_event_rows(connection))
        response.headers["X-Total-Count"] = str(_event_count(connection))
        return response
    finally:
        connection.close()
def _upsert_client_env(values):
    path = BASE_DIR / ".env"
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    seen = set()
    output = []
    for line in lines:
        key, separator, _ = line.partition("=")
        if separator and key in values:
            if key not in seen:
                output.append(f"{key}={values[key]}")
                seen.add(key)
        else:
            output.append(line)
    for key, value in values.items():
        if key not in seen:
            output.append(f"{key}={value}")
    path.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
    if os.name != "nt":
        path.chmod(0o600)
def _lan_addresses():
    addresses = set()
    try:
        for result in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET, socket.SOCK_STREAM):
            address = result[4][0]
            if ipaddress.ip_address(address).is_private and not address.startswith("127."):
                addresses.add(address)
    except OSError:
        pass
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            probe.connect(("192.0.2.1", 80))
            address = probe.getsockname()[0]
            if ipaddress.ip_address(address).is_private:
                addresses.add(address)
        finally:
            probe.close()
    except OSError:
        pass
    return sorted(addresses)
@app.get("/setup")
def setup_page():
    return render_template_string(SETUP_PAGE)
@app.get("/api/setup")
def setup_info():
    return jsonify(ok=True, central_url=CENTRAL_FUNNEL_URL, company_id=COMPANY_ID,
                   client_id=CLIENT_ID, lan_passkey=LAN_TOKEN,
                   backup_directory=str(configured_backup_directory()),
                   database=str(DB_PATH), data_directory=str(DATA_DIR))
@app.post("/api/setup/ip-check")
def setup_ip_check():
    port = int(os.getenv("RTI_CLIENT_PORT", "5100"))
    addresses = _lan_addresses()
    return jsonify(ok=True, addresses=addresses,
                   urls=[f"http://{address}:{port}" for address in addresses],
                   message="Use a Client PC IP and Android phone on the same Wi-Fi/LAN.")
@app.post("/api/setup/test-central")
def setup_test_central():
    result = _test_central_connections()
    failures = [result[key] for key in ("node_message", "sync_message")
                if result.get(key) and result.get(key.replace("_message", "_auth")) != "OK"]
    error = " · ".join(failures)
    http_status = 401 if "HTTP 401" in error else 403 if "HTTP 403" in error else 0
    _record_connection_status(**result, last_attempt=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                              last_error=error, last_http_status=http_status)
    return jsonify(ok=result["central_authenticated"], **result)
@app.post("/api/setup")
def setup_save():
    global CENTRAL_FUNNEL_URL, COMPANY_ID, CLIENT_ID, LAN_TOKEN
    data = request.get_json(silent=True) or {}
    action = str(data.get("action", "save")).strip().lower()
    if action == "rotate_lan_key":
        LAN_TOKEN = secrets.token_urlsafe(32)
        _upsert_client_env({"RTI_LAN_API_TOKEN": LAN_TOKEN})
        return jsonify(ok=True, lan_passkey=LAN_TOKEN, message="New LAN passkey created. Update the Android LAN settings with this key.")
    if action == "backup_now":
        try:
            created = create_database_backup()
            return jsonify(ok=True, name=created.name, path=str(created), message="Backup completed. Previous backups were kept.")
        except (OSError, sqlite3.Error, ValueError) as exc:
            return jsonify(ok=False, message="Backup failed: " + str(exc)), 400
    if action == "save_backup_directory":
        raw = str(data.get("backup_directory", "")).strip()
        folder = Path(raw).expanduser().resolve() if raw else BACKUP_DIR
        if folder == DB_PATH.parent.resolve() or path_is_within(folder, Path(BASE_DIR).parent):
            return jsonify(ok=False, message="Choose a backup folder outside the live database and project folders"), 400
        try:
            folder.mkdir(parents=True, exist_ok=True)
            probe = folder / (".rti-write-check-" + secrets.token_hex(8))
            with probe.open("xb") as handle:
                handle.write(b"ok")
            probe.unlink(missing_ok=True)
            connection = db()
            try:
                connection.execute("INSERT OR REPLACE INTO client_cache(cache_key,cache_value) VALUES('backup_directory',?)", (str(folder),))
                connection.commit()
            finally:
                connection.close()
            return jsonify(ok=True, directory=str(folder), message="Backup folder saved")
        except (OSError, sqlite3.Error, ValueError) as exc:
            return jsonify(ok=False, message="Could not save backup folder: " + str(exc)), 400
    funnel = str(data.get("central_url", "")).strip().rstrip("/")
    company_id = str(data.get("company_id", "")).strip()
    client_id = str(data.get("client_id", "")).strip()
    if funnel:
        try:
            parsed = urlsplit(funnel)
            valid_funnel = (parsed.scheme == "https" and parsed.hostname and parsed.hostname.lower().endswith(".ts.net")
                            and parsed.port is None and not parsed.username and not parsed.password
                            and parsed.path in ("", "/") and not parsed.query and not parsed.fragment)
        except ValueError:
            valid_funnel = False
        if not valid_funnel:
            return jsonify(ok=False, message="Enter the Central HTTPS Tailscale domain, for example https://server.tailnet.ts.net"), 400
    if not company_id.isdigit():
        return jsonify(ok=False, message="Company ID must be the numeric ID shown in Central Web → Companies → Company Directory"), 400
    if client_id and client_id != CLIENT_ID:
        return jsonify(ok=False, message="Client PC ID is generated once during setup and cannot be changed here. Keep the displayed ID so Central access stays matched."), 400
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", CLIENT_ID):
        return jsonify(ok=False, message="Client PC ID is not initialized. Run INSTALL_SETUP.bat once to generate this PC's ID."), 400
    company_changed = company_id != COMPANY_ID
    CENTRAL_FUNNEL_URL, COMPANY_ID = funnel, company_id
    _upsert_client_env({"RTI_CENTRAL_FUNNEL_URL": funnel, "RTI_COMPANY_ID": company_id})
    if company_changed:
        return jsonify(ok=True, restart_required=True,
                       message="Company ID saved. Run REPAIR_SYNC_TOKENS.bat and restart Central + Client PC services before checking sync.")
    return jsonify(ok=True, restart_required=False,
                   message="Client PC settings saved. Central sync will retry automatically.")
@app.get("/api/client/backups")
def client_backups():
    folder = configured_backup_directory()
    files = []
    if folder.is_dir():
        for item in sorted(folder.glob("*.db"), key=lambda path: path.stat().st_mtime, reverse=True)[:50]:
            try:
                stat = item.stat()
                files.append({"name": item.name, "size_bytes": stat.st_size,
                              "created_at": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")})
            except OSError:
                continue
    return jsonify(ok=True, directory=str(folder), database=str(DB_PATH), backups=files,
                   automatic_backup="Daily; older backups are kept")
@app.post("/api/client/backups")
def client_restore_backup():
    data = request.get_json(silent=True) or {}
    try:
        rollback = restore_database_backup(str(data.get("name", "")))
        return jsonify(ok=True, rollback_backup=rollback.name,
                       message="Restore completed. A safety copy of the previous database was saved as " + rollback.name)
    except (OSError, sqlite3.Error, ValueError) as exc:
        return jsonify(ok=False, message="Restore failed; the active database was not intentionally replaced: " + str(exc)), 400
@app.get("/api/mobile/health")
def mobile_health():
    supplied = request.headers.get("Authorization", "")
    scheme, separator, token = supplied.partition(" ")
    if not LAN_TOKEN or not separator or scheme.lower() != "bearer" or not hmac.compare_digest(token.strip(), LAN_TOKEN):
        return jsonify(ok=False, message="LAN Client PC authentication failed"), 401
    connection = db()
    try:
        row = connection.execute("SELECT cache_value FROM client_cache WHERE cache_key='central_connection_status'").fetchone()
        central = json.loads(row["cache_value"]) if row else {}
        pending = connection.execute("SELECT COUNT(*) n FROM pending_events WHERE status='PENDING'").fetchone()["n"]
    finally:
        connection.close()
    return jsonify(ok=True, company_id=int(COMPANY_ID) if COMPANY_ID.isdigit() else 0, client_id=CLIENT_ID, server="AB Securitas Client PC",
                   central_reachable=bool(central.get("central_reachable")),
                   central_authenticated=central.get("node_auth") == "OK" and central.get("sync_auth") == "OK",
                   central_last_success=central.get("last_success", ""), central_last_error=central.get("last_error", ""),
                   central_node_auth=central.get("node_auth", "NOT_CHECKED"),
                   central_sync_auth=central.get("sync_auth", "NOT_CHECKED"), pending_events=pending)
@app.post("/api/mobile/events")
def accept_lan_events():
    supplied = request.headers.get("Authorization", "")
    scheme, separator, token = supplied.partition(" ")
    if not LAN_TOKEN or not separator or scheme.lower() != "bearer" or not hmac.compare_digest(token.strip(), LAN_TOKEN):
        return jsonify(ok=False, message="LAN Client PC authentication failed"), 401
    data = request.get_json(silent=True) or {}
    if str(data.get("company_id", "")) != COMPANY_ID:
        return jsonify(ok=False, message="Company does not match this Client PC"), 403
    events = data.get("events")
    if not isinstance(events, list) or len(events) > 100:
        return jsonify(ok=False, message="events must contain at most 100 records"), 400
    connection = db()
    accepted, rejected = [], []
    try:
        for event in events:
            if not isinstance(event, dict):
                rejected.append({"event_id": "", "message": "Invalid event record"})
                continue
            event_id = str(event.get("event_id", "")).strip()
            qr_token = str(event.get("qr_token", "")).strip()
            session_key = str(event.get("offline_session_key", "")).strip()
            created_at = str(event.get("client_created_at", "")).strip()
            try:
                inspector_id = int(event.get("inspector_record_id", 0))
            except (TypeError, ValueError):
                inspector_id = 0
            if not event_id or len(event_id) > 128 or not qr_token or not session_key or not created_at or inspector_id <= 0:
                rejected.append({"event_id": event_id, "message": "Event data is incomplete"})
                continue
            point = connection.execute("SELECT point_code,point_name FROM cached_points WHERE qr_token=?", (qr_token,)).fetchone()
            if not point:
                rejected.append({"event_id": event_id, "message": "Checkpoint is not in the last central download"})
                continue
            existing = connection.execute("SELECT payload FROM pending_events WHERE event_id=?", (event_id,)).fetchone()
            if existing:
                prior = json.loads(existing["payload"])
                accepted.append({"ok": True, "event_id": event_id, "duplicate": True, "result": prior.get("local_result", "ACCEPTED")})
                continue
            repeated = 0
            for row in connection.execute("SELECT payload FROM pending_events"):
                try:
                    prior = json.loads(row["payload"])
                    if prior.get("offline_session_key") == session_key and prior.get("qr_token") == qr_token:
                        repeated += 1
                except (TypeError, json.JSONDecodeError):
                    continue
            result = "ACCEPTED" if repeated == 0 else "REPEAT" if repeated == 1 else "REPEAT_ALERT"
            stored = dict(event)
            stored.update(company_id=int(COMPANY_ID), client_id=CLIENT_ID, point_code=point["point_code"],
                          point_name=point["point_name"], local_result=result)
            stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            connection.execute("INSERT INTO pending_events(event_id,payload,created_at,status) VALUES(?,?,?,'PENDING')",
                               (event_id, json.dumps(stored, ensure_ascii=False), stamp))
            accepted.append({"ok": True, "event_id": event_id, "duplicate": False, "result": result,
                             "point_code": point["point_code"], "point_name": point["point_name"]})
        connection.commit()
        return jsonify(ok=True, accepted=accepted, rejected=rejected, queued_for_central=True)
    finally:
        connection.close()
def cached_bootstrap(connection=None):
    own_connection = connection is None
    connection = connection or db()
    try:
        row = connection.execute("SELECT cache_value FROM client_cache WHERE cache_key='bootstrap'").fetchone()
        return json.loads(row["cache_value"]) if row else {}
    finally:
        if own_connection:
            connection.close()
@app.get("/schedules")
def schedules_page():
    return render_template_string(SCHEDULES_PAGE)
@app.get("/api/schedules")
def get_schedules():
    connection = db()
    try:
        bootstrap = cached_bootstrap(connection)
        rows = connection.execute("SELECT * FROM schedules ORDER BY schedule_time,schedule_id").fetchall()
        return jsonify(ok=True, schedule_permission=bool(bootstrap.get("schedule_permission")),
                       schedules=[dict(row) for row in rows], online=bool(bootstrap.get("server_time_utc")))
    finally:
        connection.close()
@app.post("/api/schedules")
def create_schedule():
    connection = db()
    try:
        bootstrap = cached_bootstrap(connection)
        if not bootstrap.get("schedule_permission"):
            return jsonify(ok=False, message="Schedule permission is disabled. Ask the Super Admin to grant it."), 403
    finally:
        connection.close()
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()[:120]
    schedule_time = str(data.get("schedule_time", "")).strip()
    days = sorted({str(day).strip().upper()[:3] for day in (data.get("days", []) if isinstance(data.get("days"), list) else str(data.get("days", "")).split(",")) if str(day).strip()})
    allowed_days = {"MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"}
    try:
        grace = int(data.get("grace_minutes", 15))
    except (TypeError, ValueError):
        grace = -1
    if not name or not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", schedule_time):
        return jsonify(ok=False, message="Schedule name and 24-hour time are required"), 400
    if not days or set(days) - allowed_days or not 0 <= grace <= 1440:
        return jsonify(ok=False, message="Choose valid weekdays and a grace period from 0 to 1440 minutes"), 400
    local_id = "local-" + uuid.uuid4().hex
    payload = {"company_id": int(COMPANY_ID), "client_id": CLIENT_ID, "name": name, "schedule_time": schedule_time,
               "days": days, "grace_minutes": grace, "checkpoint_ids": [], "enabled": True}
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    connection = db()
    try:
        connection.execute("INSERT INTO schedules(schedule_id,central_id,name,schedule_time,days,grace_minutes,checkpoint_ids,enabled,client_id,updated_at) VALUES(?,NULL,?,?,?,?,?,1,?,?)",
                           (local_id, name, schedule_time, ",".join(days), grace, "[]", CLIENT_ID, stamp))
        connection.execute("INSERT INTO pending_schedule_actions(action_id,action,payload,created_at,status) VALUES(?,'CREATE',?,?,'PENDING')",
                           (local_id, json.dumps(payload), stamp))
        connection.commit()
    finally:
        connection.close()
    try:
        _sync_pending_schedule_actions()
    except Exception:
        pass
    return jsonify(ok=True, queued=True, message="Schedule saved. It will be sent to Central when a connection is available."), 201
@app.get("/api/client/status")
def client_status():
    connection = db()
    try:
        bootstrap = cached_bootstrap(connection)
        pending = connection.execute("SELECT COUNT(*) n FROM pending_events WHERE status='PENDING'").fetchone()["n"]
        rejected = connection.execute("SELECT COUNT(*) n FROM pending_events WHERE status='REJECTED'").fetchone()["n"]
        sync_row = connection.execute("SELECT cache_value FROM client_cache WHERE cache_key='schedule_sync_status'").fetchone()
        schedule_sync = json.loads(sync_row["cache_value"]) if sync_row else {}
        central_row = connection.execute("SELECT cache_value FROM client_cache WHERE cache_key='central_connection_status'").fetchone()
        central = json.loads(central_row["cache_value"]) if central_row else {}
        last_sync_row = connection.execute("SELECT cache_value FROM client_cache WHERE cache_key='central_last_success'").fetchone()
        last_sync = last_sync_row["cache_value"] if last_sync_row else ""
        try:
            recent = bool(central.get("last_success")) and datetime.now() - datetime.strptime(central["last_success"], "%Y-%m-%d %H:%M:%S") <= timedelta(seconds=max(60, POLL_SECONDS * 3))
        except ValueError:
            recent = False
        node_auth = central.get("node_auth", "NOT_CHECKED")
        sync_auth = central.get("sync_auth", "NOT_CHECKED")
        online = bool(recent and node_auth == "OK" and sync_auth == "OK")
        return jsonify(ok=True, company_id=int(COMPANY_ID) if COMPANY_ID.isdigit() else 0,
                       online=online, schedule_permission=bool(bootstrap.get("schedule_permission")),
                       pending_events=pending, rejected_events=rejected, company_name=bootstrap.get("company_name", ""),
                       client_id=CLIENT_ID, lan_host=CLIENT_HOST,
                       schedule_sync_complete=bool(schedule_sync.get("complete")),
                       schedule_updated_at=schedule_sync.get("updated_at", ""), central_last_sync=last_sync,
                       internet_online=bool(central.get("central_reachable")), central_reachable=bool(central.get("central_reachable")),
                       central_authenticated=node_auth == "OK" and sync_auth == "OK", node_auth=node_auth,
                       sync_auth=sync_auth, central_last_success=central.get("last_success", ""),
                       central_last_error=central.get("last_error", ""), central_last_http_status=central.get("last_http_status", 0))
    finally:
        connection.close()
SETUP_PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#101d36"><title>Client PC Setup · AB Securitas</title>
<style>
:root{font-family:Inter,Segoe UI,Arial,sans-serif;color:#172033;background:#f3f6fa}*{box-sizing:border-box}body{margin:0}
header{background:#101d36;color:white;padding:22px clamp(18px,5vw,64px);display:flex;justify-content:space-between;align-items:center;gap:16px}header b{font-size:18px}header small{display:block;color:#79c8ef;margin-top:4px;letter-spacing:.08em}a{color:#087eb8}
main{max-width:1000px;margin:auto;padding:28px clamp(16px,4vw,40px)}h1{font-size:26px;margin:0 0 6px}.muted{font-size:13px;color:#718096}.panel{background:#fff;border:1px solid #e5ebf3;border-radius:14px;padding:20px;margin:18px 0;box-shadow:0 5px 20px #15264a0b}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.field{display:flex;flex-direction:column;gap:6px}.full{grid-column:1/-1}label{font-size:13px;font-weight:700;color:#667085}input{padding:11px 12px;border:1px solid #d8e0eb;border-radius:8px;font:inherit}.btn{border:0;border-radius:8px;padding:10px 14px;background:#087eb8;color:white;font-weight:700;cursor:pointer;margin:4px 4px 4px 0}.btn.dark{background:#101d36}.notice{border:1px solid #dbeefe;border-radius:10px;background:#f0f8ff;padding:13px;margin:12px 0;color:#24527a}.status{min-height:24px;color:#087e4c;font-size:13px;margin-top:8px}.key{font-family:Consolas,monospace;letter-spacing:.04em}.table{width:100%;border-collapse:collapse;font-size:13px}.table td,.table th{text-align:left;padding:10px;border-bottom:1px solid #edf1f6}.table th{font-size:10px;color:#718096;text-transform:uppercase}
@media(max-width:650px){header{align-items:flex-start;flex-direction:column}.grid{grid-template-columns:1fr}.full{grid-column:auto}}
</style></head><body><header><div><b>AB SECURITAS</b><small>REAL TIME INSPECTOR · CLIENT PC SETUP</small></div><a href="/">Back to live monitor</a></header>
<main><h1>Connect this Client PC</h1><div class="muted">Configure Central sync, create the private LAN passkey, and copy the Android connection details.</div>
<section class="panel"><h2>Central connection</h2><div class="grid"><div class="field full"><label for="central">Central Tailscale HTTPS domain</label><input id="central" placeholder="https://server.tailnet.ts.net"></div><div class="notice full"><b>Company ID:</b> copy the numeric ID from Central Web → Companies → Company Directory. Do not use the Company Code. It must match the company that owns the QR checkpoint.</div><div class="field"><label for="company">Company ID</label><input id="company" inputmode="numeric" autocomplete="off" placeholder="Enter numeric Company ID"><small class="muted">Visible in the Central Company Directory.</small></div><div class="field"><label for="client">Generated Client PC ID</label><div style="display:flex;gap:8px"><input id="client" class="key" readonly aria-describedby="clientIdHelp" style="flex:1"><button class="btn dark" type="button" onclick="copyClientId()">Copy ID</button></div><small id="clientIdHelp" class="muted">Generated once during INSTALL_SETUP. Keep it when reconnecting this PC.</small></div></div><button class="btn" onclick="saveConfig()">Save connection</button><button class="btn dark" onclick="testCentral()">Test Central connection</button><div class="notice">Central must have matching credentials for this Company ID and generated Client PC ID. INSTALL_SETUP provisions both sides when Central and Client PC are in the same project folder. If you change Company ID later in that combined install, run REPAIR_SYNC_TOKENS.bat and restart the services. If Central runs on another server, its administrator must register the same IDs and private tokens there and restart Central. This page never displays secrets. Super Admin can rename or block this PC after its first authenticated sync. HTTP 401 means an ID or token does not match; HTTP 403 shows the server access reason.</div><div id="configMsg" class="status" role="status" aria-live="polite"></div><div id="centralStatus" class="notice" role="status" aria-live="polite">Central connection has not been checked yet.</div></section>
<section class="panel"><h2>Android LAN connection</h2><div class="notice">Use this only when the Android phone and Client PC are on the same Wi-Fi/LAN. The Client PC keeps receiving scans locally and forwards them to Central when the internet connection returns.</div><button class="btn" onclick="checkIp()">IP Check</button><div id="ipList" class="status" role="status">Press IP Check to find the Client PC address.</div><p><label for="passkey">LAN passkey</label><input id="passkey" class="key" readonly></p><button class="btn dark" onclick="copyPasskey()">Copy passkey</button><button class="btn" onclick="rotateKey()">Create new passkey</button><div class="muted">In the Android app, open the LAN configuration section, enter the matching Client PC URL and paste this passkey, then tap Test LAN connection and Save.</div><div id="keyMsg" class="status" role="status"></div></section>
<section class="panel"><h2>Separate database backups</h2><div class="muted">The active database is stored outside the replaceable app folder. Automatic daily backups are kept until you remove them yourself. Restoring first creates a safety copy of the current database.</div><p><label for="backup">Backup folder on this PC</label><input id="backup" placeholder="C:\\RTI-Backups"></p><button class="btn" onclick="saveBackup()">Save backup folder</button><button class="btn dark" onclick="backupNow()">Back up now</button><div id="backupMsg" class="status" role="status" aria-live="polite"></div><div id="dbPath" class="muted"></div><table class="table"><thead><tr><th>Backup file</th><th>Created</th><th>Size</th><th>Action</th></tr></thead><tbody id="backupRows"></tbody></table></section>
</main><script>
const el=id=>document.getElementById(id);async function api(path,body){const r=await fetch(path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined,cache:'no-store'});const x=await r.json();if(!r.ok||!x.ok)throw new Error(x.message||'Request failed');return x}
async function load(){try{const x=await api('/api/setup');el('central').value=x.central_url||'';el('company').value=x.company_id||'';el('client').value=x.client_id||'';el('passkey').value=x.lan_passkey||'';el('backup').value=x.backup_directory||'';el('dbPath').textContent='Active data file: '+x.database+' · Data folder: '+x.data_directory;await loadBackups();await refreshCentralStatus()}catch(e){el('configMsg').textContent=e.message}}
async function saveConfig(){try{const x=await api('/api/setup',{action:'save',central_url:el('central').value,company_id:el('company').value});el('configMsg').textContent=x.message;if(x.restart_required){el('centralStatus').textContent='Company ID changed. Central authorization can be checked after token repair and service restart.';el('centralStatus').style.borderColor='#efc4c4';return}await testCentral()}catch(e){el('configMsg').textContent=e.message}}
async function copyClientId(){try{await navigator.clipboard.writeText(el('client').value);el('configMsg').textContent='Client PC ID copied: '+el('client').value}catch(_){el('client').select();document.execCommand('copy');el('configMsg').textContent='Client PC ID copied.'}}
async function testCentral(){el('centralStatus').textContent='Checking the Central domain and both authentication tokens…';try{const r=await fetch('/api/setup/test-central',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',cache:'no-store'}),x=await r.json();el('centralStatus').textContent='Internet/domain: '+(x.central_reachable?'REACHABLE':'UNAVAILABLE')+' · Client PC token: '+x.node_auth+' — '+x.node_message+' · Company sync token: '+x.sync_auth+' — '+x.sync_message;el('centralStatus').style.borderColor=x.central_authenticated?'#9ed8b7':'#efc4c4'}catch(e){el('centralStatus').textContent='Unable to check Central: '+e.message;el('centralStatus').style.borderColor='#efc4c4'}}
async function refreshCentralStatus(){try{const x=await api('/api/client/status');el('centralStatus').textContent='Company ID '+x.company_id+' · Client PC '+x.client_id+' · Internet/domain: '+(x.central_reachable?'REACHABLE':'NOT REACHED')+' · Central authorization: '+(x.central_authenticated?'OK':'FAILED / WAITING')+(x.central_last_error?' · '+x.central_last_error:'')+(x.central_last_success?' · Last complete sync: '+x.central_last_success:'');el('centralStatus').style.borderColor=x.central_authenticated?'#9ed8b7':'#efc4c4'}catch(_){}}
async function checkIp(){try{const x=await api('/api/setup/ip-check',{});el('ipList').textContent=x.urls.length?x.urls.join('   ·   '):'No private LAN IP found. Connect this PC to the same local network as the phone and try again.'}catch(e){el('ipList').textContent=e.message}}
async function rotateKey(){try{const x=await api('/api/setup',{action:'rotate_lan_key'});el('passkey').value=x.lan_passkey;el('keyMsg').textContent=x.message}catch(e){el('keyMsg').textContent=e.message}}
async function copyPasskey(){try{await navigator.clipboard.writeText(el('passkey').value);el('keyMsg').textContent='Passkey copied. Keep it private and enter it in the Android app.'}catch(_){el('passkey').select();document.execCommand('copy');el('keyMsg').textContent='Passkey copied.'}}
async function saveBackup(){try{const x=await api('/api/setup',{action:'save_backup_directory',backup_directory:el('backup').value});el('backupMsg').textContent=x.message;await loadBackups()}catch(e){el('backupMsg').textContent=e.message}}
async function backupNow(){try{const x=await api('/api/setup',{action:'backup_now'});el('backupMsg').textContent=x.message+' · '+x.name;await loadBackups()}catch(e){el('backupMsg').textContent=e.message}}
async function restoreBackup(name){if(!confirm('Restore '+name+'? Current Client PC records will be replaced, after saving a separate safety copy.'))return;el('backupMsg').textContent='Validating backup and saving safety copy…';try{const x=await api('/api/client/backups',{name});el('backupMsg').textContent=x.message;await loadBackups()}catch(e){el('backupMsg').textContent=e.message}}
async function loadBackups(){const x=await api('/api/client/backups');el('dbPath').textContent='Active database: '+x.database+' · Backup folder: '+x.directory+' · '+x.automatic_backup;const rows=el('backupRows');rows.replaceChildren();for(const f of x.backups){const tr=document.createElement('tr');for(const v of [f.name,f.created_at,(f.size_bytes/1024).toFixed(1)+' KB']){const td=document.createElement('td');td.textContent=v;tr.appendChild(td)}const action=document.createElement('td'),button=document.createElement('button');button.className='btn dark';button.textContent='Restore';button.addEventListener('click',()=>restoreBackup(f.name));action.appendChild(button);tr.appendChild(action);rows.appendChild(tr)}if(!x.backups.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=4;td.textContent='No backups yet';tr.appendChild(td);rows.appendChild(tr)}}load();setInterval(refreshCentralStatus,15000);
</script></body></html>"""
SCHEDULES_PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#101d36"><title>Inspection schedules · AB Securitas</title>
<style>
:root{font-family:Inter,Segoe UI,Arial,sans-serif;color:#172033;background:#f3f6fa}*{box-sizing:border-box}body{margin:0}
header{background:#101d36;color:#fff;padding:22px clamp(18px,5vw,64px);display:flex;justify-content:space-between;align-items:center;gap:16px}
header b{font-size:18px}header small{display:block;color:#79c8ef;margin-top:4px;letter-spacing:.08em}a{color:#b8def4}
main{max-width:1120px;margin:auto;padding:28px clamp(16px,4vw,40px)}.panel{background:#fff;border:1px solid #e5ebf3;border-radius:14px;padding:20px;margin-bottom:16px;box-shadow:0 5px 20px #15264a0b}
h1{font-size:25px;margin:0 0 5px}.muted{font-size:13px;color:#718096}.notice{border:1px solid #dbeefe;border-radius:10px;background:#f0f8ff;padding:13px;margin:12px 0;color:#24527a}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.field{display:flex;flex-direction:column;gap:6px}.field.full{grid-column:1/-1}label{font-size:13px;font-weight:700;color:#667085}
input{padding:11px 12px;border:1px solid #d8e0eb;border-radius:8px;font:inherit}.btn{border:0;border-radius:8px;padding:10px 14px;background:#087eb8;color:#fff;font-weight:700;cursor:pointer}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:12px;border-bottom:1px solid #edf1f6}th{font-size:10px;color:#718096;text-transform:uppercase} .empty{text-align:center;color:#718096;padding:24px}
@media(max-width:650px){header{align-items:flex-start;flex-direction:column}.grid{grid-template-columns:1fr}.field.full{grid-column:auto}}
</style></head><body>
<header><div><b>AB SECURITAS</b><small>REAL TIME INSPECTOR · CLIENT PC</small></div><nav><a href="/">Live monitor</a> · <a href="/setup">Client PC setup</a></nav></header>
<main><h1>Inspection schedules</h1><div class="muted">Schedules are stored locally and synced to Central when a connection returns.</div>
<div id="accessNotice" class="notice">Checking this Client PC's schedule permission…</div>
<section class="panel" id="scheduleForm" style="display:none"><h2>Create a schedule</h2><div class="grid">
<div class="field"><label for="name">Schedule name</label><input id="name" maxlength="120" placeholder="Night patrol"></div>
<div class="field"><label for="schedule_time">Start time</label><input id="schedule_time" type="time" required></div>
<div class="field"><label for="days">Days</label><input id="days" value="MON,TUE,WED,THU,FRI,SAT,SUN"></div>
<div class="field"><label for="grace_minutes">Grace period in minutes</label><input id="grace_minutes" type="number" min="0" max="1440" value="15"></div></div><br>
<button class="btn" onclick="createSchedule()">Save schedule</button> <span id="message" class="muted"></span></section>
<section class="panel"><h2>Schedules for this Client PC</h2><div style="overflow:auto"><table><thead><tr><th>Name</th><th>Time</th><th>Days</th><th>Grace</th><th>Status</th></tr></thead><tbody id="rows"><tr><td colspan="5" class="empty">No schedules have synced yet.</td></tr></tbody></table></div></section>
<section class="panel"><h2>Local sync status</h2><div id="syncStatus" class="muted">Loading…</div></section></main>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
async function load(){try{let r=await fetch('/api/schedules',{cache:'no-store'}),x=await r.json();document.getElementById('scheduleForm').style.display=x.schedule_permission?'block':'none';document.getElementById('accessNotice').textContent=x.schedule_permission?'Schedule permission is enabled. Changes are checked by the central server and will sync when online.':'Schedule permission is disabled. Ask the Super Admin to enable it for this Client PC.';document.getElementById('rows').innerHTML=(x.schedules||[]).map(s=>'<tr><td>'+esc(s.name)+'</td><td>'+esc(s.schedule_time)+'</td><td>'+esc(s.days)+'</td><td>'+esc(s.grace_minutes)+' min</td><td>'+(s.central_id?'Central':'Waiting to sync')+'</td></tr>').join('')||'<tr><td colspan="5" class="empty">No schedules have synced yet.</td></tr>';let sr=await fetch('/api/client/status'),state=await sr.json();let sync=state.schedule_sync_complete?' · Schedule updated · Sync complete ('+esc(state.schedule_updated_at)+')':'';document.getElementById('syncStatus').textContent='Company '+esc(state.company_name||'')+' · Client '+esc(state.client_id)+' · Pending offline records '+state.pending_events+' · Rejected records '+state.rejected_events+' · '+(state.online?'Central connected':'Waiting for central connection')+sync}catch(_){document.getElementById('syncStatus').textContent='Local service is running; central status is unavailable.'}}
async function createSchedule(){let d={name:document.getElementById('name').value,schedule_time:document.getElementById('schedule_time').value,days:document.getElementById('days').value,grace_minutes:document.getElementById('grace_minutes').value};let r=await fetch('/api/schedules',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}),x=await r.json();document.getElementById('message').textContent=x.message||(x.ok?'Schedule saved':'Could not save schedule');if(r.ok){document.getElementById('name').value='';load()}}
load();setInterval(load,10000);
</script></body></html>"""
PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#101d36"><title>Live Scan Monitor · AB Securitas</title>
<style>
:root{font-family:Inter,Segoe UI,Arial,sans-serif;color:#172033;background:#f3f6fa;font-synthesis:none}
*{box-sizing:border-box}body{margin:0}.bar{background:#101d36;color:#f8fbff;padding:24px clamp(18px,5vw,64px);display:flex;align-items:center;justify-content:space-between;gap:20px}
.brand{font-size:19px;font-weight:800;letter-spacing:.02em}.brand small{display:block;color:#79c8ef;font-size:11px;letter-spacing:.09em;margin-top:5px}.connection{font-size:12px;color:#c9d6e8;display:flex;align-items:center;gap:8px}.dot{width:8px;height:8px;border-radius:50%;background:#45ce83;box-shadow:0 0 0 4px #45ce8322}
main{max-width:1440px;margin:auto;padding:30px clamp(16px,4vw,48px)}.heading{display:flex;justify-content:space-between;align-items:end;gap:16px;margin-bottom:20px}.heading h1{font-size:25px;margin:0 0 6px;letter-spacing:-.03em}.muted{color:#718096;font-size:13px}.count{font-size:14px;font-weight:700;color:#41516a}.panel{background:white;border:1px solid #e5ebf3;border-radius:14px;box-shadow:0 8px 28px #15264a0b;overflow:hidden}.toolbar{padding:14px 18px;border-bottom:1px solid #edf1f6;display:flex;gap:12px;align-items:center;justify-content:space-between}.search{max-width:370px;width:100%;padding:10px 12px;border:1px solid #d8e0eb;border-radius:9px;font:inherit}.refresh{border:0;border-radius:9px;padding:10px 13px;background:#087eb8;color:white;font-weight:700;cursor:pointer}.refresh:hover{background:#066d9f}.tablewrap{overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:13px 16px;border-bottom:1px solid #edf1f6;white-space:nowrap}th{background:#f8fafc;font-size:10px;letter-spacing:.08em;color:#718096;text-transform:uppercase;position:sticky;top:0}tbody tr:hover{background:#f8fafc}.badge{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:10px;font-weight:800}.accepted{background:#dff7e8;color:#168245}.repeat{background:#fff1c7;color:#916a00}.empty{text-align:center;color:#718096;padding:40px 16px}.footer{padding:14px 18px;color:#8390a2;font-size:11px;border-top:1px solid #edf1f6}
@media(max-width:650px){.bar{align-items:flex-start;flex-direction:column;padding:18px}.heading{align-items:flex-start;flex-direction:column}.heading h1{font-size:22px}.toolbar{align-items:stretch;flex-direction:column}.search{max-width:none}.refresh{align-self:flex-start}}
</style></head><body><header class="bar"><div class="brand">AB SECURITAS<small>ELECTRONIC SECURITY DIVISION · REAL TIME INSPECTOR</small></div><div class="connection"><span class="dot"></span><span id="connection">Waiting for Client PC records · auto refresh every 3 seconds</span></div></header>
<main><div class="heading"><div><h1>Inspection events</h1><div class="muted">Company {{ company_id }} · Internet first, local Client PC queue and sync recovery</div><p><a href="/schedules" style="color:#087eb8;font-weight:700">Inspection schedules</a> · <a href="/setup" style="color:#087eb8;font-weight:700">Client PC setup &amp; backups</a></p></div><div class="count"><span id="visible">{{ rows|length }}</span> shown · <span id="total">{{ total }}</span> total</div></div>
<section class="panel"><div class="toolbar"><input class="search" id="search" type="search" placeholder="Search point, inspector, device…" aria-label="Search events"><button class="refresh" id="refresh" type="button">Refresh now</button></div>
<div class="tablewrap"><table><thead><tr><th>Scan time</th><th>Point</th><th>Inspector</th><th>Device</th><th>Mode</th><th>Schedule</th><th>Sync source</th><th>Result</th><th>Received</th></tr></thead><tbody id="events">{% for event in rows %}<tr><td>{{ event.scan_time }}</td><td><b>{{ event.point_code }}</b> — {{ event.point_name }}</td><td>{{ event.inspector_name }}</td><td>{{ event.device_id }}</td><td>{{ event.inspection_type or 'MANUAL' }}</td><td>{{ event.schedule_name or '—' }}</td><td>{{ event.sync_source or 'LIVE' }}</td><td><span class="badge {{ 'accepted' if event.result == 'ACCEPTED' else 'repeat' }}">{{ event.result }}</span></td><td>{{ event.received_at }}</td></tr>{% else %}<tr><td class="empty" colspan="9">Waiting for scan events…</td></tr>{% endfor %}</tbody></table></div><div class="footer">Showing the latest 300 events. Monitor page is restricted to this PC; Android LAN sync uses a separate token-protected endpoint.</div></section></main>
<script>
const body=document.getElementById('events'),search=document.getElementById('search');let latest=[];
const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
function render(){const query=search.value.trim().toLowerCase();const rows=latest.filter(item=>Object.values(item).join(' ').toLowerCase().includes(query));document.getElementById('visible').textContent=rows.length;body.innerHTML=rows.length?rows.map(event=>`<tr><td>${escapeHtml(event.scan_time)}</td><td><b>${escapeHtml(event.point_code)}</b> — ${escapeHtml(event.point_name)}</td><td>${escapeHtml(event.inspector_name)}</td><td>${escapeHtml(event.device_id)}</td><td>${escapeHtml(event.inspection_type==='SCHEDULED'?'Scheduled':'Manual')}</td><td>${escapeHtml(event.schedule_name||'—')}</td><td>${escapeHtml(event.sync_source==='OFFLINE_QUEUE'?'Offline queue':event.sync_source==='WAITING_FOR_CENTRAL'?'Waiting for Central':'Live')}</td><td><span class="badge ${event.result==='ACCEPTED'?'accepted':'repeat'}">${escapeHtml(event.result)}</span></td><td>${escapeHtml(event.received_at)}</td></tr>`).join(''):'<tr><td class="empty" colspan="9">No matching inspection events.</td></tr>'}
let refreshInFlight=false;
async function refresh(force=false){if(refreshInFlight||(!force&&document.visibilityState==='hidden'))return;refreshInFlight=true;try{const response=await fetch('/api/events',{cache:'no-store'});if(!response.ok)throw new Error('request failed');const data=await response.json();if(!Array.isArray(data))throw new Error('invalid event list');latest=data;document.getElementById('total').textContent=response.headers.get('X-Total-Count')||latest.length;document.getElementById('connection').textContent='Live · Updated '+new Date().toLocaleTimeString();render()}catch(_){document.getElementById('connection').textContent='Refresh unavailable · retrying shortly'}finally{refreshInFlight=false}}
search.addEventListener('input',render);document.getElementById('refresh').addEventListener('click',()=>refresh(true));document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')refresh(true)});refresh(true);setInterval(()=>refresh(),3000);
</script></body></html>"""
if __name__ == "__main__":
    migrate_legacy_database()
    db().close()
    threading.Thread(target=worker, name="rti-client-funnel-monitor", daemon=True).start()
    app.run(host=CLIENT_HOST, port=int(os.getenv("RTI_CLIENT_PORT", "5100")), debug=False, use_reloader=False)
