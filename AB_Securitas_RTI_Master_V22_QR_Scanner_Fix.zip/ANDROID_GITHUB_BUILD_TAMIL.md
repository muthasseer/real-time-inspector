# Android APK + Tailscale Funnel — தமிழ்

## தொடங்குவதற்கு முன்

1. Central Linux VM-ல் Tailscale sign in செய்திருக்க வேண்டும்.
2. Central Web API, Mobile API Proxy இயங்கிக்கொண்டிருக்க வேண்டும்.
3. Tailscale Funnel enable செய்து approve செய்திருக்க வேண்டும்.
4. Funnel HTTPS origin-ஐ அறிந்திருக்க வேண்டும். உதாரணம்: https://device-name.tailnet-name.ts.net. இதை APK build நேரத்தில் கொடுக்க வேண்டியதில்லை.
5. GitHub repository-யில் முழு project root files உள்ளனவா சரிபார்க்கவும்: Android, Web, ClientPC, MobileApiProxy, scripts, deploy, .github.
6. முந்தைய APK-ஐ uninstall செய்ய வேண்டாம். அதே app மீது update install செய்தால் phone-இன் offline queue மற்றும் saved domain பாதுகாக்கப்படும்.

## GitHub Actions மூலம் APK

1. GitHub repository-ஐத் திறந்து Actions tab செல்லவும்.
2. “Build AB Securitas Real Time Inspector APK” workflow தேர்ந்தெடுக்கவும்.
3. Run workflow அழுத்தவும்; domain கேட்கப்படாது.
4. Workflow முடிந்ததும் artifact பகுதியில் “AB-Securitas-Real-Time-Inspector-APK” பதிவிறக்கவும்.
5. APK-ஐ Android phone-ல் install செய்யவும்.
6. Login பக்கத்தில் ⚙ அழுத்தி Central Funnel domain-ஐ உள்ளிட்டு Save Domain அழுத்தவும். உதாரணம்: `https://device-name.tailnet-name.ts.net`. Domain phone-ல் சேமிக்கப்படும்.
7. Internet இணைப்புடன் Inspector User ID / Password மூலம் login செய்யவும்; checkpoints மற்றும் schedule reminders download ஆகும்.
8. Inspection Home-ல் ⚙ அழுத்தி LAN fallback தேவைப்பட்டால் Client PC Wi-Fi IP மற்றும் அதன் LAN passkey உள்ளிட்டு Test LAN Connection, பிறகு Save LAN Settings அழுத்தவும்.

## APK update signature

Android update APK-ஐ பழைய APK-ன் அதே signing key-யுடன் தான் ஏற்றுக்கொள்ளும். GitHub Actions repository secrets-ல் `RTI_ANDROID_KEYSTORE_BASE64`, `RTI_ANDROID_KEYSTORE_PASSWORD`, `RTI_ANDROID_KEY_ALIAS`, `RTI_ANDROID_KEY_PASSWORD` என்ற நான்கு values-ஐ ஒரு முறை அமைத்து, அடுத்தடுத்த build-களிலும் அதே keystore-ஐ பயன்படுத்தவும். V22 workflow அந்த key-ஐ இருந்தால் பயன்படுத்தும். பழைய APK வேறு key-யால் கையொப்பமிடப்பட்டிருந்தால், uninstall செய்து offline data-ஐ இழக்கும் அபாயம் எடுக்க வேண்டாம்; முந்தைய build key-யைத் தொடரவும்.

புதிய app signing key உருவாக்க Windows-ல் `keytool -genkeypair -v -keystore rti-signing.jks -alias rti -keyalg RSA -keysize 2048 -validity 10000` இயக்கி, passwords-ஐ பாதுகாப்பாக வைத்துக்கொள்ளவும். Base64 secret value-ஐ உருவாக்க PowerShell-ல் `[Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path .\rti-signing.jks)))` இயக்கவும். Keystore-ஐ GitHub-ல் commit செய்யாமல், GitHub repository **Settings → Secrets and variables → Actions** பகுதியில் மட்டும் secrets ஆக சேமிக்கவும்.

இந்த V22 source-ல் Android layout மற்றும் drawable XML சரிபார்க்கவும். GitHub repository-யில் source ZIP வழியாக build செய்தால் `AB_Securitas_RTI_Master_V22_QR_Scanner_Fix.zip`-ஐ சேர்க்கவும்; அது கிடைத்தால் workflow அந்த ZIP-ஐ முதலில் தேர்ந்தெடுக்கும். Repository-யில் project files நேரடியாக இருந்தால் Android, Web, ClientPC, MobileApiProxy, scripts, deploy மற்றும் `.github` அனைத்தையும் V22 source-ஆல் update செய்து push செய்யவும்.

Workflow APK-ஐ மட்டும் build செய்கிறது. அது Central server-ஐ deploy செய்யாது. VM, Tailscale sign-in, Funnel approval மற்றும் GitHub repository access ஆகியவை உரிமையாளரின் account-களில் அமைக்கப்பட வேண்டும்.

## Private keys மற்றும் tokens

- .env கோப்புகள், database, password, node token, LAN token ஆகியவற்றை GitHub-ல் commit செய்ய வேண்டாம்.
- RTI_CLIENT_NODE_TOKENS ஒவ்வொரு company/client pair-க்கும் தனி token வைத்திருக்க வேண்டும்.
- Company ID / Client PC ID values Central Web/.env token mappings-உடன் எழுத்துக்கு எழுத்து பொருந்த வேண்டும். Schedule permission page tokens உருவாக்காது. Client PC setup-ல் HTTP 401 வந்தால் matching IDs மற்றும் இரு token values-ஐ சரிபார்க்கவும்; HTTP 403 message-ஐப் படித்து Central company/client status-ஐச் சரிசெய்யவும்.
- Public Funnel URL APK-க்குள் embed செய்யப்படுவதில்லை; inspector அதை app-ல் உள்ளிட்டு அந்த phone-ல் சேமிக்கிறார். Client credentials APK-க்குள் build செய்யப்படுவதில்லை.
- Android LAN fallback-க்கு, ClientPC/.env-ல் உள்ள RTI_LAN_API_TOKEN-ஐ மட்டும் Android-ல் private-ஆக உள்ளிடவும்.
- LAN fallback பயன்படுத்தும் போது Windows Firewall-ல் TCP 5100-ஐ Private network-க்கு மட்டும் திறக்கவும்.

## Offline நேரத்தில்

- முதலில் ஒருமுறை online login செய்து checkpoint data download செய்ய வேண்டும்.
- அதற்குப் பிறகு cached credential மூலம் offline login செய்யலாம்.
- Server-ஐ அடைய முடியாவிட்டால் scan device-ல் queue ஆகும். LAN Client PC கிடைத்தால் event அங்கே அனுப்பப்படும்.
- Internet/LAN திரும்பியதும் app foreground-ல் இருக்கும்போது automatic retry நடக்கும்.
- App திறந்திருக்கும் போது Internet, Central, Client PC/LAN, Central sync, pending queue நிலைகள் live-ஆக காட்டப்படும்; நிலை மாறும்போது Android notification வரும். Notification permission தேவை.
- Device clock தவறாக இருந்தால் offline scan நேரம் device-reported என்று server காட்டும்; Android warning தரும்.
- Offline-ல் server-க்கு live alert அனுப்ப முடியாது. Sync வந்த பிறகே அந்த event மற்றும் server receive time தெரிவியும்.

மேலும் cloud deployment, Client PC setup, schedule permissions, backups ஆகியவற்றுக்கு MASTER_ARCHITECTURE_TAMIL_EN.md பார்க்கவும்.
