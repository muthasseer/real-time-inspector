package com.absecuritas.realtimeinspector

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var loginPanel: LinearLayout
    private lateinit var startPanel: LinearLayout
    private lateinit var inspectionPanel: View
    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var scanHint: TextView
    private lateinit var lastScan: TextView
    private lateinit var companyText: TextView
    private lateinit var inspectorText: TextView
    private lateinit var deviceText: TextView
    private lateinit var locationSummary: TextView
    private lateinit var locationSummary2: TextView
    private lateinit var inspectorText2: TextView
    private lateinit var userIdInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var deviceIdText: TextView

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val processing = AtomicBoolean(false)
    private var camera: Camera? = null
    private var mobileToken = ""
    private var companyName = ""
    private var userName = ""
    private var userId = ""
    private var deviceId = ""
    private var inspectionStarted = false
    private var inspectionSessionToken = ""
    private var inspectionSessionId = 0
    private var alertShowing = false

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else showStatus("CAMERA PERMISSION REQUIRED", false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        bindViews()
        deviceId = getSharedPreferences("rti_mobile", MODE_PRIVATE).getString("device_id", "") ?: ""
        if (deviceId.isBlank()) {
            val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "DEVICE"
            val normalized = androidId.replace("[^A-Za-z0-9]".toRegex(), "").uppercase(Locale.US).takeLast(16)
            deviceId = "DEV-" + normalized
            getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().putString("device_id", deviceId).apply()
        }
        deviceIdText.text = deviceId
        restoreSession()
    }

    private fun bindViews() {
        loginPanel = findViewById(R.id.loginPanel)
        startPanel = findViewById(R.id.startPanel)
        inspectionPanel = findViewById(R.id.inspectionPanel)
        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        scanHint = findViewById(R.id.scanHint)
        lastScan = findViewById(R.id.lastScan)
        companyText = findViewById(R.id.companyText)
        inspectorText = findViewById(R.id.inspectorText)
        deviceText = findViewById(R.id.deviceText)
        locationSummary = findViewById(R.id.locationSummary)
        locationSummary2 = findViewById(R.id.locationSummary2)
        inspectorText2 = findViewById(R.id.inspectorText2)
        userIdInput = findViewById(R.id.userIdInput)
        passwordInput = findViewById(R.id.passwordInput)
        deviceIdText = findViewById(R.id.deviceIdText)
        findViewById<Button>(R.id.loginButton).setOnClickListener { login() }
        findViewById<Button>(R.id.startInspectionButton).setOnClickListener { startInspection() }
        findViewById<Button>(R.id.stopInspectionButton).setOnClickListener { stopInspection() }
        findViewById<Button>(R.id.switchInspectorButton).setOnClickListener { switchInspector() }
    }

    private fun restoreSession() {
        mobileToken = getSharedPreferences("rti_mobile", MODE_PRIVATE).getString("token", "") ?: ""
        if (mobileToken.isBlank()) {
            showLogin()
            return
        }
        Thread {
            try {
                val code = stateRequest()
                if (code.first in 200..299) {
                    val json = JSONObject(code.second)
                    applySession(json)
                    inspectionSessionToken = json.optString("inspection_session_token", "")
                    inspectionSessionId = json.optInt("inspection_session_id", 0)
                    val active = json.optBoolean("inspection_active", false)
                    mainHandler.post { if (active && inspectionSessionToken.isNotBlank()) showInspection() else showStart() }
                } else mainHandler.post { showLogin() }
            } catch (_: Exception) { mainHandler.post { showLogin() } }
        }.start()
    }

    private fun login() {
        val uid = userIdInput.text.toString().trim()
        val pw = passwordInput.text.toString()
        val did = deviceId
        if (uid.isBlank() || pw.isBlank() || did.isBlank()) {
            Toast.makeText(this, "User ID and Password are required", Toast.LENGTH_LONG).show()
            return
        }
        showLoginStatus("CONNECTING TO COMPANY...", true)
        Thread {
            try {
                val payload = JSONObject().apply { put("device_id", did); put("user_id", uid); put("password", pw) }
                val result = postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/login", payload, null)
                if (result.first in 200..299) {
                    val json = JSONObject(result.second)
                    mobileToken = json.optString("mobile_token")
                    companyName = json.optString("company_name")
                    userName = json.optString("user_name")
                    userId = json.optString("user_id", uid)
                    deviceId = json.optString("device_id", did)
                    getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().putString("token", mobileToken).putString("device_id", deviceId).apply()
                    mainHandler.post { showStart() }
                } else {
                    val msg = try { JSONObject(result.second).optString("message", "Login failed") } catch (_: Exception) { "Login failed" }
                    mainHandler.post { showLoginStatus(msg, false) }
                }
            } catch (_: Exception) { mainHandler.post { showLoginStatus("NETWORK ERROR — CHECK INTERNET", false) } }
        }.start()
    }

    private fun showLogin() {
        loginPanel.visibility = View.VISIBLE
        startPanel.visibility = View.GONE
        inspectionPanel.visibility = View.GONE
    }

    private fun showStart() {
        inspectionStarted = false
        inspectionPanel.visibility = View.GONE
        loginPanel.visibility = View.GONE
        startPanel.visibility = View.VISIBLE
        companyText.text = companyName.ifBlank { "Company" }
        inspectorText.text = "Inspector / User: $userName  •  ID: $userId"
        deviceText.text = "Device ID: $deviceId"
        findViewById<TextView>(R.id.startStatus).text = "Ready. Press Start Inspection when you reach the inspection area."
        refreshLocations()
    }

    private fun startInspection() {
        if (mobileToken.isBlank()) { showLogin(); return }
        findViewById<Button>(R.id.startInspectionButton).isEnabled = false
        Thread {
            try {
                val result = postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/start-inspection", JSONObject(), mobileToken)
                if (result.first in 200..299) {
                    val json = JSONObject(result.second)
                    inspectionSessionToken = json.optString("inspection_session_token")
                    inspectionSessionId = json.optInt("inspection_session_id", 0)
                    inspectionStarted = true
                    mainHandler.post {
                        findViewById<Button>(R.id.startInspectionButton).isEnabled = true
                        showInspection()
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
                        else cameraPermission.launch(Manifest.permission.CAMERA)
                        refreshLocations()
                    }
                } else {
                    val msg = try { JSONObject(result.second).optString("message", "Unable to start inspection") } catch (_: Exception) { "Unable to start inspection" }
                    mainHandler.post { findViewById<Button>(R.id.startInspectionButton).isEnabled = true; Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
                }
            } catch (_: Exception) {
                mainHandler.post { findViewById<Button>(R.id.startInspectionButton).isEnabled = true; Toast.makeText(this, "NETWORK ERROR — CHECK INTERNET", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun showInspection() {
        inspectionStarted = true
        loginPanel.visibility = View.GONE
        startPanel.visibility = View.GONE
        inspectionPanel.visibility = View.VISIBLE
        previewView.visibility = View.VISIBLE
        inspectorText2.text = "Inspector: $userName  •  ID: $userId\nDevice: $deviceId"
        scanHint.text = "Align the QR code inside the scan box"
        showStatus("READY — SCAN QR", true)
        refreshLocations()
    }

    private fun switchInspector() {
        val token = mobileToken
        mobileToken = ""
        inspectionStarted = false
        inspectionSessionToken = ""
        inspectionSessionId = 0
        getSharedPreferences("rti_mobile", MODE_PRIVATE).edit().remove("token").apply()
        if (token.isNotBlank()) Thread { try { postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/logout", JSONObject(), token) } catch (_: Exception) {} }.start()
        showLogin()
    }

    private fun stopInspection(manual: Boolean = true) {
        val token = mobileToken
        val session = inspectionSessionToken
        inspectionStarted = false
        inspectionSessionToken = ""
        inspectionSessionId = 0
        camera = null
        previewView.visibility = View.GONE
        inspectionPanel.visibility = View.GONE
        if (manual && token.isNotBlank() && session.isNotBlank()) {
            Thread {
                try { postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/end-inspection", JSONObject().apply { put("inspection_session_token", session) }, token) } catch (_: Exception) {}
            }.start()
        }
        showStart()
    }

    private fun refreshLocations() {
        if (mobileToken.isBlank()) return
        Thread {
            try {
                val r = stateRequest()
                if (r.first !in 200..299) return@Thread
                val json = JSONObject(r.second)
                applySession(json)
                val active = json.optBoolean("inspection_active", false)
                val token = json.optString("inspection_session_token", "")
                val sid = json.optInt("inspection_session_id", 0)
                if (active && token.isNotBlank()) { inspectionSessionToken = token; inspectionSessionId = sid }
                val scanned = json.optInt("scanned_points", 0)
                val pending = json.optInt("pending_points", 0)
                val total = json.optInt("total_points", 0)
                val summary = "TOTAL POINTS: $total    •    SCANNED: $scanned    •    PENDING: $pending"
                val arr = json.optJSONArray("locations")
                val scannedNames = StringBuilder(); val pendingNames = StringBuilder()
                if (arr != null) for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    val label = item.optString("point_code") + " - " + item.optString("name")
                    if (item.optInt("scanned") == 1) { if (scannedNames.isNotEmpty()) scannedNames.append("\n"); scannedNames.append("✓ ").append(label) }
                    else { if (pendingNames.isNotEmpty()) pendingNames.append("\n"); pendingNames.append("• ").append(label) }
                }
                mainHandler.post {
                    locationSummary.text = summary
                    locationSummary2.text = summary
                    if (inspectionStarted && json.optBoolean("inspection_complete", false)) completeInspection()
                }
            } catch (_: Exception) {}
        }.start()
    }

    private fun applySession(json: JSONObject) {
        companyName = json.optString("company_name", companyName)
        userName = json.optString("inspector_name", json.optString("user_name", userName))
        userId = json.optString("inspector_id", json.optString("user_id", userId))
    }

    private fun stateRequest(): Pair<Int, String> = getJson(AppConfig.SERVER_BASE_URL + "/api/mobile/state", mobileToken)

    private fun startCamera() {
        if (!inspectionStarted) return
        mainHandler.post { previewView.visibility = View.VISIBLE }
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val provider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
            val options = BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            val scanner = BarcodeScanning.getClient(options)
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                val mediaImage = imageProxy.image
                if (mediaImage == null || processing.get() || !inspectionStarted) { imageProxy.close(); return@setAnalyzer }
                val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                scanner.process(image)
                    .addOnSuccessListener { barcodes -> barcodes.firstOrNull()?.rawValue?.trim()?.takeIf { it.isNotBlank() }?.let { handleQr(it) } }
                    .addOnFailureListener { }
                    .addOnCompleteListener { imageProxy.close() }
            }
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            showStatus("READY — SCAN QR", true)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun handleQr(rawValue: String) {
        if (!rawValue.startsWith("RTI-", true) || !processing.compareAndSet(false, true)) return
        mainHandler.post { scanHint.text = "Sending inspection..."; statusText.text = "CONNECTING TO SERVER..." }
        cameraExecutor.execute {
            try {
                val payload = JSONObject().apply { put("qr_token", rawValue); put("device_id", deviceId); put("inspection_session_token", inspectionSessionToken) }
                val response = postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/scan", payload, mobileToken)
                mainHandler.post { handleServerResponse(response.first, response.second) }
            } catch (_: Exception) {
                mainHandler.post { showStatus("NETWORK ERROR — CHECK INTERNET", false); scanHint.text = "Ready for next inspection point"; processing.set(false) }
            }
        }
    }

    private fun handleServerResponse(httpCode: Int, body: String) {
        val json = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
        val result = json.optString("result", "")
        val pointName = json.optString("point_name", "Inspection Point")
        lastScan.text = "$pointName — ${now()}"
        when {
            httpCode in 200..299 && result.equals("ACCEPTED", true) -> showStatus("✓ ACCEPTED", true)
            httpCode in 200..299 && result.equals("REPEAT", true) -> showStatus("REPEAT ${json.optInt("repeat_count", 0)} / 2", false)
            httpCode in 200..299 && result.equals("REPEAT_ALERT", true) -> {
                showStatus("⚠ REPEAT ALERT", false)
                repeatAlert(json.optString("message", "This point has already been repeated twice."))
            }
            else -> showStatus(json.optString("message", "SERVER ERROR ($httpCode)"), false)
        }
        scanHint.text = "Align the QR code inside the scan box"
        refreshLocations()
        if (json.optBoolean("inspection_complete", false)) {
            mainHandler.postDelayed({ completeInspection() }, 500)
        } else if (!alertShowing) {
            mainHandler.postDelayed({ processing.set(false) }, 1000)
        }
    }

    private fun repeatAlert(message: String) {
        if (alertShowing) return
        alertShowing = true
        try { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 700) } catch (_: Exception) {}
        AlertDialog.Builder(this)
            .setTitle("Repeat Alert")
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss(); alertShowing = false; processing.set(false) }
            .show()
    }

    private fun completeInspection() {
        if (!inspectionStarted) return
        inspectionStarted = false
        camera = null
        val session = inspectionSessionToken
        inspectionSessionToken = ""
        inspectionSessionId = 0
        Toast.makeText(this, "Inspection completed — all points scanned", Toast.LENGTH_LONG).show()
        mainHandler.postDelayed({ showStart(); processing.set(false) }, 400)
        if (session.isNotBlank() && mobileToken.isNotBlank()) {
            Thread { try { postJson(AppConfig.SERVER_BASE_URL + "/api/mobile/end-inspection", JSONObject().apply { put("inspection_session_token", session) }, mobileToken) } catch (_: Exception) {} }.start()
        }
    }

    private fun postJson(url: String, payload: JSONObject, token: String?): Pair<Int, String> {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 10000; readTimeout = 10000; doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8"); setRequestProperty("Accept", "application/json")
            if (!token.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $token")
        }
        c.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        return Pair(code, body)
    }

    private fun getJson(url: String, token: String): Pair<Int, String> {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 10000; readTimeout = 10000
            setRequestProperty("Accept", "application/json"); setRequestProperty("Authorization", "Bearer $token")
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        return Pair(code, body)
    }

    private fun showLoginStatus(message: String, success: Boolean) {
        findViewById<TextView>(R.id.loginStatus).text = message
        findViewById<TextView>(R.id.loginStatus).setTextColor(ContextCompat.getColor(this, if (success) R.color.navy else R.color.red))
    }

    private fun showStatus(message: String, success: Boolean) {
        statusText.text = message
        statusText.setTextColor(ContextCompat.getColor(this, if (success) R.color.green else R.color.red))
    }

    private fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }
}
