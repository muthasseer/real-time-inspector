# AB Securitas Real Time Inspector V12

## Inspection session flow
- Login once on the Android device; no logout is required between inspections.
- `Start Inspection` creates a new server-side inspection session.
- Camera opens with a visible QR scan box.
- The app displays Total Points, Scanned Points and Pending Points during the session.
- First scan of a point in the current session = `ACCEPTED`.
- First repeat = `REPEAT` and is stored.
- Second repeat = `REPEAT` and is stored.
- Third repeat attempt = `REPEAT_ALERT`; it is not added to scan history, and Android gives a beep + blocking popup requiring OK.
- `END INSPECTION` ends the current session manually.
- When every active checkpoint has been accepted once in the current session, the app automatically returns to the inspection home screen.
- Each Start Inspection creates a fresh session, so logging out is not required to start another inspection cycle.
- `SWITCH INSPECTOR` is available when the same physical device must be used by another inspector.

## Device model
- Android generates the Device ID automatically and shows it as non-editable.
- A single physical device can be used by multiple inspectors in the same company.
- Server validates the immutable device ID on every mobile request.

## Super Admin password reveal
- Normal login passwords remain PBKDF2 hashed.
- New user/inspector passwords also have a separately encrypted copy only for the explicit Super Admin reveal function.
- Every reveal requires the current Super Admin password again.
- Old records created before this feature may require a password reset before their password can be displayed.

## Database migration
The Web `app.py` automatically adds the V12 schema fields/tables to an existing `inspector.db`; do not delete the production database when upgrading.

New schema includes `inspection_sessions`, `scans.inspection_session_id`, `scans.repeat_count`, and secure password-reveal fields.


## V12.1 Branding Update
- AB Securitas logo added to the application header.
- Same logo used as the Android launcher icon.
