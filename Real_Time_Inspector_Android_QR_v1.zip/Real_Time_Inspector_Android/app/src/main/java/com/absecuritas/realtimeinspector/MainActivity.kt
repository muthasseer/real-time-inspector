package com.absecuritas.realtimeinspector

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var lastScan: TextView
    private lateinit var statusText: TextView
    private lateinit var scanHint: TextView

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val processing = AtomicBoolean(false)
    private var camera: Camera? = null

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else showStatus("CAMERA PERMISSION REQUIRED", false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        lastScan = findViewById(R.id.lastScan)
        statusText = findViewById(R.id.statusText)
        scanHint = findViewById(R.id.scanHint)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val provider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }

            val options = BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .build()
            val scanner = BarcodeScanning.getClient(options)

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                val mediaImage = imageProxy.image
                if (mediaImage == null || processing.get()) {
                    imageProxy.close()
                    return@setAnalyzer
                }

                val image = InputImage.fromMediaImage(
                    mediaImage,
                    imageProxy.imageInfo.rotationDegrees
                )

                scanner.process(image)
                    .addOnSuccessListener { barcodes ->
                        val value = barcodes.firstOrNull()?.rawValue
                        if (!value.isNullOrBlank()) handleQr(value.trim())
                    }
                    .addOnFailureListener {
                        // Ignore individual frame failures; continue scanning.
                    }
                    .addOnCompleteListener {
                        imageProxy.close()
                    }
            }

            provider.unbindAll()
            camera = provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                analysis
            )

            showStatus("READY — SCAN QR", true)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun handleQr(rawValue: String) {
        if (!processing.compareAndSet(false, true)) return

        val pointId = mapQrToPoint(rawValue)
        if (pointId == null) {
            showStatus("UNKNOWN QR: $rawValue", false)
            mainHandler.postDelayed({ processing.set(false) }, 1800)
            return
        }

        val pointLabel = "POINT-${pointId.removePrefix("P").padStart(2, '0')}"
        mainHandler.post {
            scanHint.text = "Sending $pointLabel..."
            statusText.text = "CONNECTING TO SERVER..."
        }

        camera?.cameraControl?.enableTorch(false)

        cameraExecutor.execute {
            try {
                val payload = JSONObject().apply {
                    put("point_id", pointId)
                    put("inspector_id", AppConfig.INSPECTOR_ID)
                    put("device_id", AppConfig.DEVICE_ID)
                }

                val url = URL(AppConfig.SERVER_BASE_URL + AppConfig.SCAN_ENDPOINT)
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 8000
                    readTimeout = 8000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Accept", "application/json")
                }

                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                connection.disconnect()

                mainHandler.post { handleServerResponse(pointLabel, code, body) }
            } catch (e: Exception) {
                mainHandler.post {
                    lastScan.text = "$pointLabel — ${now()}"
                    showStatus("NETWORK ERROR — CHECK 4G/INTERNET", false)
                    scanHint.text = "Move to the next QR"
                    processing.set(false)
                }
            }
        }
    }

    private fun handleServerResponse(pointLabel: String, httpCode: Int, body: String) {
        val serverStatus = try {
            JSONObject(body).optString("status", "")
        } catch (_: Exception) {
            ""
        }

        lastScan.text = "$pointLabel — ${now()}"

        when {
            httpCode in 200..299 && serverStatus.equals("ACCEPTED", true) -> {
                showStatus("✓ ACCEPTED", true)
            }
            httpCode in 200..299 && serverStatus.equals("REPEAT", true) -> {
                showStatus("REPEAT — ALREADY SCANNED TODAY", false)
            }
            httpCode in 200..299 -> {
                showStatus("✓ SCAN SENT", true)
            }
            else -> {
                showStatus("SERVER ERROR ($httpCode)", false)
            }
        }

        scanHint.text = "Ready for next inspection point"
        mainHandler.postDelayed({ processing.set(false) }, 2200)
    }

    private fun mapQrToPoint(value: String): String? {
        // Current QR set: RTI-COMPANY01-P01 ... RTI-COMPANY01-P10
        val regex = Regex("RTI-COMPANY01-P(0[1-9]|10)", RegexOption.IGNORE_CASE)
        val match = regex.matchEntire(value) ?: return null
        return "P${match.groupValues[1].uppercase(Locale.US)}"
    }

    private fun showStatus(message: String, success: Boolean) {
        statusText.text = message
        statusText.setTextColor(
            ContextCompat.getColor(this, if (success) R.color.green else R.color.red)
        )
    }

    private fun now(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
