package com.absecuritas.realtimeinspector

object AppConfig {
    // Current live backend
    const val SERVER_BASE_URL = "https://muthasseer.pythonanywhere.com"

    // Change these per inspection phone/user.
    const val INSPECTOR_ID = "INSPECTOR-01"
    const val DEVICE_ID = "PHONE-01"

    const val SCAN_ENDPOINT = "/api/scan"
}
