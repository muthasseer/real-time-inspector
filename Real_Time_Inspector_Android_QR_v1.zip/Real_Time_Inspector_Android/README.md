# Real Time Inspector — Android QR Scanner

Version 1.0 prototype for the current Real Time Inspector backend.

## Current flow

QR → Android camera → ML Kit QR detection → HTTPS POST → PythonAnywhere Flask API → dashboard

Current server:
https://muthasseer.pythonanywhere.com

API:
POST /api/scan

JSON sent:
{
  "point_id": "P01",
  "inspector_id": "INSPECTOR-01",
  "device_id": "PHONE-01"
}

Current QR format:
RTI-COMPANY01-P01 ... RTI-COMPANY01-P10

## Build

Open this folder in Android Studio.

Recommended JDK: 17.

Let Android Studio sync/download Gradle and Android dependencies, then run:
app > Run on the Redmi Note 8 Pro.

If Android Studio asks to upgrade Gradle/AGP, do not change the project first; report the exact message so the project can be adjusted consistently.

## Per-phone configuration

Edit:
app/src/main/java/com/absecuritas/realtimeinspector/AppConfig.kt

Change:
INSPECTOR_ID
DEVICE_ID

The server URL is already configured as:
https://muthasseer.pythonanywhere.com

## Notes

- QR scanning is on-device using bundled ML Kit.
- The app requires camera permission and internet permission.
- The current prototype does not yet include offline queue/sync, NFC, admin login, or Android kiosk/device-owner lock.
- Those can be added after the QR → server flow is confirmed.
